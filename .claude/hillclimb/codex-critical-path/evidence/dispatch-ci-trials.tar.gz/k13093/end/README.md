# CI runner snapshot checkout

The pool monitor writes raw exports under `exports/`. `exports/latest.json` points to
one collector capture. Depth and enqueue times can arrive separately. The capture
stamp is the time against which wait is measured.

`./tools/runner-queue --pool deploy-eu` reads the pending depth. Add `--include-wait`
for the oldest pending age, in seconds. The command reports unavailable wait rows
on stderr and returns 2 when it cannot associate complete rows with the capture.

See `runbooks/runner-window.md` for the pool change window.
