# Release runner change window

For deploy-eu, at this window we can add one runner when a complete queue capture
shows the oldest pending job has waited under eight minutes. At eight minutes or
longer, hold the change so the service owners can investigate the allocator.
If the capture cannot establish oldest pending wait, leave the count of runners
alone and obtain the wait export for that capture. Queue depth is a separate measure.
