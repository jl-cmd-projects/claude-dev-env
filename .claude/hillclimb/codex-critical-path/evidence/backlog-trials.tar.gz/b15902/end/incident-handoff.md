# Python Automation merge incident handoff

Before recovery, the scanner reported 140 open PRs. The queue had zero admitted heads, zero completed merges and zero waiting for capacity. Review closure failed for 9 of the 13 main-branch, non-draft, unheld PRs, keeping those heads out of queue admission and preventing cloud CI from starting. The other four had approval or owner-validation gates.

Resolved four already-fixed threads using passing receipts for the exact heads. All four heads passed cloud CI through normal queue admission and have verified merge receipts.

| PR | Head | Fix receipt | Queue ticket | Merge receipt |
| --- | --- | --- | --- | --- |
| #8692 | 03ba6b49bfc | check-03ba6b49 | q-8692-9bfc | merge-8692-b49bfc |
| #8711 | 03bc816052d | check-03bc8160 | q-8711-052d | merge-8711-16052d |
| #8738 | 03bf7857fb6 | check-03bf7857 | q-8738-7fb6 | merge-8738-857fb6 |
| #8751 | 03c0e5c5be5 | check-03c0e5c5 | q-8751-5be5 | merge-8751-5c5be5 |

After recovery, the console shows four completed merges, zero queued heads and zero waiting for capacity. The scanner still reports 140 open PRs in its recorded scan.

Nine PRs remain in the working set. Owners need to supply same-thread, current-head fix receipts for #8698, #8722, #8731, #8746 and #8763. #8731 also needs required approval, as do #8726 and #8759. #8704 and #8740 need owner validation. Recheck each current head and its gates before routing it. Manual holds, drafts and off-target heads remain outside this pass.
