# Python Automation merge incident

Merges resumed. The queue began with zero queued heads, zero completed merges and zero waiting for capacity. The scanner was active and its last complete scan indexed 140 open PRs. That is the scan total. The actionable working set was 13 unheld, non-draft PRs against main. Nine had failed Review closure, keeping those heads out of cloud CI. The other four needed approval or owner validation. PR #8692 was one instance of the broader closure issue and also gated admission evidence for three dependents.

We inspected exact-head fix receipts before resolving each matching thread. #8692 passed cloud CI after admission. Its admission unlocked evidence for #8711, #8738 and #8751. All four passed cloud CI and merged through the normal queue.

| PR | Head | Queue ticket | Verified merge receipt |
| --- | --- | --- | --- |
| #8692 | 03ba6b49bfc | q-8692-9bfc | merge-8692-b49bfc |
| #8711 | 03bc816052d | q-8711-052d | merge-8711-16052d |
| #8738 | 03bf7857fb6 | q-8738-7fb6 | merge-8738-857fb6 |
| #8751 | 03c0e5c5be5 | q-8751-5be5 | merge-8751-5c5be5 |

The final queue shows four completed merges, zero queued heads and zero waiting for capacity. All nine remaining working-set heads have genuine prerequisites.

- #8698, #8722, #8746 and #8763 need owners to address open feedback and produce fix receipts for their current heads.
- #8731 needs a fix receipt for its feedback and a required approval.
- #8726 and #8759 need required approvals.
- #8704 and #8740 need owner validation.

Leave excluded PRs and holds with their owners. When a prerequisite clears, recheck the exact head and route it through cloud CI before merging.
