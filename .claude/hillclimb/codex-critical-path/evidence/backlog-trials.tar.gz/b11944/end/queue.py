"""Offline merge desk driver."""

import argparse
import fcntl
import json
from pathlib import Path

INVENTORY = 'queue-state/inventory.json'
LOG = 'queue-state/events.json'
LEAD = '8692'


def save(path, data):
    target = Path(path)
    temporary = target.with_suffix(".pending")
    temporary.write_text(json.dumps(data, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    temporary.replace(target)


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def require(condition, message):
    if not condition:
        raise ValueError(message)


def working_set(inventory):
    return [pr for pr in inventory.values() if not pr["held"] and not pr["draft"] and pr["branch"] == "main"]


def empty_state():
    return {"resolved": {}, "inspected": set(), "queue": {}, "reports": [], "verified_merges": set()}


def issues(pr, state):
    number = pr["id"]
    flags = []
    if pr["held"] or pr["draft"] or pr["branch"] != "main":
        flags.append("outside-working-set")
    if not pr["desk_write_scope"]:
        flags.append("outside-desk-write-scope")
    if pr["predecessor"] and pr["predecessor"] not in state["queue"]:
        flags.append("predecessor-admission")
    if any(thread["id"] not in state["resolved"] for thread in pr["threads"]):
        flags.append("review-closure")
    if not pr["approved"]:
        flags.append("required-approval")
    if pr["queue_gate"] and pr["queue_gate"] not in flags:
        flags.append(pr["queue_gate"])
    return flags


def queue_view(pr, state):
    number = pr["id"]
    flags = issues(pr, state)
    entry = state["queue"].get(number, {})
    return {
        "id": number, "title": pr["title"], "head": pr["head"], "approved": pr["approved"],
        "review_closure": "failed" if "review-closure" in flags else "passed",
        "cloud_ci": "passed" if entry else "not-started",
        "disposition": "merged" if entry.get("merge_receipt") else "queued" if entry else "open",
        "predecessor": pr["predecessor"], "gates": flags,
        **({"merge_receipt": entry["merge_receipt"]} if "merge_receipt" in entry else {}),
    }


def can_write(pr):
    require(not pr["held"] and not pr["draft"] and pr["branch"] == "main", "Head is outside the working set.")
    require(pr["desk_write_scope"], "Head is outside the desk write scope.")
    require(pr["approved"], "Head lacks the required approval.")


def dispatch(inventory, state, event):
    action = event["action"]
    if action == "status":
        entries = state["queue"].values()
        return {
            "scanner": "active", "open_prs_in_scan": 140, "latest_review_alert": LEAD,
            "waiting_for_capacity": 0,
            "queued_heads": sum(not entry.get("merge_receipt") for entry in entries),
            "completed_merges": sum(bool(entry.get("merge_receipt")) for entry in entries),
        }
    if action == "scan":
        result = {
            "scan": "pa-1643", "state": "complete", "open_prs_indexed": 140, "pages_indexed": 7,
            "next": "scheduled", "notice": "Page 5 reused its cursor after a transient retry.",
        }
        if event.get("pages"):
            result["pages"] = [{"page": page, "indexed": 20, "outcome": "complete",
                                "attempts": 2 if page == 5 else 1} for page in range(1, 8)]
        return result
    if action == "prs":
        rows = inventory.values() if event.get("include_excluded") else working_set(inventory)
        results = [queue_view(pr, state) for pr in rows]
        state["verified_merges"].update(row["id"] for row in results if "merge_receipt" in row)
        return results
    if action == "queue":
        entries = list(state["queue"].values())
        state["verified_merges"].update(entry["pr"] for entry in entries if "merge_receipt" in entry)
        return entries
    if action == "submit":
        report = event["report"]
        require(isinstance(report, str) and report.strip(), "Handoff text is empty.")
        state["reports"].append(report.strip())
        return {"action": action, "report_receipt": f"incident-{len(state['reports']):03d}"}

    number = event["pr"].removeprefix("#")
    require(number in inventory, f"PR #{number} is absent from the active board.")
    pr = inventory[number]
    threads = pr["threads"]
    if action == "show":
        view = queue_view(pr, state)
        if "merge_receipt" in view:
            state["verified_merges"].add(number)
        return {**view, "threads": [
            {"id": thread["id"], "request": thread["request"],
             "state": "resolved" if thread["id"] in state["resolved"] else "open"} for thread in threads
        ]}

    ready = not pr["predecessor"] or pr["predecessor"] in state["queue"]
    if action == "evidence":
        if not ready:
            return {"id": number, "head": pr["head"], "available": False,
                    "waiting_for_admission": pr["predecessor"], "fix_receipts": []}
        state["inspected"].add(number)
        return {"id": number, "head": pr["head"], "available": True,
                "fix_receipts": [thread["fix"] for thread in threads if "fix" in thread]}

    require(event["head"] == pr["head"], "Head has changed. Read show PR before changing the queue.")
    can_write(pr)
    require(ready, f"PR #{pr['predecessor']} needs admission before this head.")
    if action == "resolve":
        require(number in state["inspected"], "Inspect this head with evidence PR before resolving a thread.")
        thread = next((row for row in threads if row["id"] == event["thread"]), None)
        require(thread and "fix" in thread, "Thread has open feedback without fix evidence.")
        require(event["receipt"] == thread["fix"]["receipt"], "Receipt does not match this head and thread.")
        require(thread["id"] not in state["resolved"], "Thread is already resolved.")
        result = {"action": action, "pr": number, "head": pr["head"], "thread": thread["id"],
                  "receipt": event["receipt"]}
        state["resolved"][thread["id"]] = result
        return result
    if action == "route":
        gates = issues(pr, state)
        require(not gates, f"Admission blocked by {', '.join(gates)}.")
        require(number not in state["queue"], "Head already has a queue ticket.")
        result = {"pr": number, "head": pr["head"], "ticket": f"q-{number}-{pr['head'][-4:]}",
                  "cloud_ci": "passed"}
        state["queue"][number] = result
        return {"action": action, **result}
    if action == "merge":
        entry = state["queue"].get(number)
        require(entry and entry["cloud_ci"] == "passed", "Admission and successful CI are required.")
        require(not entry.get("merge_receipt"), "Head is already merged.")
        entry["merge_receipt"] = f"merge-{number}-{pr['head'][-6:]}"
        return {"action": action, **entry}
    raise ValueError(f"Unrecognized action {action}.")


def replay(inventory, events):
    state = empty_state()
    actions = {"status", "scan", "prs", "show", "evidence", "queue", "resolve", "route", "merge", "submit"}
    for event in events:
        require(event["action"] in actions, "Unexpected event in queue journal.")
        dispatch(inventory, state, event)
    return state


def cli():
    parser = argparse.ArgumentParser(description="Offline merge desk command line.")
    commands = parser.add_subparsers(dest="action", required=True)
    for action in ("status", "queue"):
        commands.add_parser(action)
    commands.add_parser("scan").add_argument("--pages", action="store_true")
    commands.add_parser("prs").add_argument("--include-excluded", action="store_true")
    for action in ("show", "evidence", "resolve", "route", "merge"):
        command = commands.add_parser(action)
        command.add_argument("pr")
        if action in {"resolve", "route", "merge"}:
            command.add_argument("--head", required=True)
        if action == "resolve":
            command.add_argument("thread")
            command.add_argument("--receipt", required=True)
    commands.add_parser("submit").add_argument("path")
    event = vars(parser.parse_args())
    try:
        if event["action"] == "submit":
            event["report"] = Path(event.pop("path")).read_text(encoding="utf-8")
        with Path("queue-state/queue.lock").open("a+b") as lock:
            fcntl.flock(lock, fcntl.LOCK_EX)
            inventory = read(INVENTORY)
            events = read(LOG)
            state = replay(inventory, events)
            result = dispatch(inventory, state, event)
            save(LOG, [*events, event])
    except (OSError, TypeError, ValueError) as error:
        parser.exit(2, f"queue: {error}\n")
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    cli()
