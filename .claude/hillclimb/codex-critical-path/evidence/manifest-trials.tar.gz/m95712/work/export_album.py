import csv
import json
from pathlib import Path


def export_album():
    batch = json.loads(Path("incoming/batch.json").read_text(encoding="utf-8"))
    receipts = [json.loads(line) for line in Path("incoming/camera-spool.jsonl").read_text(
        encoding="utf-8"
    ).splitlines() if line]
    with Path(batch["preview_sidecar"]).open(encoding="utf-8", newline="") as stream:
        sample = stream.read(4096)
        stream.seek(0)
        reader = csv.DictReader(stream, dialect=csv.Sniffer().sniff(sample, delimiters=",;"))
        fields = set(reader.fieldnames or [])
        if {"take_id", "caption"} <= fields:
            take_field, caption_field = "take_id", "caption"
        elif {"take", "note"} <= fields:
            take_field, caption_field = "take", "note"
        else:
            raise ValueError("Current sidecar must contain take_id/caption or take/note")
        captions = {
            row[take_field]: row[caption_field]
            for row in reader
            if row.get(caption_field) and (
                "album" not in fields or row["album"] == batch["album"]
            )
        }
    takes = {}
    for receipt in receipts:
        take_id = receipt["take_id"]
        if take_id not in takes:
            takes[take_id] = dict(receipt)
        elif not takes[take_id].get("caption") and receipt.get("caption"):
            takes[take_id]["caption"] = receipt["caption"]
    rows = []
    for take_id, take in takes.items():
        caption = take.get("caption") or captions.get(take_id)
        if not caption:
            raise ValueError(f"Missing caption for {take_id}")
        rows.append((take_id, take["file"], caption))
    output = Path("delivery/album-manifest.csv")
    with output.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(("take_id", "file", "caption"))
        writer.writerows(rows)
    print(f"Wrote {len(rows)} album rows to {output}")


if __name__ == "__main__":
    export_album()
