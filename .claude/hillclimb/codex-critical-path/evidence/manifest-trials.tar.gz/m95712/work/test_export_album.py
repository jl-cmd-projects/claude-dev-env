import csv
import json
import os
import tempfile
import unittest
from contextlib import contextmanager
from pathlib import Path

from export_album import export_album


@contextmanager
def working_directory(path):
    previous = Path.cwd()
    os.chdir(path)
    try:
        yield
    finally:
        os.chdir(previous)


class AlbumExportTest(unittest.TestCase):
    def run_export(self, sidecar):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        root = Path(temporary.name)
        (root / "incoming").mkdir()
        (root / "delivery").mkdir()
        (root / "incoming/batch.json").write_text(json.dumps({
            "album": "Harbor Walk", "preview_sidecar": "incoming/current.csv"
        }), encoding="utf-8")
        receipts = [
            {"take_id": "a", "file": "first.jpg", "caption": 'Morning, "blue"'},
            {"take_id": "b", "file": "second.jpg", "caption": None},
            {"take_id": "a", "file": "retry.jpg", "caption": None},
            {"take_id": "b", "file": "retry2.jpg", "caption": None},
        ]
        (root / "incoming/camera-spool.jsonl").write_text(
            "\n".join(map(json.dumps, receipts)), encoding="utf-8"
        )
        (root / "incoming/current.csv").write_text(sidecar, encoding="utf-8")
        before = {p.name: p.read_bytes() for p in (root / "incoming").iterdir()}
        with working_directory(root):
            export_album()
        self.assertEqual(before, {
            p.name: p.read_bytes() for p in (root / "incoming").iterdir()
        })
        with (root / "delivery/album-manifest.csv").open(encoding="utf-8", newline="") as stream:
            return list(csv.reader(stream))

    def test_current_sidecar_and_retries(self):
        rows = self.run_export(
            "take;note;album\na;Draft;Harbor Walk\n"
            "b;São Miguel ferry berth;Harbor Walk\nx;Reference;Harbor Walk\n"
        )
        self.assertEqual(rows, [
            ["take_id", "file", "caption"],
            ["a", "first.jpg", 'Morning, "blue"'],
            ["b", "second.jpg", "São Miguel ferry berth"],
        ])

    def test_standard_sidecar(self):
        self.assertEqual(self.run_export("take_id,caption\nb,Current caption\n")[2],
                         ["b", "second.jpg", "Current caption"])


if __name__ == "__main__":
    unittest.main()
