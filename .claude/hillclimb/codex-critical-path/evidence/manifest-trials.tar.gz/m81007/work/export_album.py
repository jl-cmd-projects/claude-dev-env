import csv
import json
from pathlib import Path


def export_album():
    receipts = {}
    with Path("incoming/camera-spool.jsonl").open(encoding="utf-8") as stream:
        for line in stream:
            if not line.strip():
                continue
            receipt = json.loads(line)
            receipts.setdefault(receipt["take_id"], receipt)

    output = Path("delivery/album-manifest.csv")
    with output.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(("take_id", "file", "caption"))
        writer.writerows(
            (take_id, receipt["file"], receipt.get("caption"))
            for take_id, receipt in receipts.items()
        )
    print(f"Wrote {len(receipts)} album rows to {output}")


if __name__ == "__main__":
    export_album()
