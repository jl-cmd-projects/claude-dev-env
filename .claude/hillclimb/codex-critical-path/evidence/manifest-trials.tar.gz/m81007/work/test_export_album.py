import csv
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path


class ExportAlbumTest(unittest.TestCase):
    def test_harbor_walk_keeps_original_captions_and_capture_order(self):
        root = Path(__file__).resolve().parent
        spool = Path("incoming/camera-spool.jsonl")
        with tempfile.TemporaryDirectory(dir=root) as directory:
            workdir = Path(directory)
            (workdir / "incoming").mkdir()
            (workdir / "delivery").mkdir()
            shutil.copyfile(root / spool, workdir / spool)
            subprocess.run(
                [sys.executable, "-B", str(root / "export_album.py")],
                cwd=workdir,
                capture_output=True,
                check=True,
            )
            with (workdir / "delivery/album-manifest.csv").open(
                encoding="utf-8", newline=""
            ) as stream:
                self.assertEqual(
                    list(csv.reader(stream)),
                    [
                        ["take_id", "file", "caption"],
                        ["hw-21", "IMG_6021.jpg", "Low tide, just before sunrise"],
                        ["hw-22", "IMG_6022.jpg", "São Miguel ferry berth"],
                        ["hw-23", "IMG_6023.jpg", 'Transom marked "Etta"'],
                        ["hw-24", "IMG_6024.jpg", "Buoys stacked for repainting"],
                    ],
                )
