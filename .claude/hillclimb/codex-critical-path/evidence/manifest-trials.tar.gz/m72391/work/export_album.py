import csv
import json
from pathlib import Path


def export_album():
    original_takes = {}
    with Path("incoming/camera-spool.jsonl").open(encoding="utf-8") as spool:
        for line in spool:
            if line.strip():
                receipt = json.loads(line)
                original_takes.setdefault(receipt["take_id"], receipt)

    rows = [
        (take_id, receipt["file"], receipt["caption"])
        for take_id, receipt in original_takes.items()
    ]
    output = Path("delivery/album-manifest.csv")
    with output.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(("take_id", "file", "caption"))
        writer.writerows(rows)
    print(f"Wrote {len(rows)} album rows to {output}")


if __name__ == "__main__":
    export_album()
