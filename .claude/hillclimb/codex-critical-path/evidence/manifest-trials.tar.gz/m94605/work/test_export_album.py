import csv
import json
import os
from pathlib import Path
import tempfile
import unittest

from export_album import export_album


class AlbumExportTest(unittest.TestCase):
    def test_retry_preserves_originals_and_fills_captions_from_current_album(self):
        with tempfile.TemporaryDirectory() as directory:
            previous = Path.cwd()
            os.chdir(directory)
            try:
                Path("incoming").mkdir()
                Path("delivery").mkdir()
                Path("incoming/batch.json").write_text(json.dumps({
                    "album": "Harbor Walk", "preview_sidecar": "incoming/current.csv"
                }), encoding="utf-8")
                Path("incoming/current.csv").write_text(
                    "take;note;album\nb;São Miguel ferry berth;Harbor Walk\n"
                    "a;Rough draft;Harbor Walk\nx;Reference;Harbor Walk\n"
                    "b;Wrong album;Other\n", encoding="utf-8"
                )
                receipts = [
                    {"take_id": "a", "file": "first.jpg", "caption": "Original, caption"},
                    {"take_id": "b", "file": "second.jpg", "caption": None},
                    {"take_id": "a", "file": "retry.jpg", "caption": "Retry"},
                    {"take_id": "b", "file": "retry2.jpg", "caption": None},
                ]
                Path("incoming/camera-spool.jsonl").write_text(
                    "\n".join(json.dumps(row) for row in receipts), encoding="utf-8"
                )
                before = {p: p.read_bytes() for p in Path("incoming").iterdir()}
                export_album()
                with Path("delivery/album-manifest.csv").open(encoding="utf-8", newline="") as stream:
                    self.assertEqual(list(csv.reader(stream)), [
                        ["take_id", "file", "caption"],
                        ["a", "first.jpg", "Original, caption"],
                        ["b", "second.jpg", "São Miguel ferry berth"],
                    ])
                self.assertEqual(before, {p: p.read_bytes() for p in Path("incoming").iterdir()})
            finally:
                os.chdir(previous)


if __name__ == "__main__":
    unittest.main()
