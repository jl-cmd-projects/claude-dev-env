import csv
import json
from pathlib import Path


def read_captions(source):
    with source.open(encoding="utf-8", newline="") as stream:
        sample = stream.read(4096)
        stream.seek(0)
        dialect = csv.Sniffer().sniff(sample, delimiters=",;")
        reader = csv.DictReader(stream, dialect=dialect)
        fields = set(reader.fieldnames or [])
        if {"take_id", "caption"}.issubset(fields):
            take_key, caption_key = "take_id", "caption"
        elif {"take", "note", "album"}.issubset(fields):
            take_key, caption_key = "take", "note"
        else:
            raise ValueError("Caption sidecar has unsupported columns")
        return list(reader), take_key, caption_key


def export_album():
    batch = json.loads(Path("incoming/batch.json").read_text(encoding="utf-8"))
    sidecar, take_key, caption_key = read_captions(Path(batch["preview_sidecar"]))
    captions = {
        row[take_key]: row[caption_key]
        for row in sidecar
        if "album" not in row or row["album"] == batch["album"]
    }
    receipts = [json.loads(line) for line in Path("incoming/camera-spool.jsonl").read_text(
        encoding="utf-8"
    ).splitlines() if line]
    originals = {}
    for row in receipts:
        originals.setdefault(row["take_id"], row)
    rows = [
        (take_id, row["file"], row.get("caption") or captions.get(take_id, ""))
        for take_id, row in originals.items()
    ]
    output = Path("delivery/album-manifest.csv")
    with output.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(("take_id", "file", "caption"))
        writer.writerows(rows)
    print(f"Wrote {len(rows)} album rows to {output}")


if __name__ == "__main__":
    export_album()
