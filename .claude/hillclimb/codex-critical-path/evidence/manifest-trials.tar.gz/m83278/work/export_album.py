import csv
import json
from pathlib import Path


def export_album():
    batch = json.loads(Path("incoming/batch.json").read_text(encoding="utf-8"))
    with Path(batch["preview_sidecar"]).open(encoding="utf-8", newline="") as stream:
        preview_captions = {
            row["take"]: row["note"]
            for row in csv.DictReader(stream, delimiter=";")
            if row["album"] == batch["album"]
        }

    takes = {}
    with Path("incoming/camera-spool.jsonl").open(encoding="utf-8") as stream:
        for line in stream:
            if not line.strip():
                continue
            receipt = json.loads(line)
            take = takes.setdefault(receipt["take_id"], receipt)
            if not take["caption"]:
                take["caption"] = receipt["caption"]

    output = Path("delivery/album-manifest.csv")
    with output.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(("take_id", "file", "caption"))
        writer.writerows(
            (take_id, take["file"], take["caption"] or preview_captions.get(take_id, ""))
            for take_id, take in takes.items()
        )
    print(f"Wrote {len(takes)} album rows to {output}")


if __name__ == "__main__":
    export_album()
