import csv
from pathlib import Path
import shutil
import subprocess
import sys
from tempfile import TemporaryDirectory
import unittest


class ExportAlbumTest(unittest.TestCase):
    def test_harbor_walk_after_import_retry(self):
        root = Path(__file__).resolve().parent
        with TemporaryDirectory(dir=root) as directory:
            checkout = Path(directory)
            shutil.copytree(root / "incoming", checkout / "incoming")
            (checkout / "delivery").mkdir()

            subprocess.run(
                [sys.executable, "-B", str(root / "export_album.py")],
                cwd=checkout,
                check=True,
                capture_output=True,
                text=True,
            )

            with (checkout / "delivery/album-manifest.csv").open(
                encoding="utf-8", newline=""
            ) as stream:
                self.assertEqual(
                    list(csv.reader(stream)),
                    [
                        ["take_id", "file", "caption"],
                        ["hw-21", "IMG_6021.jpg", "Low tide, just before sunrise"],
                        ["hw-22", "IMG_6022.jpg", "São Miguel ferry berth"],
                        ["hw-23", "IMG_6023.jpg", 'Transom marked "Etta"'],
                        ["hw-24", "IMG_6024.jpg", "Buoys stacked for repainting"],
                    ],
                )


if __name__ == "__main__":
    unittest.main()
