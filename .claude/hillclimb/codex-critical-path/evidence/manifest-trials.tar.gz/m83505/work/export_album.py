import csv
import json
from pathlib import Path


def read_preview_captions():
    batch = json.loads(Path("incoming/batch.json").read_text(encoding="utf-8"))
    source = Path(batch["preview_sidecar"])
    with source.open(encoding="utf-8-sig", newline="") as stream:
        reader = csv.DictReader(stream, delimiter=";")
        if {"take", "note", "album"}.issubset(reader.fieldnames or []):
            return {
                row["take"]: row["note"]
                for row in reader
                if row["album"] == batch["album"] and row["note"]
            }

        stream.seek(0)
        reader = csv.DictReader(stream)
        if {"take_id", "caption"}.issubset(reader.fieldnames or []):
            return {row["take_id"]: row["caption"] for row in reader if row["caption"]}

    raise ValueError(f"Unrecognized caption sidecar header in {source}")


def export_album():
    files = {}
    captions = {}
    with Path("incoming/camera-spool.jsonl").open(encoding="utf-8") as stream:
        for line in stream:
            if not line.strip():
                continue
            receipt = json.loads(line)
            take_id = receipt["take_id"]
            files.setdefault(take_id, receipt["file"])
            if receipt.get("caption"):
                captions.setdefault(take_id, receipt["caption"])

    preview_captions = read_preview_captions() if len(captions) < len(files) else {}
    rows = []
    for take_id, file in files.items():
        caption = captions.get(take_id) or preview_captions.get(take_id)
        if not caption:
            raise ValueError(f"Missing caption for take {take_id}")
        rows.append((take_id, file, caption))

    output = Path("delivery/album-manifest.csv")
    with output.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(("take_id", "file", "caption"))
        writer.writerows(rows)
    print(f"Wrote {len(rows)} album rows to {output}")


if __name__ == "__main__":
    export_album()
