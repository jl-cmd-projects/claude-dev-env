import csv
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest


EXPORTER = Path(__file__).with_name("export_album.py").resolve()


class AlbumExportTest(unittest.TestCase):
    def test_retries_preserve_original_takes_and_captions(self):
        receipts = [
            {"take_id": "hw-21", "file": "IMG_6021.jpg", "caption": "Low tide, just before sunrise"},
            {"take_id": "hw-22", "file": "IMG_6022.jpg", "caption": "São Miguel ferry berth"},
            {"take_id": "hw-23", "file": "IMG_6023.jpg", "caption": 'Transom marked "Etta"'},
            {"take_id": "hw-22", "file": "retry.jpg", "caption": None},
        ]
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / "incoming").mkdir()
            (root / "delivery").mkdir()
            spool = root / "incoming/camera-spool.jsonl"
            spool.write_text("\n".join(json.dumps(row) for row in receipts), encoding="utf-8")
            original = hashlib.sha256(spool.read_bytes()).hexdigest()
            subprocess.run([sys.executable, "-B", str(EXPORTER)], cwd=root, check=True, capture_output=True)
            with (root / "delivery/album-manifest.csv").open(encoding="utf-8", newline="") as stream:
                reader = csv.DictReader(stream)
                self.assertEqual(reader.fieldnames, ["take_id", "file", "caption"])
                self.assertEqual(list(reader), receipts[:3])
            self.assertEqual(hashlib.sha256(spool.read_bytes()).hexdigest(), original)


if __name__ == "__main__":
    unittest.main()
