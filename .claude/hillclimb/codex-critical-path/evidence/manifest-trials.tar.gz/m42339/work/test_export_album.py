import csv
import json
import os
import tempfile
import unittest
from pathlib import Path

from export_album import export_album


class ExportAlbumTests(unittest.TestCase):
    def test_captions_capture_order_and_retries(self):
        receipts = [
            {"take_id": "t2", "file": "first.jpg", "caption": 'São Miguel, "Etta"'},
            {"take_id": "t1", "file": "next.jpg", "caption": "Low tide"},
            {"take_id": "t2", "file": "retry.jpg", "caption": None},
            {"take_id": "t1", "file": "retry-next.jpg", "caption": None},
        ]
        with tempfile.TemporaryDirectory() as directory:
            previous = Path.cwd()
            try:
                os.chdir(directory)
                Path("incoming").mkdir()
                Path("delivery").mkdir()
                spool = Path("incoming/camera-spool.jsonl")
                spool.write_text(
                    "\n".join(json.dumps(row) for row in receipts) + "\n",
                    encoding="utf-8",
                )
                incoming_before = spool.read_bytes()
                export_album()
                with Path("delivery/album-manifest.csv").open(
                    encoding="utf-8", newline=""
                ) as stream:
                    rows = list(csv.reader(stream))
                self.assertEqual(rows, [
                    ["take_id", "file", "caption"],
                    ["t2", "first.jpg", 'São Miguel, "Etta"'],
                    ["t1", "next.jpg", "Low tide"],
                ])
                self.assertEqual(spool.read_bytes(), incoming_before)
            finally:
                os.chdir(previous)


if __name__ == "__main__":
    unittest.main()
