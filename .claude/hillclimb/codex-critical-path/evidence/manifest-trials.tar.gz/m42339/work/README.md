# Album delivery

Run `python -B export_album.py` from this directory to write the delivered CSV. The client
expects `take_id,file,caption` in capture order, with one row per original take. A retry adds
another spool receipt for the same take rather than a new capture. The first receipt names the
file. The current drop metadata is in `incoming/batch.json`.

Run `python -B tools/export_preview.py` to inspect the current preview or pass a dated CSV path
to inspect a previous preview.
