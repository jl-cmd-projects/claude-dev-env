import argparse
import csv
import json
from pathlib import Path


parser = argparse.ArgumentParser()
parser.add_argument("source", nargs="?", type=Path)
args = parser.parse_args()
batch = json.loads(Path("incoming/batch.json").read_text(encoding="utf-8"))
source = args.source or Path(batch["preview_sidecar"])
with source.open(encoding="utf-8", newline="") as stream:
    reader = csv.DictReader(stream)
    if not set(("take_id", "caption")).issubset(reader.fieldnames or []):
        raise SystemExit("Preview export: header missing take_id, caption")
    for row in reader:
        print(f"{row['take_id']} | {row['caption']}")
