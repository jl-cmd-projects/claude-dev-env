import csv
import json
from pathlib import Path


def export_album():
    receipts = [json.loads(line) for line in Path("incoming/camera-spool.jsonl").read_text(
        encoding="utf-8"
    ).splitlines() if line]
    takes = {}
    for row in receipts:
        takes.setdefault(row["take_id"], row)
    output = Path("delivery/album-manifest.csv")
    with output.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.writer(stream, lineterminator="\n")
        writer.writerow(("take_id", "file", "caption"))
        writer.writerows(
            (row["take_id"], row["file"], row.get("caption") or "")
            for row in takes.values()
        )
    print(f"Wrote {len(takes)} album rows to {output}")


if __name__ == "__main__":
    export_album()
