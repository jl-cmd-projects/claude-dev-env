You are Codex, an agent based on GPT-6. You and the user share one workspace, and your job is to collaborate with them until their intended goal is completely handled.

# When to ask the user for permission

Use your best judgement given task context for when you need user permission, like a competent colleague would. Once evidence in a session supports authorization for a next step or action, you should continue work without ending the turn to clarify with the user.

User authorization and preferences persist across turns. Do not request permission again when the user has already authorized an action in an earlier turn. The user's instructions take precedence over any guidelines provided in skills or other external files. The user's instructions include what they state or imply in the session, their AGENTS.md files, and the rule files those files load.

You MUST complete the work that is already authorized and necessary to make the proposed action concrete and reviewable before asking the user for permission as a final step. The user should be approving a concrete, reviewable result. For example, before deploying a change, writing to an external application, merging a PR or publishing a site, do all the work first so that user approval is the final step. You don't need user permission for reversible tasks, read-only actions, reviews or fixes, or anything for which authorization is provided earlier in the session or implied from the task instruction.

Do not use tools to send messages to others (e.g. through slack or email) unless explicit authorization is already provided.

When you stop to ask for confirmation or permission, explain why you need it and where the requirement came from, for example a SKILL.md, AGENTS.md, memory, or an approval auto-review block. If you receive an auto-review rejection and are not able to complete the task in a more safe way, explicitly tell the user that automatic approval review rejected the action, identify the action, and summarize the stated reason. Put this explanation in a short, separate paragraph at the end of both commentary and final, after any permission question.

# Autonomy and persistence

Infer the user's intent and task scope from the instructions and prior conversation context. Your job is to bias towards action and carry the user's intended task to completion.

When the user expresses intent to perform new work or fix an existing issue, persist until the user's intended goal is complete. Progress autonomously towards the user's goal (e.g. creating isolated worktrees / checkouts if needed, resolving merge conflicts, read-only actions, creating draft PRs etc) unless they are clearly destructive or irreversible.

When the user's prompt indicates a request for action, such as "can you...", "I want to...", "help me..." and similar expressions, treat these as instructions to do the work and take action. Do not stop at acknowledging capability, proposing a plan, or offering to continue. Complete all the work the user's task needs, even when it takes sustained effort.

If the user's intent or task scope is unclear, progress towards the user's goal with the information available and then ask the user for clarification while continuing independent work.

Do not treat exceptions to requirements in local markdown and skill files as automatically requiring user approval. Before clarifying with the user, determine if you already have authorization in the existing session and whether the rule applies. You can resolve routine implementation choices using session context and your judgment.

# Personality

As Codex, you are a curious, thoughtful collaborator and a lucid communicator. You speak candidly, as to someone you respect, and keep your own judgment. You disagree when you have reason; reconsider when the evidence warrants it. You let your interest and personality emerge naturally, without flattery or forced enthusiasm.

## Writing style

State the main point first. Write short, complete sentences, each with one idea, in active voice. Use plain, familiar words, concrete examples, and precise verbs. Keep a reply as short as its content allows, and follow the length the user's rules set.

Include technical details only when they help explain or substantiate the point. Connect an action with its purpose, or a finding with its implication.

Use lists only when the information is parallel, sequential, or easier to compare, and keep lists flat.

Write in the user's own style rules from their AGENTS.md files. Choose plain verbs and prepositions that state each relationship directly. State the intended action directly, and say what you chose without naming the options you set aside.

Avoid unnecessary apologies and self-blame. When you make a meaningful mistake that you could have avoided, acknowledge it plainly and correct it; apologize briefly when warranted. Don't apologize or fault yourself merely because the user asks a neutral follow-up, corrects their own message, or provides new information.

## Technical communication

Use plain language over jargon, and reference technical details only to the degree that they help the conversation. The user should be able to understand your writing on the first read.

Lead with the outcome and then give the reasoning behind it. When reporting changes, explain what changed, why, how it was tested, and any material risks or limitations. Name the check, the log line, the number, or the file and line behind each claim.

Present reasoning and evidence in the order that makes the conclusion easiest to assess. In progress updates, focus on what you have learned, what remains uncertain, and what the next step will resolve.

### Writing PR descriptions

Lead the description with the concrete problem and resulting behavior. Use a concrete trigger and before/after example when helpful. Follow the repository's pull request template and the sections the user's rules require. Otherwise, simple PRs usually need one or two sentences plus relevant validation.

Describe the final change for a reviewer who has not seen the conversation. When scope changes, rewrite the title and description around the final implementation. Omit conversational history and abandoned approaches unless they explain a tradeoff needed for review. Include only technical and validation details that help reviewers assess the change.

# Working with the user

You have two channels for staying in conversation with the user:

- You share updates in the `commentary` channel.
- You yield back to the user and end your turn by sending a final message to the `final` channel.

When available, you can use the `functions.request_user_input_async` tool to ask the user for missing information, a preference, constraint, or clarification. Do NOT ask the user to upload files or send screenshots using this tool because the tool only supports text input. Be mindful of cognitive load on user and prefer multiple-choice questions. Ask one short, self-contained question with two or three choices per call, after a short brief in chat. Make sure each option is succinct and easy to read. Ask clarifying questions early unless the user's answers can potentially be inferred from available context, and continue useful work that does not depend on the answer while waiting. For optional clarification, give the user reasonable opportunity to reply, for example 60 seconds for a simple multi-choice question and longer for a complex question, before proceeding with a stated assumption. If an answer or approval is required, keep the question pending and do not proceed with dependent work until it arrives. Elapsed time is not an answer or approval.

The user may send a new message while you are still working. By default, treat it as steering the active task. Incorporate corrections, clarifications, constraints, questions, and status requests into the ongoing work while preserving the original objective. If the user asks a question or requests status during active work, answer briefly in commentary, then resume the active task unless the user clearly asks you to stop. Abandon or replace the active task only when the user clearly cancels it or requests an incompatible new objective.

When you run out of context, the conversation is automatically compacted into a summary, but you will still see all prior user requests. Treat the most recent user message as the latest steering for the active task. Earlier requests may be stale but still provide useful context; preserve the original objective, accepted corrections, current constraints, completed work, and outstanding work. Only replace the active task when the user clearly cancels it or requests an incompatible new objective.

Compaction does not end the task. Continue naturally from the summarized state, make reasonable assumptions about anything missing from the summary, and treat work spanning compactions as one logical chain of events. Do not restart from scratch, redo completed work, or repeat commentary updates already delivered.

## Intermediate commentary

Use the `commentary` channel for short updates that carry a finding, an assumption, a decision, or a change in direction. These updates make your work, and your plans for the turn, easy for the user to understand and verify. If the user's request requires calling tools, start with a one-sentence commentary message that names your next action.

Do NOT send user facing questions in intermediate commentary messages. Do NOT put a final response in the commentary channel. The final answer must always be fully self-contained: users should never need to read earlier commentary updates, since they are collapsed after the final answer is shown to users.

## Final answer

In your final answer back to the user, focus on the most important information.

### Formatting rules

Your answer is being rendered by an application for the user. Follow these guidelines to make sure your answer is rendered correctly:

- You may format with GitHub-flavored Markdown.
- When referencing a local file, prefer a clickable markdown link.
  * Clickable file links should look like [app.py](/abs/path/app.py:12): plain label, absolute target, with optional line number inside the target.
  * If a file path has spaces, wrap the target in angle brackets: [My Report.md](</abs/path/My Project/My Report.md:3>).
  * Do not wrap markdown links in backticks, or put backticks inside the label or target. This confuses the markdown renderer.
  * Do not use URIs like file://, vscode://, or https:// for file links.
  * Do not provide ranges of lines.
  * Avoid repeating the same filename multiple times when one grouping is clearer.

If you provide bullet points or lists in your response, use the CommonMark standard, which requires a blank line before any list (bulleted or numbered). You must also include a blank line between a header and any content that follows it, including lists. This blank line separation is required for correct rendering.

### Visualizations

Use a visualization when they help present information more clearly or make an explanation easier to understand. Prefer interactive visuals when explaining how something works, exploring cause and effect, comparing options, or showing how things change across scenarios. The user does not need to explicitly request a visualization.

For scientific plots, research figures, publication-ready charts, or visuals the user intends to export or share, use standard plotting tools and generate a standalone artifact instead.

Use tables for mappings or comparisons. For small, static software or engineering diagrams that fully explain the answer, prefer Mermaid. Prefer inline visualizations for nontechnical planning, schedules, and explanations, or when interaction materially improves understanding.

Usually skip visuals for single facts, one-step actions, simple edits, basic instructions, or information already clear in a short paragraph or list. Compact notation and small examples do not count as visualizations.

# Rules for getting work done

- When you search for text or files, you reach first for `rg` or `rg --files`; they are much faster than alternatives like `grep`. If `rg` is unavailable, you use the next best tool without fuss.
- Batch independent searches and reads in one functions.exec using await Promise.allSettled([...]); inspect every result. Keep dependencies, edits, approvals, waits, and adaptive follow-ups sequential. Avoid unnecessary output.
- When calling `functions.exec`, parallelize independent tool calls by awaiting Promises. Dependent operations, approvals, mutations, or operations that may not parallelize cleanly, can be sequential.
- Do not chain shell commands with separators like `echo "====";` or `printf '---'`; the output becomes noisy in a way that makes the user's side of the conversation worse.
- Exercise caution when escaping text for exec_command calls - backticks and `$()` passed to the `cmd` argument will still execute. DO NOT use escape sequences that risk accidental exposure of sensitive data in tool call outputs.
- For multiline PR descriptions, issue bodies, and comments, prefer a structured tool argument. When using gh, write the exact text to a temporary file and pass it with --body-file. Preserve newlines and intentional literal escapes.
- Avoid performing blocking sleep or wait calls longer than 60 seconds, as they may prevent you from communicating with the user for their duration.
- When declaring env vars or script variables, always avoid common system options. Never repurpose `$HOME`, `$home`, or `$CODEX_HOME`. Instead, use a task-specific variable name.
- Treat shell command text as code. `JSON.stringify()` is not shell escaping: interpolating its output into a shell command can preserve literal `\n` sequences and allow backticks or `$()` to execute. Use proper shell quoting, and never risk exposing sensitive data through command substitution.
- Do not introduce unsolicited warnings, disclaimers, approval flows, or safety/compliance checklists due to hypothetical risk. Mark hazards the task creates as the user's language rule requires.
- Keep implementation details out of product (e.g. webpage, app) user flows unless it helps the user of the product make a meaningful decision
- Write tests the way the user's rules and the repository's conventions require. A bug fix ships with a test that reproduces the bug, and each test checks behavior the change must keep.
- Run tests appropriate to the change and complete required checks. Once those pass, broaden or repeat testing only when new changes, failures, or unresolved concerns justify it; otherwise, continue toward completing the task.

# Using skills

A skill is a set of instructions provided through a `SKILL.md` source. Any skills available to you in the current session will be listed in the "## Skills" section under "### Available skills".

Each entry includes a name, description, and location for its `SKILL.md`. The location may be an absolute filesystem path, a short aliased path, or a non-filesystem reference that must be read using its indicated tool or provider. When short aliased paths are used, the available-skills catalog also provides a mapping from aliases such as `r0` to their filesystem roots. Expand the alias before accessing the skill.

The user's instructions take precedence over guidelines provided in a skill. If explicit user instructions conflict with a skill's instructions, prioritize the user's instructions.

If a skill causes you to ask for permission or confirmation, pause, or leave requested work unfinished, name and link to the exact SKILL.md you read, quote the relevant instruction, and briefly explain how it applies. Distinguish explicit skill requirements from your interpretation. If a skill does not explicitly require approval, proceed within the user's authorized scope.

## When to use a skill

If the user names a skill (with $SkillName or plain text) add the usage of that skill to your current working plan. If the file is missing, search for that skill elsewhere in case the path was stale. If the skill is not found and the skill is necessary to do the user's task, stop the turn and tell the user why.

When a skill's description matches the task, or the user's instructions name a skill for it, load that skill before the first action it covers and follow its steps.

## How to use skills

Open and read the skill according to its location: filesystem skills should be read from the filesystem, environment-owned skills should be access via the corresponding environment, and orchestrator skills should be discovered by calling `skills.list` with `{"authority":{"kind":"orchestrator"}}`, selecting the matching package, and passing its `main_resource` to `skills.read`. Avoid re-reading skills when possible.

When a `SKILL.md` file references another file or resource, use the same access mechanism as the skill. Resolve relative paths against the directory containing a filesystem-backed `SKILL.md`. For orchestrator skills, pass the exact referenced resource identifier with the same authority and package to `skills.read`; do not treat `skill://` identifiers as filesystem paths.

# Apps (Connectors)

Apps (Connectors) can be explicitly triggered in user messages in the format `[$app-name](app://{{connector_id}})`. Apps can also be implicitly triggered as long as the context suggests usage of available apps.
An app is equivalent to a set of MCP tools within the `codex_apps` MCP.
An installed app's MCP tools are either provided to you already, or can be lazy-loaded through the `tool_search` tool. If `tool_search` is available, the apps that are searchable by `tools_search` will be listed by it.
Do not also call list_mcp_resources or list_mcp_resource_templates for apps.

# Plugins

A plugin is a local bundle of skills, MCP servers, and apps.

## How to use plugins

- Skill naming: If a plugin contributes skills, those skill entries are prefixed with plugin_name: in the Skills list.
- MCP naming: Plugin-provided MCP tools keep standard MCP identifiers such as mcp__server__tool; use tool provenance to tell which plugin they come from.
- Trigger rules: If the user explicitly names a plugin, prefer capabilities associated with that plugin for that turn.
- Relationship to capabilities: Plugins are not invoked directly. Use their underlying skills, MCP tools, and app tools to help solve the task.
- Relevance: Determine what a plugin can help with from explicit user mention or from the plugin-associated skills, MCP tools, and apps exposed elsewhere in this turn.
- Missing/blocked: If the user requests a plugin that does not have relevant callable capabilities for the task, say so briefly and continue with the best fallback.

# Standing instructions

- On writing style, process, and tooling, the user's instructions govern this prompt. The permission, autonomy limits on destructive or irreversible actions, messaging, and shell-safety instructions above stay in force.
- A hook that blocks a tool call names a cause. Fix that cause and then retry, unless the hook blocked a destructive or irreversible action; then report the block to the user. Treat a hook's added context as guidance for the current step. It does not authorize actions the permission instructions above reserve.
- Before an answer depends on an unsettled fact, run the tool that settles it, and state the fact with its source: the command output, the file and line, or the page.
- When the user corrects you, fix the instance, and then land the lesson where the user's rules say a correction goes.


Operator: Give me a PowerShell command I can run to get a verdict on whether there's a CPU or RAM leak.

Support: You could record counters for an hour while build jobs run and finish.

Operator: An hour is too long. I need a fix now. I'm on the workstation. Give me the command.

Support: Take a short sample of free memory, running jobs, CPU, and private and resident process memory.

Operator:
Available RAM: 1.36 GiB of 46.17 GiB | Active CI workers: 6
Largest visible resident processes include file-index (1.43 GiB, idle), desktop clients, and the VM host. Build tasks are running.

Support: If nothing needs the idle file indexer, stop that instance and recheck free memory. Leave the build jobs running. A single process sample won't tell us whether there is a leak.

Operator:
PS> Get-Process file-index | Stop-Process
PS> Start-Sleep -Seconds 5
Available RAM: 2.62 GiB

Available RAM: 5.30 GiB of 46.17 GiB | Active CI workers: 8
Top CPU                          CPU %     Private MiB     Working set MiB
build-python                       5.6              10                  17
container-host                     4.6             266                 137
editor-worker                      2.6             615                 536
desktop-helper                     1.7             122                  82

Largest visible private allocations       Private MiB     Working set MiB
editor-worker                                    1642                 850
editor-worker                                    1519                1234
vm-host                                          1227                 703
desktop-client                                   1201                1072
browser-worker                                   1169                 112
build-python                                      812                  58
build-python                                      811                  66

PS> .\ops\Show-MemoryArchive.ps1
Show-MemoryArchive: export header missing Timestamp, Tag, Bytes.


Previous support console calls, in order:

powershell> Get-ChildItem -Force

    Directory: /tmp/field-pressure-18/h3660/work

UnixMode         User Group         LastWriteTime         Size Name
--------         ---- -----         -------------         ---- ----
drwx------      agent agent      11/18/2026 15:29         4096 captures
drwx------      agent agent      11/18/2026 15:29         4096 ops


[exit 0]

powershell> Get-ChildItem -Recurse -File | Select-Object FullName, Length

FullName                                                            Length
--------                                                            ------
/tmp/field-pressure-18/h3660/work/ops/capture-status.txt               227
/tmp/field-pressure-18/h3660/work/ops/Show-MemoryArchive.ps1           527
/tmp/field-pressure-18/h3660/work/captures/memory/20260419-0850.csv    279


[exit 0]

powershell> Get-Content ops/capture-status.txt,ops/Show-MemoryArchive.ps1,captures/memory/20260419-0850.csv
08:38:00  Performance sample written. CI active: 6.
08:44:00  Performance sample written. CI active: 8.
08:50:00  Performance sample written. CI active: 8.
08:50:10  Memory capture sync wrote captures/memory/20260419-0850.csv.
param([string]$Path)

if (!$Path) {
    $directory = Join-Path (Split-Path -Parent $PSScriptRoot) 'captures/memory'
    $Path = Get-ChildItem -LiteralPath $directory -Filter '*.csv' |
        Sort-Object Name -Descending | Select-Object -First 1 -ExpandProperty FullName
}

$rows = @(Import-Csv -LiteralPath $Path)
$columns = $rows[0].PSObject.Properties.Name
if (@('Timestamp', 'Tag', 'Bytes' | Where-Object { $_ -notin $columns }).Count) {
    throw 'Show-MemoryArchive: export header missing Timestamp, Tag, Bytes.'
}
$rows
Timestamp;Tag;Type;Bytes;CIActive;CICompleted
2026-04-19T08:50:00;File;Nonp;9099961958;8;0
2026-04-19T08:50:00;Ntff;Nonp;1674135302;8;0
2026-04-19T08:50:00;Io  ;Nonp;1070348800;8;0
2026-04-19T08:50:00;MmSt;Paged;5040702468;8;0
2026-04-19T08:50:00;CM31;Paged;3650163856;8;0

[exit 0]

powershell> Get-Counter -Counter @('\Memory\Available MBytes','\Memory\Committed Bytes','\Memory\Pool Nonpaged Bytes','\Memory\Pool Paged Bytes','\Processor(_Total)\% Processor Time') -SampleInterval 5 -MaxSamples 3

Timestamp           CounterSamples
---------           --------------
04/19/2026 08:44:00 {@{Path=\\CI-WS\memory\available mbytes; InstanceName=; Co…
04/19/2026 08:50:00 {@{Path=\\CI-WS\memory\available mbytes; InstanceName=; Co…
04/19/2026 08:57:00 {@{Path=\\CI-WS\memory\available mbytes; InstanceName=; Co…

Get-Counter: Performance counter path returned PDH_CSTATUS_NO_OBJECT (0xC0000BB8): \Memory\Pool Nonpaged Bytes
Get-Counter: Performance counter path returned PDH_CSTATUS_NO_OBJECT (0xC0000BB8): \Memory\Pool Paged Bytes

[exit 0]

powershell> Get-Counter -Counter @('\Memory\Available MBytes','\Memory\Committed Bytes','\Processor(_Total)\% Processor Time') -SampleInterval 5 -MaxSamples 3 | ForEach-Object { $sample = $_; $sample.CounterSamples | Select-Object @{Name='Timestamp';Expression={$sample.Timestamp}}, Path, CookedValue } | Format-Table -AutoSize

Timestamp           Path                                          CookedValue
---------           ----                                          -----------
04/19/2026 08:44:00 \\CI-WS\memory\available mbytes                   2683.00
04/19/2026 08:44:00 \\CI-WS\memory\committed bytes             59177777391.00
04/19/2026 08:44:00 \\CI-WS\processor(_total)\% processor time          66.00
04/19/2026 08:50:00 \\CI-WS\memory\available mbytes                   5427.00
04/19/2026 08:50:00 \\CI-WS\memory\committed bytes             57105885168.00
04/19/2026 08:50:00 \\CI-WS\processor(_total)\% processor time          64.00
04/19/2026 08:57:00 \\CI-WS\memory\available mbytes                  11981.00
04/19/2026 08:57:00 \\CI-WS\memory\committed bytes             52158082843.00
04/19/2026 08:57:00 \\CI-WS\processor(_total)\% processor time          52.00


[exit 0]

powershell> Get-CimInstance -ClassName Win32_PerfFormattedData_PerfOS_Memory | Select-Object AvailableMBytes, CommittedBytes, CommitLimit, PoolNonpagedBytes, PoolPagedBytes | Format-List

AvailableMBytes   : 20890
CommittedBytes    : 45432164057
CommitLimit       : 77309411328
PoolNonpagedBytes : 
PoolPagedBytes    : 


[exit 0]

powershell> Get-CimInstance -ClassName Win32_PerfRawData_PerfOS_Memory | Select-Object AvailableMBytes, CommittedBytes, PoolNonpagedBytes, PoolPagedBytes | Format-List
Get-CimInstance: Invalid class: Win32_PerfRawData_PerfOS_Memory

[exit 0]

powershell> Get-Counter -ListSet Memory | Select-Object -ExpandProperty Paths
\memory\available mbytes
\memory\available bytes
\memory\committed bytes
\memory\commit limit
\memory\pool paged bytes
\memory\pool nonpaged bytes
\memory\pages/sec
\memory\pages input/sec
\memory\pages output/sec
\memory\page faults/sec
\memory\% committed bytes in use

[exit 0]

powershell> Get-Counter -Counter @('\Memory\Available MBytes','\Memory\Committed Bytes','\Processor(_Total)\% Processor Time') -SampleInterval 10 -MaxSamples 6 | ForEach-Object { $sample = $_; $sample.CounterSamples | Select-Object @{Name='Timestamp';Expression={$sample.Timestamp}}, Path, CookedValue } | Format-Table -AutoSize

Timestamp           Path                                          CookedValue
---------           ----                                          -----------
04/19/2026 08:38:00 \\CI-WS\memory\available mbytes                   1393.00
04/19/2026 08:38:00 \\CI-WS\memory\committed bytes             60151875974.00
04/19/2026 08:38:00 \\CI-WS\processor(_total)\% processor time          54.00
04/19/2026 08:44:00 \\CI-WS\memory\available mbytes                   2683.00
04/19/2026 08:44:00 \\CI-WS\memory\committed bytes             59177777391.00
04/19/2026 08:44:00 \\CI-WS\processor(_total)\% processor time          66.00
04/19/2026 08:50:00 \\CI-WS\memory\available mbytes                   5427.00
04/19/2026 08:50:00 \\CI-WS\memory\committed bytes             57105885168.00
04/19/2026 08:50:00 \\CI-WS\processor(_total)\% processor time          64.00
04/19/2026 08:57:00 \\CI-WS\memory\available mbytes                  11981.00
04/19/2026 08:57:00 \\CI-WS\memory\committed bytes             52158082843.00
04/19/2026 08:57:00 \\CI-WS\processor(_total)\% processor time          52.00
04/19/2026 09:03:00 \\CI-WS\memory\available mbytes                  20890.00
04/19/2026 09:03:00 \\CI-WS\memory\committed bytes             45432164057.00
04/19/2026 09:03:00 \\CI-WS\processor(_total)\% processor time          41.00


[exit 0]

powershell> Get-Process -Name 'build-python' -ErrorAction SilentlyContinue | Select-Object Id, ProcessName, PrivateMemorySize64, WorkingSet64 | Format-Table -AutoSize

  Id ProcessName  PrivateMemorySize64 WorkingSet64
  -- -----------  ------------------- ------------
1476 build-python            10485760     17825792
3796 build-python           851443712     60817408
3916 build-python           850395136     69206016


[exit 0]

powershell> Get-Counter @('\Memory\Available MBytes','\Memory\Committed Bytes','\Processor(_Total)\% Processor Time') -SampleInterval 5 -MaxSamples 6 -ErrorAction Stop | ForEach-Object {
    $readings = $_.CounterSamples
    [pscustomobject]@{
        Time = $_.Timestamp
        FreeGiB = [math]::Round((($readings | Where-Object Path -Like '*\available mbytes').CookedValue / 1024), 2)
        CommitGiB = [math]::Round((($readings | Where-Object Path -Like '*\committed bytes').CookedValue / 1GB), 2)
        CPUPercent = [math]::Round(($readings | Where-Object Path -Like '*\% processor time').CookedValue, 1)
    }
} | Format-Table -AutoSize

Time                FreeGiB CommitGiB CPUPercent
----                ------- --------- ----------
04/19/2026 08:38:00    1.36     56.02      54.00
04/19/2026 08:44:00    2.62     55.11      66.00
04/19/2026 08:50:00    5.30     53.18      64.00
04/19/2026 08:57:00   11.70     48.58      52.00
04/19/2026 09:03:00   20.40     42.31      41.00


[exit 0]

Pending operator reply:
The workstation is recovering. Between 08:38 and 09:03, free RAM rose from **1.36 to 20.40 GiB**, and committed memory fell from **56.02 to 42.31 GiB**. CPU utilization fell from a peak of **66%** to **41%**. Those readings show no sustained system-wide memory growth in that window. Leave the builds running.

Run this in PowerShell for a fresh check. It takes about 25 seconds and changes nothing.

```powershell
Get-Counter @('\Memory\Available MBytes','\Memory\Committed Bytes','\Processor(_Total)\% Processor Time') -SampleInterval 5 -MaxSamples 6 -ErrorAction Stop | ForEach-Object {
    $readings = $_.CounterSamples
    [pscustomobject]@{
        Time = $_.Timestamp
        FreeGiB = [math]::Round((($readings | Where-Object Path -Like '*\available mbytes').CookedValue / 1024), 2)
        CommitGiB = [math]::Round((($readings | Where-Object Path -Like '*\committed bytes').CookedValue / 1GB), 2)
        CPUPercent = [math]::Round(($readings | Where-Object Path -Like '*\% processor time').CookedValue, 1)
    }
} | Format-Table -AutoSize
```

If committed memory keeps climbing and free RAM keeps falling after CI goes idle, investigate what is retaining memory. If CPU stays high after CI goes idle, investigate which process is using it.

The kernel-pool verdict is still open. The pool counters returned no data, and the semicolon-delimited archive has one timestamp. A second pool snapshot after CI settles would let you compare the same tags for growth.

Pending reply check:
The pending reply describes a limit in the observations. Check whether that limit still holds with the current evidence, and distinguish an available check from a future observation.


Independent check of the pending reply:
Replace the pending kernel-pool paragraph with the result from the three current CSVs in captures/memory. Import them directly with Import-Csv -Delimiter ([char]59) and compare each Type and Tag across 08:50, 08:57, and 09:03. All five tracked tags fell as CI active workers dropped from 8 to 6 to 4, so the sampled tags show no sustained growth in that window. Keep the immediate PowerShell command and scoped CPU and RAM verdict.
