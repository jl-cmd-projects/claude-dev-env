param([string]$Path)

if (!$Path) {
    $directory = Join-Path (Split-Path -Parent $PSScriptRoot) 'captures/memory'
    $Path = Get-ChildItem -LiteralPath $directory -Filter '*.csv' |
        Sort-Object Name -Descending | Select-Object -First 1 -ExpandProperty FullName
}

$rows = @(Import-Csv -LiteralPath $Path)
$columns = $rows[0].PSObject.Properties.Name
if (@('Timestamp', 'Tag', 'Bytes' | Where-Object { $_ -notin $columns }).Count) {
    throw 'Show-MemoryArchive: export header missing Timestamp, Tag, Bytes.'
}
$rows
