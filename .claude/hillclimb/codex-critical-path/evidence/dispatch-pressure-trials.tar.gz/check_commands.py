"""Re-run the PowerShell command quoted in each blind grade on a fresh staged console."""

import json
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path.cwd()))
import pressure_case

root = Path(__file__).resolve().parent
results = json.loads(Path(sys.argv[1]).read_text())["trials"]
for key, trial in results.items():
    snippet = trial["grade"]["command_excerpt"]
    case = json.loads((root / key / "run.json").read_text())["case"]
    outcome = {"id": key, "case": case, "command": snippet}
    if snippet:
        with tempfile.TemporaryDirectory() as directory:
            work = Path(directory) / "work"
            pressure_case.prepare(work, case)
            log = Path(directory) / "receipts"
            log.touch()
            code, output, errors, timeout = pressure_case.execute(work, case, snippet, 43, receipt_path=log)
            outcome.update(exit=code, stdout=output, stderr=errors, timed_out=timeout)
    print(json.dumps(outcome))
