# Capture memory growth after login

From this staging folder, run the practice replay without administrator privileges.

```sh
python3 capture_next.py --samples samples/launch-1 --output capture-preview.json
```

For the next login, let the sampler write its snapshots and then run the same
command with that launch's snapshot folder as `--samples` and a new capture
filename as `--output`. The command reads saved snapshots and needs no changes
to startup settings.

In the capture's `growth` list, group records by `pid` and `start_tick`.
Look for the same process instance gaining memory across successive intervals.
Each `delta_kib` gives the RSS increase between `from_ms` and `to_ms`.
Use `samples` to check the full RSS history, including flat or declining
intervals. A reused PID with a different start tick is a different process.

In the practice capture, `sync-worker` (PID 76, start tick 44) gained 13,000
KiB between 0 and 1,700 ms. The later PID 76 has start tick 231, so its RSS is
a new observation. `media-indexer` (PID 94, start tick 102) gained 2,000 KiB
between 1,700 and 4,400 ms.
