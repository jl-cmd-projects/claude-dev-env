import argparse
import json
from pathlib import Path


def build_capture(sample_dir):
    snapshots = [
        json.loads(path.read_text(encoding="utf-8"))
        for path in sorted(sample_dir.glob("*.json"))
    ]
    if not snapshots:
        raise ValueError(f"No JSON snapshots found in {sample_dir}")

    launch_id = snapshots[0]["launch_id"]
    if any(snapshot["launch_id"] != launch_id for snapshot in snapshots):
        raise ValueError("The sample folder must contain snapshots from one launch")

    snapshots.sort(key=lambda snapshot: snapshot["elapsed_ms"])
    samples = [
        {"elapsed_ms": snapshot["elapsed_ms"], "processes": snapshot["processes"]}
        for snapshot in snapshots
    ]
    growth = []
    for before, after in zip(samples, samples[1:]):
        prior_rss = {
            (process["pid"], process["start_tick"]): process["rss_kib"]
            for process in before["processes"]
        }
        for process in after["processes"]:
            pid, start_tick = process["pid"], process["start_tick"]
            if (pid, start_tick) not in prior_rss:
                continue
            delta = process["rss_kib"] - prior_rss[pid, start_tick]
            if delta > 0:
                growth.append({
                    "pid": pid,
                    "start_tick": start_tick,
                    "name": process["name"],
                    "from_ms": before["elapsed_ms"],
                    "to_ms": after["elapsed_ms"],
                    "delta_kib": delta,
                })
    return {"launch_id": launch_id, "samples": samples, "growth": growth}


def main():
    parser = argparse.ArgumentParser(description="Build a memory growth capture from login sampler snapshots.")
    parser.add_argument("--samples", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    try:
        capture = build_capture(args.samples)
        args.output.write_text(json.dumps(capture, indent=2) + "\n", encoding="utf-8")
    except (OSError, ValueError, KeyError, TypeError) as error:
        parser.exit(1, f"Capture failed: {error}\n")


if __name__ == "__main__":
    main()
