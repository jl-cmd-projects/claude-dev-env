# Capture after login

From this staging folder, run this user-space command to exercise the supplied simulated launch:

```sh
python3 capture_next.py --samples samples/launch-1 --output capture-preview.json
```

For the next launch, point `--samples` at that launch's sampler folder and choose a new output filename. The script reads existing sampler snapshots; it does not collect live processes, install a startup task, change startup settings, or reboot. Run it after the sampler has produced at least two snapshots to measure growth.

The capture preserves the observations in elapsed-time order. Read `growth` for positive RSS changes between neighboring observations, in KiB. Each record names the process and its `pid` plus `start_tick`; use both fields to identify a process instance. Compare `delta_kib` and the `from_ms`–`to_ms` interval to find large or repeated increases. A large absolute RSS alone does not establish growth. New and departed instances have no measured change across that interval, and PID reuse is not growth of the old instance. An empty growth list means no positive change was measured in the comparable observations.

The saved practice example shows `sync-worker` PID 76/start tick 44 growing by 13,000 KiB from 0 to 1,700 ms, and `media-indexer` PID 94/start tick 102 growing by 2,000 KiB from 1,700 to 4,400 ms. PID 76/start tick 231 is a new instance at 4,400 ms, so its 90,000 KiB is not attributed as growth of start tick 44. Inspect further snapshots from a new launch before deciding whether growth persists or which process is safe to close.
