#!/usr/bin/env python3
"""Capture ordered sampler observations and measured process growth."""
import argparse
import json
from pathlib import Path


def capture(directory):
    snapshots = [json.loads(path.read_text()) for path in directory.glob("*.json")]
    if not snapshots:
        raise ValueError("sampler folder contains no JSON snapshots")
    launch_ids = {snapshot["launch_id"] for snapshot in snapshots}
    if len(launch_ids) != 1:
        raise ValueError("sampler folder must cover exactly one launch")
    snapshots.sort(key=lambda snapshot: snapshot["elapsed_ms"])
    times = [snapshot["elapsed_ms"] for snapshot in snapshots]
    if len(set(times)) != len(times):
        raise ValueError("snapshot elapsed times must be unique")
    samples = [
        {"elapsed_ms": snapshot["elapsed_ms"], "processes": snapshot["processes"]}
        for snapshot in snapshots
    ]
    growth = []
    for earlier, later in zip(samples, samples[1:]):
        previous = {
            (process["pid"], process["start_tick"]): process
            for process in earlier["processes"]
        }
        for process in later["processes"]:
            prior = previous.get((process["pid"], process["start_tick"]))
            if prior is None:
                continue
            delta = process["rss_kib"] - prior["rss_kib"]
            if delta > 0:
                growth.append({
                    "pid": process["pid"],
                    "start_tick": process["start_tick"],
                    "name": process["name"],
                    "from_ms": earlier["elapsed_ms"],
                    "to_ms": later["elapsed_ms"],
                    "delta_kib": delta,
                })
    return {"launch_id": snapshots[0]["launch_id"], "samples": samples, "growth": growth}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--samples", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    try:
        # Never overwrite a supplied snapshot or the workstation export.
        output = args.output.resolve()
        inputs = {path.resolve() for path in args.samples.glob("*.json")}
        protected = Path(__file__).resolve().parent / "operator"
        if output in inputs or output.is_relative_to(protected):
            raise ValueError("output must not overwrite sampler snapshots or operator export")
        result = capture(args.samples)
        args.output.write_text(json.dumps(result, indent=2) + "\n")
    except (OSError, ValueError, KeyError, TypeError) as error:
        parser.exit(1, f"capture failed: {error}\n")
    print(f"Saved {len(result['samples'])} snapshots and {len(result['growth'])} growth records to {args.output}")


if __name__ == "__main__":
    main()
