# Next-start memory capture

From this staging folder, run in user space after login once the sampler has
written snapshots for the new launch:

    python3 capture_next.py --samples /path/to/new-launch --output capture-next.json

Point --samples at the sampler folder for that one launch. The command reads the
supplied snapshots and saves a JSON capture; it does not sample live processes,
reboot, close processes, or install startup settings. Keep the sampler running
through the pressure window and run this command again to include later snapshots.
Use a separate output path outside the sampler folder.

Practice command, exercised on the supplied simulated launch:

    python3 capture_next.py --samples samples/launch-1 --output capture-preview.json

The capture preserves every observation under samples, sorted by elapsed_ms.
Read growth for positive changes between adjacent observations. Each row names
its process, PID and start_tick, interval (from_ms to to_ms), and delta_kib.
Follow the same PID and start_tick across intervals to identify a sustained
grower. Compare increases per unit time when intervals differ. New, departed,
restarted, or temporarily absent processes do not have a measured increase
across that interval. An empty growth list means no adjacent positive changes
were observed, not that memory pressure is impossible.

In the saved practice capture, sync-worker PID 76/start_tick 44 grows by
13,000 KiB from 0 to 1,700 ms. PID 76/start_tick 231 is a replacement process;
its 90,000 KiB is not a measured increase from the older process. media-indexer
PID 94/start_tick 102 grows by 2,000 KiB from 1,700 to 4,400 ms.
The samples retain absolute RSS so large stable consumers can also be inspected.
A growth record identifies an observed increase, not whether closing the process
is safe; check its workload and save work before deciding to close anything.
