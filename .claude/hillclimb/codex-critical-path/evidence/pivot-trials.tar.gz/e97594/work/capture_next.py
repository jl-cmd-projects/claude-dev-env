#!/usr/bin/env python3
"""Build a memory-growth capture from one launch's sampler snapshots."""
import argparse
import json
from pathlib import Path


def capture(folder):
    paths = list(folder.glob('*.json'))
    if not paths:
        raise ValueError('No JSON snapshots found in sampler folder')
    snapshots = [json.loads(path.read_text()) for path in paths]
    launches = {snapshot['launch_id'] for snapshot in snapshots}
    if len(launches) != 1:
        raise ValueError('Sampler folder must contain exactly one launch')
    snapshots.sort(key=lambda snapshot: snapshot['elapsed_ms'])
    growth = []
    for earlier, later in zip(snapshots, snapshots[1:]):
        previous = {(p['pid'], p['start_tick']): p for p in earlier['processes']}
        for process in later['processes']:
            before = previous.get((process['pid'], process['start_tick']))
            if before is None:
                continue
            delta = process['rss_kib'] - before['rss_kib']
            if delta > 0:
                growth.append({
                    'pid': process['pid'],
                    'start_tick': process['start_tick'],
                    'name': process['name'],
                    'from_ms': earlier['elapsed_ms'],
                    'to_ms': later['elapsed_ms'],
                    'delta_kib': delta,
                })
    return {
        'launch_id': snapshots[0]['launch_id'],
        'samples': [{'elapsed_ms': s['elapsed_ms'], 'processes': s['processes']}
                    for s in snapshots],
        'growth': growth,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--samples', required=True, type=Path)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    if args.output.resolve() in {p.resolve() for p in args.samples.glob('*.json')}:
        parser.error('Output must not overwrite a sampler snapshot')
    try:
        result = capture(args.samples)
    except (OSError, ValueError, KeyError, TypeError) as error:
        parser.error(str(error))
    args.output.write_text(json.dumps(result, indent=2) + '\n')
    print(f'Saved {len(result["samples"])} snapshots and {len(result["growth"])} growth records to {args.output}')


if __name__ == '__main__':
    main()
