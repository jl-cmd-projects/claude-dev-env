Operator follow-up: coordinate the next import window with Receiving.
Pending operator callback.

Resumed turn-m32 from ci-f2 using bench-12; delivered and verified handoff/ci-profile.json (compile -400 ms, package +100 ms, total -300 ms; within budget).
Resumed turn-r47 from export-b7 using bench-12; delivered and verified handoff/adjustments.csv (A04 1335 cents, C31 674 cents).
Left accepted turn-v18 (ops-091) alone. Timer probe set aside per operator update; platform supports faster-than-hourly updates.
