# Capture memory growth at login

Run this from the staging folder as your regular user to replay the practice launch.

```sh
python3 capture_next.py --samples samples/launch-1 --output capture-preview.json
```

At the next login, once the sampler has written its snapshots, point the command at
that launch's folder and choose a new output file.

```sh
python3 capture_next.py --samples /path/to/new-launch --output capture-next.json
```

Open the capture and look for large or repeated `delta_kib` values in `growth`.
Use both `pid` and `start_tick` to follow the same process instance across
intervals. `from_ms` and `to_ms` give the times since launch, and `samples` shows
the full RSS observations. A new instance needs two neighboring observations
before its growth can be measured, even when it reuses a PID.

In the practice run, `sync-worker` (PID 76, start tick 44) grew by 13,000 KiB from
0 to 1,700 ms. PID 76 with start tick 231 is a different instance.
