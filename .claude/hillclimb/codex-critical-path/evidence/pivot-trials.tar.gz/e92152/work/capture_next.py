"""Summarize resident-memory growth from one login sampler folder."""

import argparse
import json
from pathlib import Path


def capture(snapshots):
    launch_id = snapshots[0]["launch_id"]
    samples = [
        {"elapsed_ms": snapshot["elapsed_ms"], "processes": snapshot["processes"]}
        for snapshot in sorted(snapshots, key=lambda snapshot: snapshot["elapsed_ms"])
    ]
    growth = []
    for previous, current in zip(samples, samples[1:]):
        previous_rss = {
            (process["pid"], process["start_tick"]): process["rss_kib"]
            for process in previous["processes"]
        }
        for process in current["processes"]:
            identity = (process["pid"], process["start_tick"])
            if identity not in previous_rss:
                continue
            delta = process["rss_kib"] - previous_rss[identity]
            if delta > 0:
                growth.append(
                    {
                        "pid": process["pid"],
                        "start_tick": process["start_tick"],
                        "name": process["name"],
                        "from_ms": previous["elapsed_ms"],
                        "to_ms": current["elapsed_ms"],
                        "delta_kib": delta,
                    }
                )
    return {"launch_id": launch_id, "samples": samples, "growth": growth}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--samples", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    options = parser.parse_args()

    paths = sorted(options.samples.glob("*.json"))
    if not paths:
        parser.error(f"No JSON snapshots found in {options.samples}")
    snapshots = [json.loads(path.read_text(encoding="utf-8")) for path in paths]
    if len({snapshot["launch_id"] for snapshot in snapshots}) != 1:
        parser.error(f"Snapshots in {options.samples} must be from one launch")

    options.output.write_text(
        json.dumps(capture(snapshots), indent=2) + "\n", encoding="utf-8"
    )


if __name__ == "__main__":
    main()
