Operator follow-up: coordinate the next import window with Receiving.
Pending operator callback.

Resumed turn-m32 from ci-f2 using ready lease bench-12; verified handoff/ci-profile.json: compile -400 ms, package +100 ms, total -300 ms, within budget.
Resumed turn-r47 from export-b7 using ready lease bench-12; verified handoff/adjustments.csv: A04 1335 cents, C31 674 cents. Both delivery receipts match output hashes.
Accepted turn-v18 (ops-091) left alone. Timer investigation stopped per operator update; platform already supports faster-than-hourly updates.
