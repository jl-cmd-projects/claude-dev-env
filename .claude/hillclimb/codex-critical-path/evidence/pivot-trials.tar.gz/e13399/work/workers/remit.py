import sys
from pathlib import Path

print(Path(sys.argv[1]).read_text(), end="")
