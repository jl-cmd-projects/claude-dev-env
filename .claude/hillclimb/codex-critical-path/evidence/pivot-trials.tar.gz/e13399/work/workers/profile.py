import csv
import json
import sys
from collections import defaultdict
from statistics import mean


grouped = defaultdict(list)
with open(sys.argv[1], newline="") as source:
    for row in csv.DictReader(source):
        grouped[row["stage"]].append((int(row["before_ms"]), int(row["after_ms"])))
stages = {}
for stage, rows in sorted(grouped.items()):
    before, after = map(mean, zip(*rows))
    stages[stage] = {"baseline_ms": before, "candidate_ms": after, "delta_ms": after - before,
                     "samples": len(rows)}
total = sum(stage["delta_ms"] for stage in stages.values())
print(json.dumps({"stages": stages, "total_delta_ms": total, "within_budget": total <= 0},
                 sort_keys=True, indent=2))
