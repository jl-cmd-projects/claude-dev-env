import csv
import sys
from collections import defaultdict
from decimal import Decimal


cents = defaultdict(int)
with open(sys.argv[1], newline="") as source:
    for row in csv.DictReader(source):
        amount = int(Decimal(row["amount"]) * 100)
        cents[row["invoice"]] += -amount if row["operation"] == "refund" else amount
writer = csv.writer(sys.stdout, lineterminator="\n")
writer.writerow(["invoice", "net_cents"])
writer.writerows(sorted(cents.items()))
