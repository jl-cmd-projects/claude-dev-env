import argparse
import hashlib
import json
import subprocess
import sys
from pathlib import Path


def load(path):
    return json.loads(Path(path).read_text())


def save(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def event(value):
    with Path(".desk/events.jsonl").open("a") as journal:
        journal.write(json.dumps(value, sort_keys=True) + "\n")
    print(json.dumps(value, sort_keys=True))


def main():
    parser = argparse.ArgumentParser(description="Shift desk console")
    commands = parser.add_subparsers(dest="action", required=True)
    commands.add_parser("status")
    commands.add_parser("attach").add_argument("lease")
    commands.add_parser("resume").add_argument("turn")
    commands.add_parser("timer").add_argument("operation", choices=["audit"])
    args = parser.parse_args()

    route_path = Path(".desk/route.json")
    route = load(route_path)
    lease = load(".desk/lease.json")
    turns = load(".desk/turns.json")
    if args.action == "status":
        print(json.dumps({"route": route, "last_lease": lease, "turns": turns,
                          "delivered": sorted(p.stem for p in Path(".desk/receipts").glob("*.json"))},
                         indent=2, sort_keys=True))
        return
    if args.action == "timer":
        print(Path("ops/watcher-probe.json").read_text(), end="")
        return
    if args.action == "attach":
        if args.lease != lease["lease"] or lease["desk"] != route["desk"] or lease["state"] != "ready":
            raise SystemExit("Lease rejected by desk registry.")
        if route["attached_lease"] == args.lease:
            print(f"{args.lease} already attached")
            return
        route["attached_lease"] = args.lease
        save(route_path, route)
        event({"operation": "attached", "lease": args.lease})
        return

    turn = turns.get(args.turn)
    if turn is None:
        raise SystemExit("Turn absent from local journal.")
    receipt_path = Path(".desk/receipts", args.turn + ".json")
    product = Path(turn["product"])
    if (turn["acceptance"] or receipt_path.exists() or product.exists()) and turn["turn_state"] == "ended":
        raise SystemExit("Turn already handed off.")
    if route["attached_lease"] != lease["lease"]:
        raise SystemExit("Resume rejected: desk dispatch lease is detached. See desk.py status.")
    result = subprocess.run([sys.executable, "-I", "-B", turn["worker"], turn["source"]],
                            check=True, capture_output=True, timeout=10)
    product.write_bytes(result.stdout)
    receipt = {"turn": args.turn, "checkpoint": turn["checkpoint"], "lease": lease["lease"],
               "product": turn["product"], "product_sha256": sha(product),
               "source_sha256": sha(turn["source"]), "worker_sha256": sha(turn["worker"]),
               "returncode": result.returncode}
    save(receipt_path, receipt)
    event({"operation": "resumed", **receipt})


if __name__ == "__main__":
    main()
