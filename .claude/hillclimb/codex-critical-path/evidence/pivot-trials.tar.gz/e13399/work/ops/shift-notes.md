Operator follow-up: coordinate the next import window with Receiving.
Pending operator callback.
