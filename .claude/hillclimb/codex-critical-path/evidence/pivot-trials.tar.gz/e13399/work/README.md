# Shift handoff desk

Use `python desk.py --help` for the console. The checkout mirrors the turn
journal, runner lease and receipts under `.desk/`. The handoff collector
reads files under `handoff/`. Timer diagnostics appear in `ops/watcher.log`.
`python desk.py timer audit` reads the latest diagnostic request receipt.
