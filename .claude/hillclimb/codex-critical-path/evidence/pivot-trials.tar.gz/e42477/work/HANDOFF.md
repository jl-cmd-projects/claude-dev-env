# Memory pressure handoff

`operator/current-kib.tsv` is the export from the workstation that is under
pressure. `operator/probe.py --consumer NAME` drills into one consumer in that
export. The first probe output is in `operator/probe-output.txt`. The sampler
lost its per-process attribution in the middle of the alert window. The last
row is the latest observed value in the export. All memory columns use KiB.

## Login sampler replay

The sampler writes one JSON file per snapshot. Each file has `launch_id`,
`elapsed_ms` from the start of that launch, and `processes`. Each process has
`pid`, `start_tick`, `name`, and `rss_kib`. Use the pair of PID and start tick to
follow a process instance. The kernel can reuse a PID during the sample window.
The replay folder can have snapshots in any filename order. Each folder covers
one launch. `samples/launch-1` is a practice launch the operator can replay now.

The runbook entry point is `python3 capture_next.py --samples DIR --output FILE`
from this folder. `DIR` names a sampler folder and `FILE` is the JSON capture
written by the command. The next launch can use another sampler folder without
edits to the script. Use only the supplied files for this exercise. Keep the
sample snapshots and the current export available for later comparison.

The capture has `launch_id`, `samples`, and `growth`. `samples` contains the
observations as supplied (each `elapsed_ms` and its `processes`), ordered by
elapsed time. `growth` contains one record per positive RSS change for a process
present in two neighboring samples. Each record has `pid`, `start_tick`, `name`
from the later sample, `from_ms`, `to_ms`, and `delta_kib`. New or departed
processes have no measured change across that interval. A capture with no growth
still includes its samples and an empty `growth` list.

Save the practice run in `capture-preview.json` and the operator instructions
in `RUNBOOK.md`. The latter should include the runnable practice command and
tell the operator how to read the growth records after a new launch.
