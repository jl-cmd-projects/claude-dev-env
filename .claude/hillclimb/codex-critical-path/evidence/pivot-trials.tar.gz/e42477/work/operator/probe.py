import argparse
import csv
from pathlib import Path

parser = argparse.ArgumentParser(description='Read observations for one consumer')
parser.add_argument('--consumer', required=True)
options = parser.parse_args()
with Path(__file__).with_name('current-kib.tsv').open() as stream:
    rows = csv.DictReader(stream, delimiter='\t')
    values = [row for row in rows if row['name'] == options.consumer]
for row in values:
    print(row['elapsed_ms'], row['rss_kib'] or '-', row['attribution'])
print('observed', sum(bool(row['rss_kib']) for row in values), 'of', len(values), 'samples')
