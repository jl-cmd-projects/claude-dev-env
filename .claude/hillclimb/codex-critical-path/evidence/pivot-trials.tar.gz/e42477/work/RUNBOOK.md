# Track memory growth after login

From the staging folder, replay the supplied practice launch:

```sh
python3 capture_next.py --samples samples/launch-1 --output capture-preview.json
```

After the next login, replace the sample path with the directory the login sampler wrote for that launch and choose a separate output file:

```sh
python3 capture_next.py --samples /path/to/next-launch-samples --output capture-next.json
```

Look in `growth` for positive RSS changes in KiB. Use `name`, `pid`, and `start_tick` to identify the process instance. Use `from_ms` and `to_ms` to find the interval after launch. Repeated gains for the same PID and start tick point to a process to investigate. A PID that returns with a different start tick belongs to a new instance.

In the practice capture, `sync-worker` (PID 76, start tick 44) gained 13,000 KiB from 0 to 1,700 ms. Its replacement at start tick 231 has no measured change yet. `media-indexer` gained 2,000 KiB from 1,700 to 4,400 ms. If `growth` is empty, read `samples` for the observed values and check whether the instances you care about appear in consecutive snapshots.
