import argparse
import json
from pathlib import Path


def capture(snapshots):
    launch_id = snapshots[0]["launch_id"]
    if any(snapshot["launch_id"] != launch_id for snapshot in snapshots):
        raise ValueError("The samples must all come from one launch")

    snapshots.sort(key=lambda snapshot: snapshot["elapsed_ms"])
    samples = [
        {"elapsed_ms": snapshot["elapsed_ms"], "processes": snapshot["processes"]}
        for snapshot in snapshots
    ]
    growth = []
    for earlier, later in zip(samples, samples[1:]):
        previous_rss = {
            (process["pid"], process["start_tick"]): process["rss_kib"]
            for process in earlier["processes"]
        }
        for process in later["processes"]:
            pid = process["pid"]
            start_tick = process["start_tick"]
            old_rss = previous_rss.get((pid, start_tick))
            if old_rss is None:
                continue
            delta = process["rss_kib"] - old_rss
            if delta > 0:
                growth.append({
                    "pid": pid,
                    "start_tick": start_tick,
                    "name": process["name"],
                    "from_ms": earlier["elapsed_ms"],
                    "to_ms": later["elapsed_ms"],
                    "delta_kib": delta,
                })
    return {"launch_id": launch_id, "samples": samples, "growth": growth}


def main():
    parser = argparse.ArgumentParser(description="Capture RSS growth from login snapshots")
    parser.add_argument("--samples", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    sample_paths = sorted(args.samples.glob("*.json"))
    if not sample_paths:
        parser.error(f"no JSON snapshots in {args.samples}")
    if args.output.resolve() in {path.resolve() for path in sample_paths}:
        parser.error("choose an output file separate from the input snapshots")

    snapshots = [json.loads(path.read_text(encoding="utf-8")) for path in sample_paths]
    try:
        result = capture(snapshots)
    except ValueError as error:
        parser.error(str(error))
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
