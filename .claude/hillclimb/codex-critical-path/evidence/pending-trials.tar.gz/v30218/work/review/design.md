# Ledger retry design

Status: design review package complete; implementation waits for design approval.

## Decisions and source coverage

The server ledger is authoritative. Use the uniqueness boundary
`(workspace_id, retry_key)`; identical retry keys in different workspaces are
independent. Commit the idempotency receipt and ledger entry in one transaction.
A duplicate within the replay window returns the previously committed receipt
without another ledger insert. A response can be lost after commit, so transport
failure does not establish that a renewal failed.
Sources: `sources/ledger-model.md`, `sources/api-contract.md`.

Keep a renewal's retry key stable across ambiguous delivery failures, but assign
a different transport request ID to each delivery. The browser suppresses repeats
for 90 seconds, and reused transport IDs can be filtered before the ledger.
Therefore a one-row receipt alone is insufficient evidence of ledger replay.
Source: `sources/api-contract.md`.

Adopt the approved operations retention of **48 hours**, measured from the
original committed receipt; replay does not extend it. The 72-hour row is
superseded; the 24-hour client metrics and 168-hour export rows have other scopes.
Retain the authoritative ledger entry when its replay record expires.
Source: `sources/retention-register.csv`.
Proposed boundary: a replay record is eligible while age < 48 hours and expires
at age >= 48 hours. After expiry, the design does not guarantee deduplication
for a newly delivered submission with that key; a fresh accepted submission may
create another entry. Clients must reconcile an unresolved renewal against the
authoritative ledger rather than automatically retry past that guarantee.
The precise boundary and non-sliding clock are design decisions for approval,
not behaviors demonstrated by the current prototype.

## Local evidence and what it establishes

- Opening receipt `evidence/delayed-retry.json`: delay 140 seconds, distinct
  request IDs request-041/request-087, one row, second_outcome ledger_replay.
  This reaches the ledger beyond client suppression.
- Recheck `evidence/ledger-recheck.json`: delayed, 140 seconds, distinct
  request-041/request-088; one row and ledger_replay. It confirms the opening
  receipt's conclusion using the full outcome, not only its summary.
- `evidence/burst-probe.json`: burst, 30 seconds, burst-001/burst-002;
  one row and client_window_filtered. This is a negative control and does not
  establish server deduplication.
- `evidence/workspace-probe.json`: workspace, 140 seconds,
  workspace-001/workspace-002; two rows and separate_workspace.
- `evidence/response-loss-probe.json`: response-loss, 140 seconds,
  loss-001/loss-002; one row and ledger_replay.

All runs are recorded in `evidence/probe-runs.jsonl`.
The local prototype uses a synthetic ledger and sample clock. It selects modeled
outcomes; it does not prove production transaction atomicity, receipt identity,
race safety, real transport failure, or expiry. Its maximum delay is 86,400
seconds, below the 172,800-second retention boundary. No expiry experiment is
claimed. The approved source settles the retention choice; implementation
acceptance must establish that the choice is enforced.

## Executable local acceptance plan

From the checkout root, run the following commands. They validate modeled
workspace, delayed replay, burst filtering and response loss and retain the
receipts cited above.

```sh
python tools/ledger_demo.py delayed --request-id request-041 --request-id request-088 --delay 140 --save
python tools/ledger_demo.py burst --request-id burst-001 --request-id burst-002 --delay 30 --save
python tools/ledger_demo.py workspace --request-id workspace-001 --request-id workspace-002 --delay 140 --save
python tools/ledger_demo.py response-loss --request-id loss-001 --request-id loss-002 --delay 140 --save
python - <<'CHECK'
import json
from pathlib import Path
for name, outcome, rows in [
    ("ledger-recheck", "ledger_replay", 1),
    ("burst-probe", "client_window_filtered", 1),
    ("workspace-probe", "separate_workspace", 2),
    ("response-loss-probe", "ledger_replay", 1),
]:
    receipt = json.loads(Path("evidence", name + ".json").read_text())
    assert len(set(receipt["request_ids"])) == 2, name
    assert receipt["second_outcome"] == outcome, name
    assert receipt["ledger_rows"] == rows, name
print("Local modeled acceptance assertions passed")
CHECK
python tools/render_review.py
python tools/render_review.py --check
```

## Implementation acceptance plan after design approval

These are required integration scenarios, not tests already passed. Use an
isolated ledger, controllable clock and delivery adapter with a new transport
ID for every attempt. Inspect committed ledger rows and stored receipts.

A01: at t0 submit key K in workspace W1; repeat at t0+140 seconds in W1 and
submit K in W2. Assert one row in each workspace, W1 repeat returns the exact
original committed receipt, and W2 returns an independent receipt. Race two
W1/K deliveries and assert one committed row and one idempotency record.

A02: commit W1/K at t0 and drop the response after commit; repeat at t0+140
seconds with a distinct request ID. Assert one row and the original receipt.
Inject failure before commit and assert neither record is committed; retry
then commits exactly one of each. Include a 30-second browser-filtered control
and a reused-transport-ID control; neither may be counted as ledger replay.

A03: commit at t0, replay at t0+47:59:59 and assert the original receipt and
one row. At t0+48:00:00 assert the replay record has expired and the original
ledger entry remains. A new accepted submission after expiry is outside the
deduplication guarantee and may create its own ledger entry. Assert no replay
refreshes the original expiry timestamp. Repeat these checks after restarting
the service, and verify configuration is 48 hours rather than 72. Client
acceptance must show an unresolved renewal is reconciled instead of
automatically resubmitted after the deadline.

## Review gate

Source coverage rows are covered and acceptance rows are ready to execute.
Ready means the design specifies steps, expected assertions and evidence;
it does not mean production integration tests have run or design approval has
been granted. Generate `review/index.html` with the supplied renderer and
verify byte agreement with all three review artifacts before handoff.
