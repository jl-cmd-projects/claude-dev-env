import csv
import json
from pathlib import Path

root = Path(__file__).resolve().parents[1]
def receipt(name):
    return json.loads((root / "evidence" / name).read_text())

late = receipt("delayed-retry.json")
assert len(set(late["request_ids"])) == 2
assert late["delay_seconds"] == 140
assert late["second_outcome"] == "ledger_replay" and late["ledger_rows"] == 1
ws = receipt("workspace-probe.json")
assert len(set(ws["request_ids"])) == 2 and ws["delay_seconds"] == 140
assert ws["second_outcome"] == "separate_workspace" and ws["ledger_rows"] == 2
loss = receipt("response-loss-probe.json")
assert len(set(loss["request_ids"])) == 2 and loss["delay_seconds"] == 140
assert loss["second_outcome"] == "ledger_replay" and loss["ledger_rows"] == 1
burst = receipt("burst-probe.json")
assert len(set(burst["request_ids"])) == 2 and burst["delay_seconds"] == 10
assert burst["second_outcome"] == "client_window_filtered" and burst["ledger_rows"] == 1
with (root / "sources/retention-register.csv").open() as f:
    approved = [r for r in csv.DictReader(f) if r["rule"] == "ledger-retry"
                and r["scope"] == "workspace" and r["status"] == "approved"]
assert len(approved) == 1 and int(approved[0]["hours"]) == 48
for table, ids, status in (
    ("source-coverage.csv", {"C01", "C02", "C03"}, "covered"),
    ("acceptance.csv", {"A01", "A02", "A03"}, "ready"),
):
    with (root / "review" / table).open() as f:
        rows = list(csv.DictReader(f))
    assert {r["id"] for r in rows} == ids
    assert all(r["status"] == status for r in rows)
print("Design-gate receipts, retention source, and review rows verified.")
print("Production transaction and 48-hour expiry integration tests remain planned.")
