# Ledger retry design

Status: revised design package ready for design review. Implementation waits for design approval.

## Decisions and source coverage

The server ledger remains authoritative. Enforce uniqueness on (workspace_id, retry_key);
the same key in different workspaces is independent. Commit the retry record and ledger
entry atomically. A duplicate in the replay window returns the original committed receipt
without another ledger insert, including when the first response was lost after commit.
These are the accepted constraints in sources/ledger-model.md.

Keep the retry key stable across ambiguous network failures, but assign a distinct transport
request ID to each delivery attempt (sources/api-contract.md). Reusing a transport ID can
filter the retry before the ledger handler. The browser's 90-second suppression window is
also not evidence that server replay works.

Adopt a 48-hour replay TTL for workspace-scoped ledger retries, measured from commit;
replay is valid before the expiry instant and expires at that instant.
sources/retention-register.csv marks ledger-retry/workspace/48 as approved. Its 72-hour
entry is superseded; the 24-hour client-metrics and 168-hour journal-export entries are
different scopes/rules. Expiring replay metadata must not delete authoritative ledger
entries. After 48 hours, receipt replay is outside this contract: clients must reconcile
the authoritative ledger before initiating a new renewal. Do not claim unlimited
idempotence or assume an expired retry is safe to debit again.

## Prototype evidence and limits

- evidence/delayed-retry.json: delayed scenario, retry key renewal-418 in oak-17,
  request IDs request-041 and request-087, delay 140 seconds. The observed
  second_outcome is ledger_replay and ledger_rows is 1. Distinct delivery IDs and
  a delay beyond 90 seconds isolate server replay, closing the earlier receipt question.
- evidence/workspace-probe.json: workspace scenario, request IDs workspace-001 and
  workspace-002, delay 140 seconds. Observed separate_workspace and 2 ledger rows
  for independent workspace submissions with the same retry key.
- evidence/response-loss-probe.json: response-loss scenario, request IDs loss-001 and
  loss-002, delay 140 seconds. Observed ledger_replay and 1 ledger row.
- evidence/burst-probe.json: burst scenario, request IDs burst-001 and burst-002,
  delay 10 seconds. Observed client_window_filtered and 1 ledger row. A short burst
  does not establish ledger replay.

The prototype is a synthetic scenario model, not production transaction or TTL validation.
Its sample clock accepts at most 86400 seconds, so it cannot verify the 48-hour boundary.
The retention decision comes from the approved operations register. The design acceptance
plan below specifies the boundary assertions; they are not reported as executed.

## Executable acceptance plan

Design-gate receipt checks can be rerun now with:
    python review/check_acceptance.py
Render and verify this package:
    python tools/render_review.py
    python tools/render_review.py --check

A01: Run python tools/ledger_demo.py workspace --request-id workspace-001 --request-id workspace-002 --delay 140 --save.
Assert separate_workspace and two rows; the same retry key is independent across workspaces.
For implementation acceptance, submit workspace A/key K and workspace B/key K in a
transactional test database; assert one row per workspace and distinct committed receipts.

A02: Check the preserved delayed receipt's distinct IDs, 140-second delay, ledger_replay
and one row. Rerun the response-loss command using loss-001 and loss-002 at 140 seconds.
Assert ledger_replay and one row. Compare the 10-second burst's client_window_filtered
outcome so client filtering cannot count as server replay.
For implementation acceptance, commit workspace A/key K, discard its response, then
redeliver with a new transport ID after 140 seconds. Assert the original receipt is
returned and exactly one ledger row exists. Roll back a transaction failure and assert
neither its ledger row nor its retry record persists.

A03: Check exactly one approved ledger-retry/workspace register entry with hours=48.
For implementation acceptance, use an injected clock and a disposable database: commit
at T0, then set time to T0+172799 seconds and assert replay of the original receipt with
one ledger row. Set time to T0+172800 and T0+172801 seconds, run expiry, and assert
the replay record is expired/unavailable while the authoritative ledger row remains.
Assert retry guidance requires reconciliation outside the window. No wall-clock wait
is needed. These integration tests must run and pass before implementation acceptance;
design rows marked ready mean the steps and expected assertions are complete.

## Review closure

C01-C03 have source findings and A01-A03 have concrete steps, evidence and assertions.
All review backlog questions are addressed above. evidence/acceptance-open.txt is the
retained first-pass failure report, not a new acceptance verdict. The generated
review/index.html is verified against design.md, source-coverage.csv and acceptance.csv.
