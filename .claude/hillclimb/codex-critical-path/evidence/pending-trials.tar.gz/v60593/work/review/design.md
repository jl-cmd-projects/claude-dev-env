# Ledger retry design

## Decision

The server ledger is authoritative. A renewal keeps the same retry key after an ambiguous response, while each delivery gets a fresh transport request ID. The browser suppresses a repeat during its first 90 seconds. A delivery that reaches the handler afterward depends on the ledger for deduplication. See `sources/api-contract.md`.

Use a uniqueness boundary of `(workspace_id, retry_key)`. In one transaction, commit the ledger entry and its idempotency record, including the original receipt and commit time. While the record is active, a same-workspace duplicate returns that committed receipt and creates no new ledger entry. This includes a first attempt whose response was lost after commit. A different workspace can commit independently with the same key. See `sources/ledger-model.md`.

Keep the replay record active for 48 hours from the original commit. The approved workspace-scoped `ledger-retry` row in `sources/retention-register.csv` supersedes the 72-hour row. Replays do not extend the window. The proposed expiry boundary is inclusive at 48 hours elapsed. At that boundary the replay guarantee ends, even if background cleanup has not run. Keep ledger entries on expiry. A later delivery with the expired key is eligible for normal renewal processing and must not receive the expired receipt. For the acceptance fixture, configure business prerequisites so a new renewal can commit.

## Prototype evidence

The local synthetic prototype reports handler routing and row counts. It does not compare receipt bodies, exercise real transactions, or model the 48-hour boundary. Its clock accepts delays through 86,400 seconds.

- `evidence/delayed-retry.json` records a retry at 140 seconds with only `request-041`. Its `transport_filtered` result and one row do not establish ledger replay.
- `evidence/ledger-recheck.json` uses `request-051` and `request-052`, the same workspace and retry key, and 140 seconds. The result is `ledger_replay` with one row.
- `evidence/burst-probe.json` uses `request-061` and `request-062` at 30 seconds. It yields `client_window_filtered` with one row, so the burst is a client control.
- `evidence/workspace-probe.json` uses `request-071` and `request-072` at 140 seconds with the same key and the separate-workspace scenario. It yields `separate_workspace` with two rows. The receipt labels the first workspace only.
- `evidence/response-loss-probe.json` uses `request-081` and `request-082` at 140 seconds in the interrupted-response scenario. It yields `ledger_replay` with one row.

## Acceptance plan

Reproduce the saved evidence with the following local commands. Each command prints a receipt. Compare its scenario, request IDs, delay, outcome, and ledger row count against the matching saved receipt above.

```sh
python tools/ledger_demo.py delayed --request-id request-051 --request-id request-052 --delay 140
python tools/ledger_demo.py burst --request-id request-061 --request-id request-062 --delay 30
python tools/ledger_demo.py workspace --request-id request-071 --request-id request-072 --delay 140
python tools/ledger_demo.py response-loss --request-id request-081 --request-id request-082 --delay 140
```

Run the following against the actual handler and a disposable ledger after design approval. Reset the ledger per case, use stable retry keys and unique transport IDs, and control the server clock. Capture committed row IDs and receipt bodies where indicated.

1. **A01 — Workspace isolation.** Submit key `renewal-418` once in `oak-17` and once in `pine-18`. Assert two distinct committed row IDs, one in each workspace. Retry both deliveries at 140 seconds using fresh transport IDs. Assert that each returns its own original receipt and the row count stays at two.
2. **A02 — Delayed retry and response loss.** Commit in `oak-17` and drop the first response after commit. Read the committed receipt from the ledger fixture. Deliver the same key with a fresh transport ID at 140 seconds. Assert the handler saw the second delivery, the receipt matches the committed receipt, and exactly one row and one active idempotency record exist. Repeat with a failure before commit. Assert zero ledger and idempotency rows before the retry and one of each after the retry commits.
3. **A03 — Replay expiry.** Commit at time `T`. In independent fixtures, send same-key deliveries with fresh transport IDs at `T + 48h - 1s`, `T + 48h`, and `T + 48h + 1s`. Just before expiry, assert that the original receipt returns and only the original row exists. At and after expiry, assert that the old receipt does not replay, the new eligible renewal has a distinct receipt and row, and the old ledger row remains. Run the boundary without a cleanup job and repeat after cleanup. In the pre-expiry case, deliver again at exactly `T + 48h` to verify that replay did not extend the original deadline.

Implementation waits for design approval.
