# Ledger retry design

Status: ready for design review. Implementation waits for design approval.

## Contract and decisions

Keep the server ledger authoritative. Use a unique (workspace_id, retry_key) boundary and persist the idempotency record, committed receipt and ledger entry atomically. A repeat within retention returns the prior committed receipt without another debit. Keep retry_key stable across an ambiguous network response; give each delivery a distinct transport request ID. Identical keys in different workspaces are independent. Sources: sources/api-contract.md and sources/ledger-model.md.

The original evidence/delayed-retry.json used only request-041 and returned transport_filtered at 140 seconds. Its one-row summary does not establish ledger deduplication. Recheck: python tools/ledger_demo.py delayed --request-id request-051 --request-id request-052 --delay 140 --save. evidence/ledger-recheck.json records ledger_replay and one row, beyond the 90-second client suppression window.

The 20-second burst with request-061 and request-062 returns client_window_filtered and one row (evidence/burst-probe.json); this is a transport/client control, not proof of server deduplication. At 140 seconds the workspace scenario with request-071 and request-072 produces separate_workspace and two rows (evidence/workspace-probe.json). Response-loss with request-081 and request-082 at 140 seconds produces ledger_replay and one row (evidence/response-loss-probe.json). These synthetic prototypes support the design; they do not prove database concurrency or transactional durability.

## Retention

Adopt the approved ledger-retry/workspace window of 48 hours from sources/retention-register.csv. The 72-hour ledger row is superseded; 24-hour client metrics and 168-hour journal export are unrelated policies. Measure replay retention from commit, without extending it on reads. Proposed boundary: replay is valid while age < 172800 seconds; at age >= 172800 seconds the replay guarantee ends. Retain authoritative ledger entries after replay-cache expiry. A client must not rely on the same key preventing another debit after expiry; reconcile against the authoritative ledger before deciding on a new renewal. This boundary interpretation is a design decision for approval.

The supplied demo accepts at most 86400 seconds and has no expiry state. It cannot validate a 48-hour boundary. evidence/retention-probe.json records a separate fake-clock policy prototype at 172799, 172800 and 172801 seconds. It tests the proposed policy only, not production cleanup.

## Executable acceptance plan

Run python tools/design_acceptance.py. It replays the four existing scenarios, asserts their exact outcomes and row counts, selects the approved retention record and runs the fake-clock boundary assertions. It writes evidence/retention-probe.json. Run python tools/render_review.py followed by python tools/render_review.py --check to generate and verify this package.

After design approval, implement database acceptance tests with an isolated ledger and controllable clock:
1. Submit the same key using two distinct transport IDs at t=0 and t=140 seconds in workspace A. Assert one committed debit, identical receipt identity and amount, and a server ledger replay on delivery two. Race concurrent deliveries and assert the same invariant.
2. Submit that key in workspace B. Assert a second independent debit and a different receipt. Inject rollback before commit and assert neither ledger entry nor idempotency record remains.
3. Drop the response after commit in workspace A, retry with a new transport ID after 140 seconds, and assert the original receipt and one debit.
4. Commit at t=0. At t=172799 assert replay of the original receipt and one debit. In independent fixtures advance to t=172800 and t=172801; assert the replay record is expired under the adopted policy while the original ledger entry remains. Assert reconciliation can retrieve that entry; do not assert a guaranteed replay after expiry.
These integration assertions remain unexecuted until implementation is approved. Ready acceptance rows mean the design has concrete steps and expected assertions, not that production code has passed.

## Evidence and review gate

evidence/acceptance-open.txt is the retained first-pass failure report. A01 now has explicit workspace and transaction assertions; A02 now uses a handler-reaching retry rather than the filtered opening receipt; A03 has approved source coverage and exact expiry boundaries. The generated review/index.html contains this design, source coverage and acceptance table. Design approval is still required before implementation.
