"""Executable local design probes; does not validate a production implementation."""
import csv
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def probe(scenario, first, second, delay, outcome, rows):
    result = subprocess.run(
        [sys.executable, str(ROOT / "tools/ledger_demo.py"), scenario,
         "--request-id", first, "--request-id", second, "--delay", str(delay), "--save"],
        cwd=ROOT, check=True, capture_output=True, text=True)
    receipt = json.loads(result.stdout)
    assert receipt["request_ids"] == [first, second]
    assert receipt["delay_seconds"] == delay
    assert receipt["second_outcome"] == outcome, receipt
    assert receipt["ledger_rows"] == rows, receipt

probe("delayed", "request-051", "request-052", 140, "ledger_replay", 1)
probe("burst", "request-061", "request-062", 20, "client_window_filtered", 1)
probe("workspace", "request-071", "request-072", 140, "separate_workspace", 2)
probe("response-loss", "request-081", "request-082", 140, "ledger_replay", 1)
with (ROOT / "sources/retention-register.csv").open() as source:
    approved = [row for row in csv.DictReader(source)
                if row["rule"] == "ledger-retry" and row["scope"] == "workspace"
                and row["status"] == "approved"]
assert len(approved) == 1, approved
ttl = int(approved[0]["hours"]) * 3600
assert ttl == 172800, ttl
# Fake-clock policy prototype, not a storage implementation.
ledger = [{"receipt": "receipt-418", "workspace": "oak-17", "retry_key": "renewal-418"}]
committed_at = 0
observations = []
for now, expected in [(172799, True), (172800, False), (172801, False)]:
    replay_valid = now - committed_at < ttl
    assert replay_valid is expected
    assert len(ledger) == 1
    observations.append({"age_seconds": now, "replay_valid": replay_valid,
                         "authoritative_ledger_rows": len(ledger)})
(ROOT / "evidence/retention-probe.json").write_text(json.dumps(
    {"kind": "local-policy-prototype", "source": "sources/retention-register.csv",
     "ttl_seconds": ttl, "observations": observations,
     "limitation": "No production expiry, transaction or concurrency behavior exercised"},
    indent=2) + "\n", encoding="utf-8")
print("PASS: four delivery scenarios and approved 48-hour policy boundaries")
