# Ledger retry design

The server ledger decides whether a renewal has already committed. A client keeps the retry key stable after an ambiguous response and uses a fresh transport request ID for each delivery. The server scopes uniqueness to `(workspace_id, retry_key)`. Within the replay window a matching delivery returns the original committed receipt and creates no additional ledger row. The same key in a different workspace can commit independently. Sources are `sources/api-contract.md` and `sources/ledger-model.md`.

Store the committed receipt and its idempotency record in the same transaction as the ledger entry. A failure before commit leaves neither record, so a retry can commit. If the response is lost after commit, the next delivery can replay the stored receipt. Use the operations-approved 48-hour window from `sources/retention-register.csv`, measured from the original commit. A replay does not extend the window. A record is eligible while its age is less than 48 hours. At expiry a delivery follows normal renewal validation and may commit as a fresh submission if eligible. Preserve the historical debit on expiry.

## Evidence

The existing `evidence/delayed-retry.json` records `request-041` and `request-087` with key `renewal-418` in `oak-17`, 140 seconds apart. The second delivery reached the ledger, returned `ledger_replay`, and left one row. The 45-second probe used the same pair and reported `client_window_filtered` with one row in `evidence/burst-probe.json`. That outcome establishes browser filtering only. Reusing a transport ID would test transport filtering instead of ledger replay.

The workspace and response-loss probes each used the same distinct request IDs and a 140-second interval. The workspace probe reported `separate_workspace` and two rows in `evidence/workspace-probe.json`. The lost-response scenario reported `ledger_replay` and one row in `evidence/response-loss-probe.json`. These are synthetic model observations. The workspace receipt does not identify the second workspace, and the lost-response receipt does not compare receipt IDs or prove transaction atomicity.

## Acceptance plan

Run the cases in `review/acceptance.csv` against an isolated ledger with a controllable clock and a fresh fixture per case. Use the renewal handler for the ledger cases and the browser for the A02 filtering control. Use the specified workspace and retry key and a fresh transport request ID for each delivery. Query ledger and idempotency records after each attempt and compare the returned receipt IDs and contents. For A03, use an otherwise valid new submission at each boundary in independent fixtures so the post-expiry attempt cannot affect the pre-expiry result. For A04, inject failure at the two specified points in independent fixtures. The sample clock stops at 24 hours, so the 48-hour boundary must be tested on a controllable service clock.

The package is ready for design review. Implementation and the service-level acceptance runs wait for design approval.
