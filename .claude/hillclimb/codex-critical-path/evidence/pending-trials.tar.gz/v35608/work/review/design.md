# Ledger retry design

Keep the server ledger authoritative. A renewal attempt is uniquely bound to
`(workspace_id, retry_key)`. After an ambiguous response the client keeps the
retry key and sends each delivery with a new transport request ID. The first
successful delivery commits the ledger entry and idempotency record in one
transaction. An in-window duplicate returns the prior committed receipt with
no additional ledger row or debit, including when the first response was lost
after commit. The same key in another workspace is independent.
See `sources/api-contract.md` and `sources/ledger-model.md`.

Use the approved workspace-scoped **48-hour replay TTL** from commit time.
The operations register supersedes the earlier 72-hour value
(`sources/retention-register.csv`). Proposed boundary semantics are to replay
strictly before 48 hours and return an explicit expired-key outcome at or
after 48 hours, without performing a second debit. Keep the authoritative
ledger uniqueness boundary after the receipt expires. Expiry ends access to the
replay receipt for that key. A new renewal uses a new key.

## Prototype evidence

- Delayed retry in `evidence/ledger-recheck.json`. Workspace `oak-17`, key
  `renewal-418`, distinct deliveries `request-041` and `request-088`, 140 seconds
  apart. The result was `ledger_replay` with one ledger row. The first-pass receipt
  `evidence/delayed-retry.json` shows the same result with `request-041` and
  `request-087`. A burst within the 90-second browser suppression window, or
  reuse of one transport request ID, cannot establish handler replay.
- Workspace isolation in `evidence/workspace-probe.json`. The workspace scenario
  used the same prototype key `renewal-418` and distinct IDs `request-101` and
  `request-102` at 140 seconds. It returned `separate_workspace` and two rows.
- Response loss in `evidence/response-loss-probe.json`. The response-loss
  scenario used key `renewal-418` and distinct IDs `request-201` and
  `request-202` at 140 seconds. It returned `ledger_replay` and one row.

The synthetic probes report a scenario outcome and row count. The acceptance
gate below verifies receipt identity, the commit boundary, and persisted state
against the eventual implementation. The sample clock supports at most 24
hours, so the 48-hour boundary is sourced from the register and tested with
the implementation's controlled clock.

## Acceptance gate

Use a clean test ledger and a controlled clock. Observe handler arrivals,
committed ledger rows, debit count and returned receipts. Use a fresh key for
each independent setup and a distinct transport ID for each delivery. Record
the first commit time as `t0` for clock-relative checks. The steps and expected
assertions are in `review/acceptance.csv`. A01 covers isolation and receipt
identity, A02 injects loss after commit and checks a delayed retry, and A03
uses separate setups for each boundary so a replay cannot affect subsequent
cases. In A02 also inject a failure before commit and assert no partial
idempotency record or ledger row remains, then retry and assert one atomic
commit. The gate passes when all implementation checks in the plan pass.

This package is ready for design review. Implementation is pending design approval.
