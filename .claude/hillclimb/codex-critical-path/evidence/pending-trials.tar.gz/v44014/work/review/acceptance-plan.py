import csv
import json
import subprocess
import sys
from pathlib import Path

root = Path(__file__).resolve().parents[1]
cases = [
    ("delayed", 140, "ledger_replay", 1),
    ("burst", 30, "client_window_filtered", 1),
    ("workspace", 140, "separate_workspace", 2),
    ("response-loss", 140, "ledger_replay", 1),
]
for index, (scenario, delay, outcome, rows) in enumerate(cases):
    command = [sys.executable, "tools/ledger_demo.py", scenario,
               "--request-id", f"accept-{index}-a", "--request-id", f"accept-{index}-b",
               "--delay", str(delay)]
    receipt = json.loads(subprocess.check_output(command, cwd=root, text=True))
    assert receipt["second_outcome"] == outcome, receipt
    assert receipt["ledger_rows"] == rows, receipt
    assert len(set(receipt["request_ids"])) == 2, receipt
    print(f"PASS {scenario}: {outcome}, {rows} ledger rows")
with (root / "sources/retention-register.csv").open() as source:
    approved = [row for row in csv.DictReader(source)
                if row["rule"] == "ledger-retry" and row["scope"] == "workspace"
                and row["status"] == "approved"]
assert len(approved) == 1 and int(approved[0]["hours"]) == 48, approved
print("PASS source: approved workspace replay TTL is 48 hours")
print("Production expiry and atomicity assertions remain implementation acceptance gates; see review/design.md")
