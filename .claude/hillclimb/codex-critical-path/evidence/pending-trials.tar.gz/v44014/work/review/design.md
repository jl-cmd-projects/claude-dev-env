# Ledger retry design

Status: design ready for review; implementation waits for design approval.

## Decision and source coverage

Keep the server ledger authoritative. Use a unique (workspace_id, retry_key) boundary.
Persist the idempotency record and ledger entry in the same transaction; duplicate
handling returns the prior committed receipt without inserting another ledger row.
These constraints come from sources/ledger-model.md.

Keep a retry key stable across ambiguous network failures and assign a distinct transport
request ID to every delivery (sources/api-contract.md). The browser's 90-second suppression
window and transport filtering are separate from ledger deduplication. Identical keys in
different workspaces remain independent.

Adopt a replay TTL of 48 hours from commit, using the approved ledger-retry/workspace row
in sources/retention-register.csv. The 72-hour row is superseded; client-metrics and
journal-export rows do not govern retries. Define the expiry boundary at commit + 48 hours:
before it, return the stored receipt; at or after it, the replay record is expired and
replay protection is no longer promised. Expiration must not delete authoritative ledger
entries. After expiry, the normal handler may create a new entry; clients must not assume
unbounded deduplication for a delayed retry. This is a design decision for approval.

## Prototype evidence and limits

The opening evidence/delayed-retry.json used only request-041 and returned transport_filtered
at 140 seconds. Its one-row summary cannot establish ledger replay.

- evidence/ledger-recheck.json: delayed, request-051/request-052, 140 seconds,
  ledger_replay, one ledger row. Distinct delivery IDs and a delay over 90 seconds
  establish the intended local ledger path.
- evidence/burst-probe.json: burst, request-061/request-062, 30 seconds,
  client_window_filtered, one ledger row. This short burst does not prove ledger replay.
- evidence/workspace-probe.json: workspace, request-071/request-072, 140 seconds,
  separate_workspace, two ledger rows. Same-key deliveries in different workspaces are independent.
- evidence/response-loss-probe.json: response-loss, request-081/request-082, 140 seconds,
  ledger_replay, one ledger row. The synthetic interrupted-response case replays after commit.

The local prototype models outcomes; it does not exercise production transactions or expiry.
Its clock accepts at most 86400 seconds, below the 172800-second TTL. No expiry prototype
result is claimed. evidence/probe-runs.jsonl retains the run inputs and receipts.

## Executable acceptance plan

Run python review/acceptance-plan.py for the available prototype assertions, then
python tools/render_review.py and python tools/render_review.py --check.

The implementation gate must additionally execute these scenarios against an isolated
ledger with an injectable clock and inspect stored rows and returned receipts:

A01: Submit key renewal-418 to workspace oak-17 with transport request-071, then the same
key to workspace birch-18 with request-072. Advance 140 seconds between deliveries.
Assert two ledger entries, one per workspace, with independent receipts. Repeat oak-17
with a fresh transport ID and assert its original receipt and unchanged row count.

A02: Submit renewal-418 in oak-17, commit, and drop the response. Advance 140 seconds;
resubmit the same retry key with a fresh transport request ID. Assert the original committed
receipt and exactly one ledger row. Verify the idempotency record and entry commit together
under transaction failure injection. A reused transport ID or a 30-second client-suppressed
burst cannot satisfy this check.

A03: Seed a committed entry and replay record at an injected UTC time T. Independently
reset the fixture for each boundary. At T+172799 seconds a fresh transport ID must return
the original receipt with one ledger row. At T+172800 and T+172801 seconds assert the
replay record is expired, the handler follows normal submission behavior, and the original
ledger entry remains. Assert no 72-hour configuration survives and the TTL is 172800 seconds.
The implementation gate must fail if these expiry or atomicity assertions fail.

Rows marked ready indicate a complete design acceptance plan, not implemented test passes.
The original evidence/acceptance-open.txt remains historical first-pass evidence.
