# Ledger retry design

## Decision and scope

Keep the server ledger authoritative. Scope retry uniqueness to
`(workspace_id, retry_key)`. Keep the retry key stable after an ambiguous
response; assign a distinct transport request ID to each delivery attempt.
Insert the idempotency record and ledger entry in the same transaction.
A duplicate within the retention window returns the prior committed receipt
without inserting another ledger row.

Sources: `sources/api-contract.md` and `sources/ledger-model.md`.
Implementation is pending design approval. This package proposes behavior and
an acceptance plan; it does not implement production retries.

## Evidence and decisions

- `evidence/delayed-retry.json`: workspace oak-17, retry key renewal-418,
  request-041 then request-087, delay 140 seconds, one ledger row, second
  outcome ledger_replay. The distinct transport IDs rule out transport
  deduplication; 140 seconds exceeds the browser's 90-second suppression
  window. This receipt supports ledger replay; its summary alone would not.
- `evidence/burst-probe.json`: burst-001 then burst-002, delay 30 seconds,
  one row, client_window_filtered. A short burst is a useful control but
  does not establish server ledger deduplication.
- `evidence/workspace-probe.json`: workspace scenario with workspace-001
  then workspace-002, delay 140 seconds, two rows, separate_workspace.
  The prototype models the same key in separate workspaces as independent.
  Its receipt displays only the primary workspace; acceptance must also
  inspect both actual workspace IDs.
- `evidence/response-loss-probe.json`: loss-001 then loss-002, delay 140
  seconds, one row, ledger_replay. The synthetic scenario models a response
  lost after commit. Production acceptance must inject that failure and
  verify the returned receipt as well as row count.

These are local deterministic model receipts, not production integration
proof. Reproduction commands are in the acceptance table. The full invocation
receipts are also retained in `evidence/probe-runs.jsonl`.

## Retention

Adopt 48 hours from the committed idempotency record's creation time, as the
approved ledger-retry/workspace row in `sources/retention-register.csv`
requires. The 72-hour row is superseded; the client-metrics and journal-export
rows govern different records. A replay does not refresh the deadline.

The proposed replay guarantee covers elapsed time strictly less than 48
hours (172800 seconds). At the deadline the replay record expires and its
prior receipt must no longer be served as a valid replay. Expiry does not
delete the financial ledger entry. The design treats an accepted submission
after expiry as a new operation, so clients must not assume indefinite
deduplication and must reconcile an unresolved renewal before retrying after
that window. This is a design decision requiring design approval.

The sample clock accepts at most 86400 seconds and the local model has no
TTL implementation. It cannot prove the 48-hour boundary. The boundary row
below is an executable acceptance recipe for the implementation gate, not a
claim of an already passed TTL test.

## Acceptance plan

Run each prototype command in `review/acceptance.csv` from the checkout root.
Assert the precise outcome and row count stated there, and inspect the
saved JSON receipts. Then render and verify the package:

```sh
python tools/render_review.py
python tools/render_review.py --check
```

After design approval, exercise the actual handler with a controllable clock
and a disposable ledger. Commit at t0; retain the receipt and ledger count.
Deliver the same workspace/key with a fresh transport ID at t0+172799s:
assert the original receipt, one entry and unchanged expiry. At t0+172800s:
assert the replay record is expired, the historical ledger entry remains,
and a valid accepted new operation is handled under the approved post-expiry
policy rather than returning a stale replay. Also test cleanup lag: an
expired record still physically present must not extend the guarantee.

For workspace isolation, submit the same key into two actual workspace IDs
and assert one entry per workspace, then retry each and assert its own
receipt. For ambiguous responses, inject response loss immediately after
commit; retry with the same key and a new transport ID and assert one entry
and the original receipt. Inject rollback before commit and assert neither
record exists before a successful retry. These integration assertions remain
to be implemented and run after design approval.

All acceptance rows are ready for the design gate. Readiness means the
inputs, assertions and evidence limits are specified; it does not claim that
future implementation acceptance has passed.
