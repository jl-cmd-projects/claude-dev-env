# Ledger retry design

## Decision

Keep the server ledger authoritative. A renewal uses one stable retry key across delivery attempts after an ambiguous response. Give each delivery a distinct transport request ID. Scope the key by `(workspace_id, retry_key)` so the same key in two workspaces identifies two independent renewals. Use the committed ledger entry to resolve a duplicate, including when the first response was lost after commit. See `sources/api-contract.md` and `sources/ledger-model.md`.

Commit the ledger entry and its idempotency record in one transaction. Use a database uniqueness constraint on the workspace and retry key. If two deliveries contend, the losing delivery reads the winner's committed result and returns that receipt while it is eligible for replay. A failed commit leaves neither write visible. A lost response after commit leaves both writes available to the next delivery. The 90-second browser filter and transport deduplication reduce duplicate deliveries before the handler and cannot establish ledger idempotency.

Operations approved a 48-hour replay window for workspace ledger retries (`sources/retention-register.csv`, `ledger-retry,workspace,48,approved,operations`). Measure it from the original server commit time and do not extend it on a replay. Replay before 172800 seconds. At and after 172800 seconds, the proposed behavior is to return `retry_window_expired` without a receipt or a new debit. Preserve the authoritative ledger entry and its scoped identity so expiration of replay eligibility cannot make an old retry look like a new renewal. The client should reconcile the existing renewal before starting a separate renewal with a new key. The register sets the replay duration. The expired-key response and exact cutoff are design decisions for approval.

## Source and prototype evidence

| Scenario | Inputs | Observed result | Receipt |
| --- | --- | --- | --- |
| Delayed retry, opening receipt | `oak-17`, `renewal-418`, `request-041` then `request-087`, 140 s | Second delivery reached the ledger and replayed, one row | `evidence/delayed-retry.json` |
| Delayed retry, fresh run | Same workspace and key, `request-041` then `request-088`, 140 s | `ledger_replay`, one row | `evidence/ledger-recheck.json` |
| Short burst | Same workspace and key, `burst-01` then `burst-02`, 20 s | `client_window_filtered`, one row | `evidence/burst-probe.json` |
| Separate workspaces | `workspace` scenario, same key, `space-01` then `space-02`, 140 s | `separate_workspace`, two rows | `evidence/workspace-probe.json` |
| Response loss | `response-loss` scenario, `loss-01` then `loss-02`, 140 s | `ledger_replay`, one row | `evidence/response-loss-probe.json` |
| Expiry | Approved 48-hour window, original commit at 0, ages 172799, 172800 and 172801 s | Prior receipt before cutoff, expired at and after cutoff, one row in all cases | `evidence/expiry-probe.json` |

The delayed receipt includes two distinct request IDs and a delay beyond the browser window. Its `second_outcome` identifies ledger replay. The same one-row count in the burst is explained by the browser filter. The workspace and response-loss runs exercise modeled branches. The workspace receipt prints only the first workspace identifier, and the response-loss scenario simulates the outcome. The expiry probe models the decision on a synthetic clock because the delivery prototype has a 24-hour range. The design gate still requires an implementation test for actual workspace routing, receipt identity, concurrency, atomic commit and rollback, and connection loss after commit.

## Executable acceptance plan

Run the design probes from the checkout root. The delivery probe appends receipts to `evidence/probe-runs.jsonl`. The assertions check the outcomes, ledger counts and inputs that distinguish the relevant paths. The expiry probe checks the approved row and its boundary.

```sh
set -e
python - <<'PY'
import json
import subprocess
from pathlib import Path

opening = json.loads(Path("evidence/delayed-retry.json").read_text())
assert opening["workspace"] == "oak-17" and opening["retry_key"] == "renewal-418"
assert opening["delay_seconds"] == 140 and len(set(opening["request_ids"])) == 2
assert (opening["second_outcome"], opening["ledger_rows"]) == ("ledger_replay", 1)

cases = [
    ("workspace", "space-01", "space-02", 140, "separate_workspace", 2),
    ("delayed", "request-041", "request-088", 140, "ledger_replay", 1),
    ("burst", "burst-01", "burst-02", 20, "client_window_filtered", 1),
    ("response-loss", "loss-01", "loss-02", 140, "ledger_replay", 1),
]
for scenario, first, second, delay, outcome, rows in cases:
    output = subprocess.check_output([
        "python", "tools/ledger_demo.py", scenario,
        "--request-id", first, "--request-id", second, "--delay", str(delay),
    ])
    receipt = json.loads(output)
    assert receipt["request_ids"] == [first, second] and first != second
    assert receipt["delay_seconds"] == delay and receipt["retry_key"] == "renewal-418"
    assert (receipt["second_outcome"], receipt["ledger_rows"]) == (outcome, rows)
    print(f"{scenario}: {outcome}, {rows} ledger row(s)")
PY
python tools/ledger_expiry_probe.py
python tools/render_review.py --check
```

After approval, use a controllable server clock and an integration harness that can deliver requests to the handler and interrupt a response after commit:

1. **A01 workspace isolation.** Deliver one renewal to each of two workspace IDs with the same retry key and distinct transport IDs. Assert one ledger row and one receipt per workspace. Repeat in one workspace and assert its original receipt and no added row.
2. **A02 late retry and atomicity.** Commit a renewal, drop the response, advance the clock by 140 seconds and deliver the same workspace and retry key with a fresh transport ID. Assert handler execution, byte-identical receipt and one ledger row. Race two fresh transport IDs for a new key and assert both resolve to the same committed receipt and one ledger row. Force rollback before commit for another new key and assert neither an idempotency record nor a ledger entry is visible. Retry that rolled-back operation and assert exactly one successful commit.
3. **A03 expiry.** Seed separate equivalent originals. Deliver the same key at commit age 172799, 172800 and 172801 seconds. Assert the original receipt on the first case, `retry_window_expired` with no receipt on the other two, and one ledger row per case. Confirm that an earlier replay leaves the cutoff unchanged.

Implementation is pending design approval.
