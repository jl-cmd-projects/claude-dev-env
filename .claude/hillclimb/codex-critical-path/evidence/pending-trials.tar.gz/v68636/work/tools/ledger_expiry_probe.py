"""Check the proposed expiry decision against the approved register on a local clock."""

import csv
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def replay_window_seconds():
    with (ROOT / "sources/retention-register.csv").open(newline="", encoding="utf-8") as register:
        approved = [
            row
            for row in csv.DictReader(register)
            if (row["rule"], row["scope"], row["status"], row["owner"])
            == ("ledger-retry", "workspace", "approved", "operations")
        ]
    (rule,) = approved
    return int(rule["hours"]) * 3600


def retry_at(age_seconds, ttl_seconds):
    ledger = {("oak-17", "renewal-418"): (0, "receipt-418")}
    committed_at, receipt = ledger[("oak-17", "renewal-418")]
    within_window = age_seconds - committed_at < ttl_seconds
    return {
        "age_seconds": age_seconds,
        "outcome": "ledger_replay" if within_window else "retry_window_expired",
        "returned_receipt": receipt if within_window else None,
        "ledger_rows": len(ledger),
    }


def main():
    ttl = replay_window_seconds()
    cases = [retry_at(age, ttl) for age in (ttl - 1, ttl, ttl + 1)]
    assert ttl == 172800
    assert [(case["outcome"], case["returned_receipt"], case["ledger_rows"]) for case in cases] == [
        ("ledger_replay", "receipt-418", 1),
        ("retry_window_expired", None, 1),
        ("retry_window_expired", None, 1),
    ]
    print(json.dumps({"ttl_seconds": ttl, "committed_at_seconds": 0, "cases": cases}, indent=2))


if __name__ == "__main__":
    main()
