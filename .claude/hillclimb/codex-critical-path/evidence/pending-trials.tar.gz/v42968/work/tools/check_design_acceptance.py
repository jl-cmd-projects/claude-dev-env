"""Executable local design checks; does not exercise a production ledger."""
import csv
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
def receipt(name, scenario, outcome, rows, delay):
    data = json.loads((ROOT / "evidence" / name).read_text())
    assert data["scenario"] == scenario, name
    assert len(data["request_ids"]) == 2 and len(set(data["request_ids"])) == 2, name
    assert data["second_outcome"] == outcome, name
    assert data["ledger_rows"] == rows, name
    assert data["delay_seconds"] == delay, name

receipt("ledger-recheck.json", "delayed", "ledger_replay", 1, 140)
receipt("burst-probe.json", "burst", "client_window_filtered", 1, 20)
receipt("workspace-probe.json", "workspace", "separate_workspace", 2, 140)
receipt("response-loss-probe.json", "response-loss", "ledger_replay", 1, 0)
with (ROOT / "sources/retention-register.csv").open() as f:
    approved = [r for r in csv.DictReader(f) if r["rule"] == "ledger-retry"
                and r["scope"] == "workspace" and r["status"] == "approved"]
assert len(approved) == 1
assert int(approved[0]["hours"]) == 48
ttl = int(approved[0]["hours"]) * 3600
boundary = [{"age_seconds": age, "outcome": "replay" if age < ttl else "expired"}
            for age in (ttl - 1, ttl, ttl + 1)]
assert [r["outcome"] for r in boundary] == ["replay", "expired", "expired"]
saved = json.loads((ROOT / "evidence/retention-boundary.json").read_text())
assert saved == {"model": "proposed retention specification; not production evidence",
                 "ttl_hours": 48, "cases": boundary}
for name, status in (("source-coverage.csv", "covered"), ("acceptance.csv", "ready")):
    with (ROOT / "review" / name).open() as f:
        rows = list(csv.DictReader(f))
    assert len(rows) == 3 and all(r["status"] == status for r in rows), name
print("PASS: four saved local scenarios, approved 48h retention boundary, source coverage and acceptance readiness")
