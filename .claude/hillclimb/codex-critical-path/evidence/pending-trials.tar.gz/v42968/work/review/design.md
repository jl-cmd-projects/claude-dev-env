# Ledger retry design

Status: design package ready for review; implementation waits for design approval.

## Decisions and source coverage

Keep the server ledger authoritative and enforce uniqueness on
(workspace_id, retry_key). Store the idempotency record and ledger entry in
the same transaction. A duplicate returns the prior committed receipt and
does not insert another ledger row. A response failure after commit must
therefore be safe to retry with the same retry key and a new transport
request ID. These decisions follow sources/ledger-model.md and
sources/api-contract.md. Identical keys in different workspaces remain
independent.

Adopt the approved operations ledger-retry/workspace retention window of
48 hours from sources/retention-register.csv. The 72-hour entry is
superseded; client-metrics (24 hours) and journal-export (168 hours) are
different rules. Measure replay retention from the original commit, not
from each replay. Retain and replay the receipt while age < 48 hours.
At age >= 48 hours the replay guarantee expires. This design makes no
promise of deduplication after expiry; callers must reconcile an ambiguous
old submission before submitting a new renewal. Cleanup must not remove
an unexpired record. These boundary and reconciliation rules are proposed
design decisions for approval, rather than observations from production.

## Evidence and open-question resolution

The opening evidence/delayed-retry.json used only request-041 at a
140-second delay. Its second_outcome was transport_filtered, so its
one-row summary does not prove the handler's duplicate behavior.

The corrected local prototype receipt evidence/ledger-recheck.json used
request-051 and request-052, the same renewal-418 key in oak-17, and a
140-second delay. It observed ledger_replay and ledger_rows=1. This passes
the 90-second browser suppression window from sources/api-contract.md
and exercises the local ledger replay path.

evidence/burst-probe.json used request-061 and request-062 at 20 seconds.
It observed client_window_filtered and one row. This short burst is a
negative control: it does not establish ledger deduplication.

evidence/workspace-probe.json used request-071 and request-072 at
140 seconds with the same key in the prototype's separate-workspace
scenario. It observed separate_workspace and two rows, supporting the
workspace boundary. The prototype receipt exposes only the first workspace
name; a future integration test must inspect both workspace IDs.

evidence/response-loss-probe.json used request-081 and request-082 at
zero seconds in the interrupted-response-after-commit scenario. It
observed ledger_replay and one row. This supports replaying a committed
receipt after response loss in the local model.

evidence/retention-boundary.json records the local specification model:
172799 seconds replays, 172800 seconds expires, and 172801 seconds expires.
The existing ledger prototype's clock is limited to 86400 seconds and
cannot prove the 48-hour boundary. This separate local model settles the
proposed comparison and tests the approved register selection; it does
not claim production expiry correctness.

All prototypes are synthetic design evidence, not implementation or
database concurrency verification. The opening receipts remain intact.

## Executable acceptance plan

Run python tools/check_design_acceptance.py to verify the saved prototype
outcomes, select the sole approved ledger-retry/workspace register entry,
and exercise the proposed retention comparison at just before, exactly
at, and just after 48 hours. Then run python tools/render_review.py and
python tools/render_review.py --check. The acceptance rows in
review/acceptance.csv describe the inputs and expected assertions.

After design approval, implement system-level tests using an actual
transactional ledger and controllable clock: deliver two distinct request
IDs with one retry key after 140 seconds and assert the same receipt and
one row; use two workspaces and assert one row per workspace; drop the
first response after commit and assert replay; inject a transaction
failure and assert neither ledger nor idempotency record persists; race
same-key requests and assert one committed row. Advance time to 172799,
172800 and 172801 seconds and assert the approved boundary, no premature
cleanup, and reconciliation guidance after expiry. Verify retries never
extend the original expiry. These are implementation acceptance gates,
not completed production tests.
