# Ledger retry design

Implementation is pending design approval.

## Retry handling

Generate a stable retry key for one renewal. Keep it after an ambiguous response, and use a fresh transport request ID for each delivery. The browser suppresses a repeat submit within 90 seconds. After that window the server must still handle duplicates. A repeat with a reused transport ID can be filtered before it reaches the handler. See `sources/api-contract.md`.

The server ledger is authoritative. Enforce a unique active replay record for `(workspace_id, retry_key)`. Record the committed receipt and insert the ledger row in one transaction. A concurrent retry must resolve against the committed record. A same-workspace retry inside the replay window returns that original receipt and writes no second ledger row, even if the first response was lost after commit. The same key in another workspace uses an independent record. See `sources/ledger-model.md`.

The approved workspace replay TTL is 48 hours from the successful commit, per `sources/retention-register.csv`. Do not extend it on replay. With the proposed boundary, a record replays while its age is strictly less than 48 hours. At 48 hours and later, expire the replay record, retain the ledger entry, and process a submission through normal renewal validation without replaying the expired receipt. The client must reconcile an unresolved renewal before resubmitting it outside the guarantee.

## Evidence

- The original 140-second receipt for `oak-17` and `renewal-418` lists only `request-041` and reports `transport_filtered`. Its one row shows the transport stopped the duplicate before it could exercise ledger replay. See `evidence/delayed-retry.json`.
- The corrected test used `request-051` and `request-052`, the same workspace and retry key, and a 140-second delay beyond the browser window. It reported `ledger_replay` and one ledger row. See `evidence/ledger-recheck.json`.
- At 140 seconds, the workspace scenario with `request-061` and `request-062` reported `separate_workspace` and two ledger rows. The response-loss scenario with `request-071` and `request-072` reported `ledger_replay` and one row. See `evidence/workspace-probe.json` and `evidence/response-loss-probe.json`. These synthetic scenarios model the expected outcomes. The workspace receipt reports only the primary workspace, and the response-loss receipt contains no real commit or receipt identifiers. A01 and A02 specify the full assertions for implementation.
- The sample clock supports up to 86,400 seconds. The approved register establishes the 48-hour window. A03 requires boundary checks with a controllable server clock once implemented.

## Acceptance plan

Run each row in `review/acceptance.csv` on a clean disposable ledger with a controllable server clock. Use distinct transport IDs so each attempt reaches the handler. Check returned receipt identity and committed ledger state as specified in each row.

Reproduce the design-stage evidence locally with these commands. Their output should match the named saved receipts.

```sh
python tools/ledger_demo.py delayed --request-id request-051 --request-id request-052 --delay 140
python tools/ledger_demo.py workspace --request-id request-061 --request-id request-062 --delay 140
python tools/ledger_demo.py response-loss --request-id request-071 --request-id request-072 --delay 140
```

The acceptance rows are ready for design review. Passing implementation checks remains part of the implementation gate after approval.
