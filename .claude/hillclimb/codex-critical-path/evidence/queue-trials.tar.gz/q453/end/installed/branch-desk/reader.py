import json
import sys
from pathlib import Path


def decode(payload):
    if not isinstance(payload, dict) or type(payload.get("schema")) is not int:
        raise ValueError("Expected an object with an integer schema")
    schema = payload["schema"]
    if schema not in (1, 2):
        raise ValueError("Unknown schema")
    rows = payload.get("entries" if schema == 1 else "items")
    if not isinstance(rows, list):
        raise ValueError("Expected an array")
    result = []
    ids = set()
    for row in rows:
        if not isinstance(row, dict):
            raise ValueError("Expected row objects")
        identifier = row.get("id")
        if not isinstance(identifier, str) or not identifier or identifier.strip() != identifier:
            raise ValueError("Invalid id")
        if identifier in ids:
            raise ValueError("Duplicate id")
        ids.add(identifier)
        if schema == 1:
            amount = row.get("amount_cents")
            enabled = row.get("enabled")
            if type(enabled) is not bool:
                raise ValueError("Invalid enabled")
        else:
            money = row.get("amount")
            if not isinstance(money, dict):
                raise ValueError("Invalid amount")
            amount = money.get("cents")
            state = row.get("state")
            if state not in ("open", "void"):
                raise ValueError("Invalid state")
            enabled = state == "open"
        if type(amount) is not int or amount < 0:
            raise ValueError("Invalid amount")
        if enabled:
            result.append({"id": identifier, "amount_cents": amount})
    return sorted(result, key=lambda row: row["id"])


def main():
    try:
        if len(sys.argv) != 2:
            raise ValueError("Expected one payload path")
        rows = decode(json.loads(Path(sys.argv[1]).read_text(encoding="utf-8")))
    except (ValueError, OSError) as error:
        print(f"Invalid ledger: {error}", file=sys.stderr)
        return 2
    print(json.dumps(rows))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
