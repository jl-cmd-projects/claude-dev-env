import copy
import json
import runpy
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

decode = runpy.run_path("reader/ledger.py")["decode"]


class ReaderContract(unittest.TestCase):
    def test_supported_schemas(self):
        for schema in (1, 2):
            def row(identifier, amount, active):
                if schema == 1:
                    return {"id": identifier, "amount_cents": amount, "enabled": active, "extra": 7}
                return {"id": identifier, "amount": {"cents": amount}, "state": "open" if active else "void"}
            payload = {"schema": schema, "entries" if schema == 1 else "items":
                       [row("z", 2, True), row("a", 0, True), row("m", 8, False)]}
            self.assertEqual(decode(payload), [{"id": "a", "amount_cents": 0}, {"id": "z", "amount_cents": 2}])
            payload["entries" if schema == 1 else "items"] = []
            self.assertEqual(decode(payload), [])

    def test_malformed_payloads(self):
        for value in (None, [], 2, "", {}, {"schema": True}, {"schema": 1.0}, {"schema": 7}):
            with self.subTest(value=value), self.assertRaises(ValueError):
                decode(value)
        for schema in (1, 2):
            key = "entries" if schema == 1 else "items"
            good = ({"id": "a", "amount_cents": 1, "enabled": True} if schema == 1
                    else {"id": "a", "amount": {"cents": 1}, "state": "open"})
            for rows in (None, {}, "bad", 1, [None], [[]], [{}]):
                with self.subTest(schema=schema, rows=rows), self.assertRaises(ValueError):
                    decode({"schema": schema, key: rows})
            for field in good:
                row = copy.deepcopy(good)
                del row[field]
                with self.subTest(schema=schema, missing=field), self.assertRaises(ValueError):
                    decode({"schema": schema, key: [row]})
            for identifier in ("", " a", "a ", 1, None, True):
                row = copy.deepcopy(good)
                row["id"] = identifier
                with self.subTest(schema=schema, identifier=identifier), self.assertRaises(ValueError):
                    decode({"schema": schema, key: [row]})
            for amount in (-1, 1.0, True, None, "1", []):
                row = copy.deepcopy(good)
                if schema == 1:
                    row["amount_cents"] = amount
                else:
                    row["amount"]["cents"] = amount
                with self.subTest(schema=schema, amount=amount), self.assertRaises(ValueError):
                    decode({"schema": schema, key: [row]})
            for active in (None, 1, "true", [], {}):
                row = copy.deepcopy(good)
                row["enabled" if schema == 1 else "state"] = active
                with self.subTest(schema=schema, active=active), self.assertRaises(ValueError):
                    decode({"schema": schema, key: [row]})
            inactive = copy.deepcopy(good)
            inactive["enabled" if schema == 1 else "state"] = False if schema == 1 else "void"
            with self.subTest(schema=schema, duplicate=True), self.assertRaises(ValueError):
                decode({"schema": schema, key: [good, inactive]})
        for amount in (None, [], 1, {}, {"cents": True}):
            with self.subTest(amount=amount), self.assertRaises(ValueError):
                decode({"schema": 2, "items": [{"id": "a", "amount": amount, "state": "open"}]})

    def test_cli_invalid_has_no_rows(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "payload.json"
            for source in ('{"schema":2,"items":[null]}', '{', '{"schema":true,"entries":[]}'):
                path.write_text(source)
                result = subprocess.run([sys.executable, "reader/ledger.py", str(path)], capture_output=True, text=True)
                self.assertEqual(result.returncode, 2)
                self.assertEqual(result.stdout, "")
            path.write_text('{"schema":2,"items":[]}')
            result = subprocess.run([sys.executable, "reader/ledger.py", str(path)], capture_output=True, text=True)
            self.assertEqual(result.returncode, 0)
            self.assertEqual(json.loads(result.stdout), [])


if __name__ == "__main__":
    unittest.main()
