import json
import sys
from pathlib import Path


def decode(payload):
    if not isinstance(payload, dict):
        raise ValueError("Payload must be an object.")
    schema = payload.get("schema")
    if type(schema) is not int or schema not in (1, 2):
        raise ValueError("Unsupported ledger schema.")

    entries = payload.get("entries" if schema == 1 else "items")
    if not isinstance(entries, list):
        raise ValueError("Ledger rows must be an array.")

    rows = []
    seen = set()
    for entry in entries:
        if not isinstance(entry, dict):
            raise ValueError("Ledger row must be an object.")
        row_id = entry.get("id")
        if not isinstance(row_id, str) or not row_id or row_id != row_id.strip():
            raise ValueError("Ledger ID must be a nonempty string without surrounding whitespace.")
        if row_id in seen:
            raise ValueError("Duplicate ledger ID.")
        seen.add(row_id)

        if schema == 1:
            active = entry.get("enabled")
            if type(active) is not bool:
                raise ValueError("Ledger enabled field must be a boolean.")
            cents = entry.get("amount_cents")
        else:
            state = entry.get("state")
            if state not in ("open", "void"):
                raise ValueError("Ledger state must be open or void.")
            active = state == "open"
            amount = entry.get("amount")
            if not isinstance(amount, dict):
                raise ValueError("Ledger amount must be an object.")
            cents = amount.get("cents")

        if type(cents) is not int or cents < 0:
            raise ValueError("Ledger amount must be a nonnegative integer.")
        if active:
            rows.append({"id": row_id, "amount_cents": cents})

    return sorted(rows, key=lambda row: row["id"])


def reject_json_constant(value):
    raise ValueError(f"Invalid JSON constant: {value}")


def main():
    try:
        text = Path(sys.argv[1]).read_text(encoding="utf-8")
        rows = decode(json.loads(text, parse_constant=reject_json_constant))
    except (ValueError, OSError, IndexError, RecursionError) as error:
        print(f"Invalid ledger: {error}", file=sys.stderr)
        return 2
    print(json.dumps(rows))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
