import json
import sys
from pathlib import Path


def decode(payload):
    if not isinstance(payload, dict):
        raise ValueError("Ledger must be an object.")
    schema = payload.get("schema")
    if type(schema) is not int or schema not in (1, 2):
        raise ValueError("Ledger schema must be 1 or 2.")

    entries = payload.get("entries" if schema == 1 else "items")
    if not isinstance(entries, list):
        raise ValueError("Ledger rows must be an array.")

    seen = set()
    rows = []
    for entry in entries:
        if not isinstance(entry, dict):
            raise ValueError("Ledger row must be an object.")
        row_id = entry.get("id")
        if not isinstance(row_id, str) or not row_id or row_id != row_id.strip():
            raise ValueError("Ledger row ID must be a nonempty string without surrounding whitespace.")
        if row_id in seen:
            raise ValueError(f"Duplicate ledger row ID: {row_id!r}.")
        seen.add(row_id)

        if schema == 1:
            cents = entry.get("amount_cents")
            active = entry.get("enabled")
            if type(active) is not bool:
                raise ValueError("Ledger row enabled must be a boolean.")
        else:
            amount = entry.get("amount")
            if not isinstance(amount, dict):
                raise ValueError("Ledger row amount must be an object.")
            cents = amount.get("cents")
            state = entry.get("state")
            if state not in ("open", "void"):
                raise ValueError("Ledger row state must be open or void.")
            active = state == "open"

        if type(cents) is not int or cents < 0:
            raise ValueError("Ledger row cents must be a nonnegative integer.")
        if active:
            rows.append({"id": row_id, "amount_cents": cents})

    return sorted(rows, key=lambda row: row["id"])


def invalid_constant(value):
    raise ValueError(f"Invalid JSON constant: {value}.")


def main():
    try:
        payload = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"), parse_constant=invalid_constant)
        rows = decode(payload)
    except (ValueError, OSError) as error:
        print(f"Invalid ledger: {error}", file=sys.stderr)
        return 2
    print(json.dumps(rows))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
