import json
import sys
from pathlib import Path


def decode(payload):
    if not isinstance(payload, dict) or type(payload.get("schema")) is not int:
        raise ValueError("schema must be an integer")
    schema = payload["schema"]
    if schema not in (1, 2):
        raise ValueError("unsupported schema")
    entries = payload.get("entries" if schema == 1 else "items")
    if not isinstance(entries, list):
        raise ValueError("rows must be an array")
    seen = set()
    active = []
    for row in entries:
        if not isinstance(row, dict):
            raise ValueError("row must be an object")
        identifier = row.get("id")
        if not isinstance(identifier, str) or not identifier or identifier.strip() != identifier:
            raise ValueError("id must be a nonempty trimmed string")
        if identifier in seen:
            raise ValueError("duplicate id")
        seen.add(identifier)
        if schema == 1:
            cents = row.get("amount_cents")
            enabled = row.get("enabled")
            if type(enabled) is not bool:
                raise ValueError("enabled must be boolean")
        else:
            amount = row.get("amount")
            if not isinstance(amount, dict):
                raise ValueError("amount must be an object")
            cents = amount.get("cents")
            state = row.get("state")
            if state not in ("open", "void"):
                raise ValueError("invalid state")
            enabled = state == "open"
        if type(cents) is not int or cents < 0:
            raise ValueError("amount must be a nonnegative integer")
        if enabled:
            active.append({"id": identifier, "amount_cents": cents})
    return sorted(active, key=lambda row: row["id"])


def main():
    try:
        if len(sys.argv) != 2:
            raise ValueError("expected one input path")
        rows = decode(json.loads(Path(sys.argv[1]).read_text(encoding="utf-8")))
    except (ValueError, OSError) as error:
        print(f"Invalid ledger: {error}", file=sys.stderr)
        return 2
    print(json.dumps(rows))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
