import copy
import json
import runpy
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

decode = runpy.run_path("reader/ledger.py")["decode"]


class ReaderContract(unittest.TestCase):
    def test_valid_and_order(self):
        for schema in (1, 2):
            rows = [{"id": "z", "amount_cents": 0, "enabled": True},
                    {"id": "a", "amount_cents": 5, "enabled": True},
                    {"id": "off", "amount_cents": 2, "enabled": False}]
            payload = {"schema": schema, "entries": rows}
            if schema == 2:
                payload = {"schema": 2, "items": [
                    {"id": row["id"], "amount": {"cents": row["amount_cents"]},
                     "state": "open" if row["enabled"] else "void"} for row in rows]}
            payload["extra"] = None
            original = copy.deepcopy(payload)
            self.assertEqual(decode(payload), [{"id": "a", "amount_cents": 5}, {"id": "z", "amount_cents": 0}])
            self.assertEqual(payload, original)

    def test_malformed(self):
        invalid = [None, [], {}, {"schema": True}, {"schema": 1.0}, {"schema": 9},
                   {"schema": 1}, {"schema": 2, "items": {}}, {"schema": 1, "entries": [None]}]
        for schema in (1, 2):
            valid = ({"id": "x", "amount_cents": 1, "enabled": False} if schema == 1 else
                     {"id": "x", "amount": {"cents": 1}, "state": "void"})
            key = "entries" if schema == 1 else "items"
            for field in valid:
                row = copy.deepcopy(valid)
                del row[field]
                invalid.append({"schema": schema, key: [row]})
            for bad_id in ("", " x", "x ", None, 1, True):
                row = copy.deepcopy(valid)
                row["id"] = bad_id
                invalid.append({"schema": schema, key: [row]})
            for bad_amount in (-1, True, 1.0, None, "1"):
                row = copy.deepcopy(valid)
                if schema == 1:
                    row["amount_cents"] = bad_amount
                else:
                    row["amount"]["cents"] = bad_amount
                invalid.append({"schema": schema, key: [row]})
            invalid.append({"schema": schema, key: [valid, copy.deepcopy(valid)]})
        invalid += [{"schema": 1, "entries": [{"id": "x", "amount_cents": 1, "enabled": 1}]},
                    {"schema": 2, "items": [{"id": "x", "amount": None, "state": "open"}]},
                    {"schema": 2, "items": [{"id": "x", "amount": {"cents": 1}, "state": []}]}]
        for payload in invalid:
            with self.subTest(payload=payload):
                with self.assertRaises(ValueError):
                    decode(payload)

    def test_cli(self):
        with tempfile.TemporaryDirectory(dir=".") as directory:
            source = Path(directory) / "ledger.json"
            for payload, expected_code in (({"schema": 2, "items": []}, 0),
                                           ({"schema": 1, "entries": [{}]}, 2)):
                source.write_text(json.dumps(payload))
                result = subprocess.run([sys.executable, "reader/ledger.py", str(source)],
                                        capture_output=True, text=True)
                self.assertEqual(result.returncode, expected_code)
                self.assertEqual(result.stdout, "[]\n" if expected_code == 0 else "")
            source.write_text("{")
            result = subprocess.run([sys.executable, "reader/ledger.py", str(source)],
                                    capture_output=True, text=True)
            self.assertEqual(result.returncode, 2)
            self.assertEqual(result.stdout, "")


unittest.main()
