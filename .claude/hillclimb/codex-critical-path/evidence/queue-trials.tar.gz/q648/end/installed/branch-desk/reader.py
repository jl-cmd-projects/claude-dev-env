import json
import sys
from pathlib import Path


def decode(payload):
    if not isinstance(payload, dict):
        raise ValueError("Ledger must be an object.")

    schema = payload.get("schema")
    if type(schema) is not int or schema not in (1, 2):
        raise ValueError("Unsupported ledger schema.")

    legacy = schema == 1
    entries = payload.get("entries" if legacy else "items")
    if not isinstance(entries, list):
        raise ValueError("Ledger rows must be an array.")

    seen = set()
    active_rows = []
    for entry in entries:
        if not isinstance(entry, dict):
            raise ValueError("Ledger row must be an object.")

        entry_id = entry.get("id")
        if not isinstance(entry_id, str) or not entry_id or entry_id != entry_id.strip():
            raise ValueError("Ledger row has an invalid ID.")
        if entry_id in seen:
            raise ValueError("Duplicate ledger ID.")
        seen.add(entry_id)

        if legacy:
            amount = entry.get("amount_cents")
            active = entry.get("enabled")
            if not isinstance(active, bool):
                raise ValueError("Ledger row must have a boolean enabled flag.")
        else:
            amount_object = entry.get("amount")
            if not isinstance(amount_object, dict):
                raise ValueError("Ledger row must have an amount object.")
            amount = amount_object.get("cents")
            state = entry.get("state")
            if state not in ("open", "void"):
                raise ValueError("Ledger row has an invalid state.")
            active = state == "open"

        if type(amount) is not int or amount < 0:
            raise ValueError("Ledger amount must be a nonnegative integer.")
        if active:
            active_rows.append({"id": entry_id, "amount_cents": amount})

    return sorted(active_rows, key=lambda row: row["id"])


def main():
    try:
        rows = decode(json.loads(Path(sys.argv[1]).read_text(encoding="utf-8")))
    except (ValueError, OSError) as error:
        print(f"Invalid ledger: {error}", file=sys.stderr)
        return 2
    print(json.dumps(rows))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
