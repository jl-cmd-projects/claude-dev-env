import json
import runpy
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
READER = ROOT / "reader" / "ledger.py"
decode = runpy.run_path(str(READER))["decode"]


class LedgerContract(unittest.TestCase):
    def test_supported_consumer_samples(self):
        for consumer in ("branch-desk", "night-recon"):
            with self.subTest(consumer=consumer):
                payload = json.loads((ROOT / "data" / f"{consumer}.json").read_text())
                expected = json.loads((ROOT / "data" / f"{consumer}.expected.json").read_text())
                self.assertEqual(decode(payload), expected)

    def test_malformed_inputs_raise_value_error(self):
        legacy = {"id": "L", "amount_cents": 0, "enabled": False}
        current = {"id": "C", "amount": {"cents": 0}, "state": "void"}
        malformed = (
            None, [], {}, {"schema": True, "entries": []},
            {"schema": 2.0, "items": []}, {"schema": 3},
            {"schema": 1, "entries": {}}, {"schema": 2, "items": [None]},
            {"schema": 1, "entries": [{**legacy, "enabled": 0}]},
            {"schema": 1, "entries": [{**legacy, "id": " L"}]},
            {"schema": 1, "entries": [{**legacy, "amount_cents": True}]},
            {"schema": 1, "entries": [legacy, {**legacy, "enabled": True}]},
            {"schema": 2, "items": [{**current, "amount": []}]},
            {"schema": 2, "items": [{**current, "amount": {}}]},
            {"schema": 2, "items": [{**current, "amount": {"cents": -1}}]},
            {"schema": 2, "items": [{**current, "state": "closed"}]},
            {"schema": 2, "items": [current, {**current, "state": "open"}]},
        )
        for payload in malformed:
            with self.subTest(payload=payload):
                with self.assertRaises(ValueError):
                    decode(payload)

    def test_cli_rejects_malformed_json_and_payload_without_rows(self):
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "payload.json"
            for payload in ("{", '{"schema":2,"items":[{}]}'):
                with self.subTest(payload=payload):
                    path.write_text(payload, encoding="utf-8")
                    result = subprocess.run(
                        [sys.executable, str(READER), str(path)],
                        capture_output=True, text=True, check=False,
                    )
                    self.assertEqual(result.returncode, 2)
                    self.assertEqual(result.stdout, "")


if __name__ == "__main__":
    unittest.main()
