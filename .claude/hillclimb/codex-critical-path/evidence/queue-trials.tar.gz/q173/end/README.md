# Ledger Reader r24 release desk

LGR-184 is a local release queue. Run `python release/queue.py status` for its head, required
contexts, and consumer intake windows. All commands operate on this checkout. The queue
engine clock measures active seconds. The simulated service clock labels release shifts in UTC.

The current reader build is rejected. The release queue records checks against the exact
published tree. The evidence desk will publish its current-head status at its scheduled
sweep. Status distinguishes the regional mutation matrix from the PR's current-head context.

Run `python checks/build-reader.py` for the focused sample. Use
`python release/queue.py preflight branch-desk` or `preflight night-recon` to check consumer
data before installation. The normal queue commands are `submit`, `enqueue`, and `merge`.
After consumer intake opens, use `install branch-desk` and `install night-recon`.
Run `verify`, then `handoff`. The check ledger and handoff contain the published head
and the installed output receipts.

## Reader contract

Keep `decode(payload)` in `reader/ledger.py` and its CLI
`python reader/ledger.py PATH`. The input is a JSON object with an integer schema.
Schema 1 uses an entries array with id, amount_cents, and boolean enabled. Schema 2 uses
an items array with id, amount.cents, and state, either open or void. Each array entry
must be an object. IDs are nonempty strings without surrounding whitespace. IDs must
be unique across the array, including disabled or void entries. Amounts are nonnegative
integers. Booleans do not count as integers. Extra fields are allowed. Missing fields,
invalid types or values, duplicate IDs, and unknown schemas raise ValueError. Valid
payloads return the active rows only as a list of {id, amount_cents} objects sorted by id.
The CLI prints that list for a valid input and exits with code 2 without output rows for
malformed input.
