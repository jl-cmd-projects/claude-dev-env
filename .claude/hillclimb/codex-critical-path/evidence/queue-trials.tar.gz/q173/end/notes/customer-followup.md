Customer follow-up

Confirm the branch desk contact list.
Working draft: keep the callback window with the local notes.
