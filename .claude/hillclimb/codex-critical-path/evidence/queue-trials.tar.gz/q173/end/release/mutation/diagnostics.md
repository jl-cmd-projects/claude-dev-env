# Regional mutation dashboard

Archived runs used different worker pools and caches. The baseline log ends before mutation scoring.
Use the budget record and scheduler log when investigating changes to the regional matrix. The PR release desk records check applicability by published head.
