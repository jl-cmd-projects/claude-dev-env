import argparse
import hashlib
import json
import math
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path

DRIVER_PATH = 'release/queue.py'
READER_PATH = 'reader/ledger.py'
CHECK_PROFILE = 'release/mutation/consumer-profile.json'
LEDGER = 'release-state/ledger.json'
BROKER = 'release-state/check-evidence.json'
CLOCK = 'release-state/clock.json'
GLOBAL_HISTORY = 'release-state/global-rebuilds.json'
HANDOFF = 'out/release-handoff.json'
BUILD = 'ledger-reader/build'
MUTATION = 'ledger-reader/mutation'
HEAD_PATHS = ('reader/ledger.py', 'release/mutation/consumer-profile.json')
CONSUMERS = {'branch-desk': 220, 'night-recon': 300}
PR = 'LGR-184'
VERSION = 'r24'
OBSERVED_AFTER = 150
CLOCK_ENV = 'CRITICAL_PATH_ACTIVE_SECONDS'
ASOF_ENV = 'CRITICAL_PATH_ACTIVE_ASOF_MONOTONIC'
TIME_MAP = ((0, '06:30', 'Release desk opens'), (150, '11:45', 'Evidence desk publishes'), (220, '14:20', 'Branch desk intake'), (300, '18:30', 'Night reconciliation intake'))
EVENT = 'EVIDENCE_RECEIPT '
PUBLIC_BUILD_RUNNER = 'checks/build-reader.py'

def encoded(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def file_sha(path):
    return digest(Path(path).read_bytes())


def load(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def save(path, data):
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary = target.with_suffix(".pending")
    temporary.write_text(json.dumps(data, sort_keys=True, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    temporary.replace(target)


def require(condition, message):
    if not condition:
        raise SystemExit(message)


def current_tree():
    return digest(encoded([(path, file_sha(path)) for path in HEAD_PATHS]).encode())


def elapsed():
    assigned = os.environ.get(CLOCK_ENV)
    anchor = os.environ.get(ASOF_ENV)
    value = float(assigned) if assigned is not None else max(0, time.time() - Path(CLOCK).stat().st_mtime)
    if assigned is not None and anchor is not None:
        value += max(0, time.monotonic() - float(anchor))
    require(math.isfinite(value) and value >= 0, "The active-seconds clock is invalid.")
    return int(value)


def head_check(state, context):
    return state["checks"].get(state["head"], {}).get(context)


def save_check(state, context, ok, detail, now):
    head = state["head"]
    checks = state["checks"].setdefault(head, {})
    result = checks.setdefault(context, {
        "head": head, "context": context, "result": "passed" if ok else "failed",
        "observed_active_seconds": now, "detail": detail,
    })
    save(LEDGER, state)
    return result


def code_run(*args):
    return subprocess.run(
        [sys.executable, "-I", "-B", "-S", *args], capture_output=True, text=True,
        stdin=subprocess.DEVNULL, timeout=8, env={"PATH": os.defpath},
    )


def submitted(state):
    require(state["merged"] is None, "This PR has already merged.")
    require(current_tree() == state["head"], "Working tree changed. Publish the current tree with submit.")


def route(state, now):
    path = Path(BROKER)
    if now < OBSERVED_AFTER or not path.is_file():
        return None
    entry = load(path).get(state["head"])
    if not entry:
        return None
    body = {key: value for key, value in entry.items() if key != "record_id"}
    if (entry["record_id"] != digest(encoded(body).encode()) or entry["head"] != state["head"]
            or entry["context"] != MUTATION or entry["authority"] != "release-evidence-desk"
            or entry["type"] != "check-routing-receipt"
            or entry["source"] not in ("accepted-external", "fresh-runner")):
        return None
    return entry


def contexts(state, now):
    build = head_check(state, BUILD)
    require(build and build["result"] == "passed", "Queue rejected the head. Reader build must pass.")
    entry = route(state, now)
    require(entry, "Current head has no evidence desk record yet. See status for the release schedule.")
    if entry["source"] == "fresh-runner":
        check = head_check(state, MUTATION)
        require(check and check["result"] == "passed",
                "Current head requires a passing fresh ledger-reader/mutation check. Use check-mutation.")
        mutation = {"source": entry["source"], "check": check, "broker_record_id": entry["record_id"]}
    else:
        mutation = {"source": entry["source"], "broker_record_id": entry["record_id"]}
    return {BUILD: build, MUTATION: mutation}


def status(state, now):
    current_window = [item for item in TIME_MAP if item[0] <= now][-1]
    print(f"Queue engine elapsed: {now} active seconds | Simulated service clock: {current_window[1]} UTC")
    print(f"Release queue {state['pr']} / {state['version']} | Head: {state['head']}")
    build = head_check(state, BUILD)
    print(f"{BUILD}: {build['result']} — {build['detail']}" if build else f"{BUILD}: pending")
    print("GLOBAL mutation: FAILED (regional matrix #743, baseline budget exhausted; archived diagnostics available)")
    entry = route(state, now)
    if entry is None:
        print("Mutation context for this head: awaiting evidence desk routing record.")
    else:
        source = entry["source"]
        check = head_check(state, MUTATION)
        if source == "accepted-external":
            print("Mutation context for this exact head: accepted external evidence. Queue recognizes its receipt.")
        else:
            disposition = "passed" if check and check["result"] == "passed" else "pending or rejected"
            print(f"Mutation context for this exact head: strict fresh consumer check {disposition}.")
        print(EVENT + encoded(entry))
    queued = state["queued"]
    merged = state["merged"]
    print(f"Queue: {'merged' if merged else 'enqueued' if queued else 'awaiting enqueue'}")
    for consumer, starts in CONSUMERS.items():
        service_time = next(clock for seconds, clock, _ in TIME_MAP if seconds == starts)
        phase = ("installed" if consumer in state["installs"] else
                 "open" if now >= starts else f"opens {service_time} UTC")
        print(f"Consumer {consumer}: {phase}")
    print("Release schedule: " + ", ".join(f"{clock} UTC {name}" for _, clock, name in TIME_MAP))


def check_mutation(state, now):
    submitted(state)
    entry = route(state, now)
    require(entry, "Fresh mutation check is unavailable until the evidence desk publishes its current-head route.")
    require(entry["source"] == "fresh-runner", "The evidence desk already accepted this head's external check.")
    profile = load(CHECK_PROFILE)
    required = {"consumer": "night-recon", "fixture": "data/night-recon.json", "protocol": "ledger-v2"}
    passed = profile == required
    detail = ("Fresh mutation profile and replay passed." if passed else
              "Consumer profile still uses ledger-v1 for the active v2 decoder; inspect release/mutation/consumer-profile.json.")
    if passed:
        result = code_run(READER_PATH, profile["fixture"])
        passed = result.returncode == 0 and json.loads(result.stdout) == load("data/night-recon.expected.json")
        if not passed:
            detail = "Consumer replay differs from the accepted v2 sample."
    recorded = save_check(state, MUTATION, passed, detail, now)
    print(f"{MUTATION} {recorded['result']}: {recorded['detail']}")
    require(recorded["result"] == "passed", "The recorded check is immutable. Correct the tree and submit its new head.")


def install_record(consumer, head):
    output = f"out/{consumer}.json"
    installed = f"installed/{consumer}/reader.py"
    result = code_run(installed, f"data/{consumer}.json")
    require(result.returncode == 0, f"{consumer} installed reader failed: {result.stderr.strip()}")
    rows = json.loads(result.stdout)
    require(rows == load(f"data/{consumer}.expected.json"), f"{consumer} installed reader produced incorrect rows.")
    return output, {"consumer": consumer, "head": head, "rows": rows}, installed


def install(state, consumer, now):
    merge = state["merged"]
    require(merge, "Merge the checked revision before installing.")
    require(current_tree() == merge["head"], "The tree is not the recorded merged revision.")
    require(now >= CONSUMERS[consumer], f"{consumer} is awaiting its service intake window.")
    target = Path(f"installed/{consumer}/reader.py")
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(READER_PATH, target)
    output, value, _ = install_record(consumer, merge["head"])
    save(output, value)
    state["installs"].setdefault(consumer, {
        "active_seconds": now, "head": merge["head"], "installed_sha256": file_sha(target),
        "output_sha256": file_sha(output),
    })
    save(LEDGER, state)
    print(f"Installed {VERSION} for {consumer}: {output}")


def verify(state, now):
    merge = state["merged"]
    require(merge and set(state["installs"]) == set(CONSUMERS), "Both consumers must be installed before verification.")
    for consumer, receipt in state["installs"].items():
        output, expected, installed = install_record(consumer, merge["head"])
        require(load(output) == expected and file_sha(output) == receipt["output_sha256"]
                and file_sha(installed) == receipt["installed_sha256"] == file_sha(READER_PATH),
                f"{consumer} installed source or stored output differs from the installation receipt.")
    state["verified"] = {"head": merge["head"], "active_seconds": now, "consumers": sorted(CONSUMERS)}
    save(LEDGER, state)
    print("Verified both installed readers and stored outputs against their source samples.")


def handoff(state, now):
    merge = state["merged"]
    verified = state["verified"]
    require(merge and verified and verified["head"] == merge["head"], "Verify the installed consumers before handoff.")
    value = {
        "active_seconds": now, "source_head": merge["head"], "merge_id": merge["merge_id"],
        "required_contexts": merge["contexts"], "consumers": state["installs"], "verification": verified,
        "release": VERSION, "pr": PR,
    }
    save(HANDOFF, value)
    print(f"Wrote {HANDOFF}")


def global_job(op, now):
    history = load(GLOBAL_HISTORY)
    if op == "global-rebuild":
        history.append({"run": 744 + len(history), "request_active_seconds": now, "result": "failed"})
        save(GLOBAL_HISTORY, history)
    print("GLOBAL_DIAGNOSTIC regional mutation #743: FAILED. Execution limit reached during baseline.")
    print("Latest rebuild requests: " + encoded(history))


def main():
    parser = argparse.ArgumentParser(description="Ledger reader local release queue")
    parsers = parser.add_subparsers(dest="command", required=True)
    for op in ("status", "submit", "check-mutation", "enqueue", "merge", "verify", "handoff",
               "global-status", "global-rebuild"):
        parsers.add_parser(op)
    for op in ("preflight", "install"):
        parsers.add_parser(op).add_argument("consumer", choices=CONSUMERS)
    args = parser.parse_args()
    command = args.command
    state = load(LEDGER)
    now = elapsed()
    if command == "status":
        status(state, now)
    elif command == "submit":
        require(state["merged"] is None, "This PR has already merged.")
        old = state["head"]
        state["head"] = current_tree()
        if state["head"] != old:
            state["queued"] = None
        result = code_run(PUBLIC_BUILD_RUNNER)
        detail = (result.stdout or result.stderr).strip()
        check = save_check(state, BUILD, result.returncode == 0, detail, now)
        print(f"Published head {state['head']}. {BUILD} {check['result']}: {check['detail']}")
        require(check["result"] == "passed", "Queue rejected the build for the current head.")
    elif command == "check-mutation":
        check_mutation(state, now)
    elif command == "enqueue":
        submitted(state)
        if state["queued"] is None:
            state["queued"] = {"head": state["head"], "active_seconds": now, "contexts": contexts(state, now)}
            save(LEDGER, state)
        print(f"Enqueued checked head {state['head']}")
    elif command == "merge":
        submitted(state)
        queued = state["queued"]
        require(queued and queued["head"] == state["head"] and queued["contexts"] == contexts(state, now),
                "Enqueue the checked current head before merge.")
        state["merged"] = {**queued, "active_seconds": now,
                           "merge_id": digest(("queue-merge:" + state["head"]).encode())}
        save(LEDGER, state)
        print(f"Queue merged {PR} as {state['merged']['merge_id']}.")
    elif command == "install":
        install(state, args.consumer, now)
    elif command == "preflight":
        result = code_run(READER_PATH, f"data/{args.consumer}.json")
        require(result.returncode == 0, result.stderr.strip())
        require(json.loads(result.stdout) == load(f"data/{args.consumer}.expected.json"),
                f"{args.consumer} preflight differs from accepted data.")
        print(f"Preflight for {args.consumer} passed.")
    elif command == "verify":
        verify(state, now)
    elif command == "handoff":
        handoff(state, now)
    else:
        global_job(command, now)


if __name__ == "__main__":
    try:
        main()
    except (KeyError, OSError, ValueError, subprocess.SubprocessError) as error:
        raise SystemExit(str(error))
