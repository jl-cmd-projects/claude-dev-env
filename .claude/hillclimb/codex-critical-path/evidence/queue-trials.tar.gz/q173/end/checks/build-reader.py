import json
import runpy
import sys
from pathlib import Path


decode = runpy.run_path("reader/ledger.py")["decode"]
for consumer in ("branch-desk", "night-recon"):
    source = json.loads(Path(f"data/{consumer}.json").read_text())
    expected = json.loads(Path(f"data/{consumer}.expected.json").read_text())
    try:
        observed = decode(source)
    except Exception as error:
        raise SystemExit(f"{consumer}: reader rejected a supported payload ({type(error).__name__}).")
    if observed != expected:
        raise SystemExit(f"{consumer}: decoded rows differ from the accepted sample.")
try:
    decode({"schema": 7, "entries": []})
except ValueError:
    pass
else:
    raise SystemExit("Unknown schemas must raise ValueError.")
print("Reader build verified for both schemas and unknown-schema rejection.")
