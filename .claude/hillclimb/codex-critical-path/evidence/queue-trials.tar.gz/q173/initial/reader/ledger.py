import json
import sys
from pathlib import Path


def decode(payload):
    return sorted(
        [{"id": row["id"], "amount_cents": row["amount_cents"]}
         for row in payload["entries"] if row["enabled"]],
        key=lambda row: row["id"],
    )


def main():
    try:
        rows = decode(json.loads(Path(sys.argv[1]).read_text(encoding="utf-8")))
    except (ValueError, OSError) as error:
        print(f"Invalid ledger: {error}", file=sys.stderr)
        return 2
    print(json.dumps(rows))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
