# Ledger retry design

Status: ready for design review. Implementation is pending design approval.

## Delivery and commit

Keep the server ledger authoritative. A renewal submission has one retry key. Preserve it after an ambiguous response and use a fresh transport request ID for each delivery. Transport can filter repeated request IDs before the ledger sees them. The browser also suppresses repeat submissions in the first 90 seconds. A server-side retry test must deliver distinct transport IDs after that window. See `sources/api-contract.md`.

Enforce uniqueness on `(workspace_id, retry_key)` in the replay records. Insert the replay record and ledger entry in one transaction. Concurrent deliveries for the same pair must resolve to one committed entry. While its replay record is live, a repeat returns the original committed receipt without an additional debit. A response can be lost after commit and must use the same replay path. The same key in another workspace has an independent write and receipt. See `sources/ledger-model.md`.

## Prototype receipts

- `evidence/delayed-retry.json` reported one row after 140 seconds for `renewal-418` in `oak-17`. Its only request ID was `request-041` and its second outcome was `transport_filtered`. The second delivery did not exercise ledger replay.
- `evidence/ledger-recheck.json` used the same scenario, key, workspace and 140-second delay with distinct IDs `request-041` and `request-042`. The second outcome was `ledger_replay` with one ledger row.
- `evidence/workspace-probe.json` used the same key across the prototype's workspace scenario at 140 seconds with `request-043` and `request-044`. The second outcome was `separate_workspace` with two rows. `evidence/response-loss-probe.json` used `request-045` and `request-046` at 140 seconds in the response-loss scenario. It returned `ledger_replay` with one row.
- `evidence/burst-probe.json` used distinct IDs `request-047` and `request-048` at 45 seconds and returned `client_window_filtered` with one row. This records the effect of client suppression.

These are synthetic prototype outcomes. The integration checks in `review/acceptance.csv` specify the required assertions against committed rows and receipts.

## Retention

Use the approved 48-hour workspace-scoped `ledger-retry` rule in `sources/retention-register.csv`. The 72-hour row is superseded. Set the replay deadline at the first commit timestamp plus 48 hours. A repeat before the deadline returns the original receipt and leaves the deadline unchanged. At the deadline the old receipt is ineligible for replay, even if a cleanup job has yet to remove it. The expiry only affects the replay record. Keep the original ledger entry authoritative.

Proposed expiry policy for design approval: an expired key is eligible for a new submission and a new replay record. A client recovering an ambiguous response at or after the deadline must reconcile the original renewal before submitting again. A03 freezes the clock and exercises just before, at, and after the deadline in independent fixtures. The prototype sample clock stops at 24 hours, so the register establishes the window and A03 remains an implementation acceptance check.

## Design gate

`review/source-coverage.csv` records how each linked source informs the design. `review/acceptance.csv` defines the setup, action and assertions for the workspace, delayed replay, response-loss and expiry checks. The generated `review/index.html` packages the three documents.
