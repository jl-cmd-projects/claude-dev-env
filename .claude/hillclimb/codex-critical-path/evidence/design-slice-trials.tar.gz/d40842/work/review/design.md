# Ledger retry design

Keep the server ledger authoritative and scope the key by workspace.
Proposed: one write when retrying a renewal after an ambiguous response.
The later retry and retention notes need source and evidence links.
Implementation is pending design approval.
