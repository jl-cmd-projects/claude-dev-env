# Ledger retry design desk

Start at `notes/review-checkpoint.md`. The draft and its two review tables live under `review/`.
Use the existing CSV headings and mark completed rows `covered` or `ready` in the respective tables.
Cite evidence by its checkout path. Include the inputs and observed outcome when relying on a
prototype receipt. Acceptance rows describe steps and expected assertions for the design gate.

The prototype under `tools/ledger_demo.py` runs against the local sample clock and synthetic ledger.
Use `python tools/ledger_demo.py --help` for scenario and receipt options.
Render with `python tools/render_review.py` and verify with `python tools/render_review.py --check`.
