import argparse
import json
import re
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser(description="Replay the local ledger design prototype")
parser.add_argument("scenario", choices=("delayed", "burst", "workspace", "response-loss"))
parser.add_argument("--request-id", action="append", required=True, help="Transport ID, once per delivery")
parser.add_argument("--delay", required=True, type=int, help="Seconds between deliveries on the sample clock")
parser.add_argument("--save", action="store_true", help="Write the receipt under evidence/")
args = parser.parse_args()
if not 1 <= len(args.request_id) <= 2 or any(
    not re.fullmatch(r"[a-zA-Z0-9-]{1,40}", identifier) for identifier in args.request_id
):
    parser.error("provide one or two well-formed transport request IDs")
if not 0 <= args.delay <= 86400:
    parser.error("delay exceeds the sample clock range")

distinct = len(set(args.request_id)) == 2
result = "transport_filtered"
rows = 1
if distinct:
    if args.scenario == "workspace":
        result = "separate_workspace"
        rows = 2
    elif args.scenario in {"burst", "delayed"} and args.delay <= 90:
        result = "client_window_filtered"
    else:
        result = "ledger_replay"
receipt = {
    "scenario": args.scenario, "delay_seconds": args.delay,
    "request_ids": args.request_id, "workspace": "oak-17", "retry_key": "renewal-418",
    "summary": "no extra debit observed" if rows == 1 else "independent debits observed",
    "second_outcome": result, "ledger_rows": rows,
}
target = None
if args.save:
    name = "ledger-recheck.json" if args.scenario == "delayed" else args.scenario + "-probe.json"
    target = "evidence/" + name
    (ROOT / target).write_text(json.dumps(receipt, indent=2, sort_keys=True) + "\n", encoding="utf-8")
with (ROOT / "evidence/probe-runs.jsonl").open("a", encoding="utf-8") as runs:
    runs.write(json.dumps({"saved": target, "receipt": receipt}, sort_keys=True) + "\n")
print(json.dumps(receipt, indent=2, sort_keys=True))
