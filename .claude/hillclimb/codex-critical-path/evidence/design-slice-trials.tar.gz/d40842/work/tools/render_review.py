import argparse
import html
import sys
from pathlib import Path


root = Path(__file__).resolve().parents[1] / "review"
parser = argparse.ArgumentParser(description="Render or verify the local design review page")
mode = parser.add_mutually_exclusive_group()
mode.add_argument("--check", action="store_true")
mode.add_argument("--stdout", action="store_true")
args = parser.parse_args()
sections = []
for title, source in (("Design", "design.md"), ("Source coverage", "source-coverage.csv"),
                      ("Acceptance", "acceptance.csv")):
    body = html.escape((root / source).read_text(encoding="utf-8"))
    sections.append(f"<section><h2>{title}</h2><pre>{body}</pre></section>")
page = ("<!doctype html>\n<meta charset=utf-8>\n<title>Ledger retry design review</title>\n"
        "<h1>Ledger retry design review</h1>\n" + "\n".join(sections) + "\n").encode()
target = root / "index.html"
if args.stdout:
    sys.stdout.buffer.write(page)
elif args.check:
    if not target.is_file() or target.read_bytes() != page:
        raise SystemExit("Review page is missing or stale")
    print("Review page matches the three source artifacts")
else:
    target.write_bytes(page)
    print("Generated review/index.html")
