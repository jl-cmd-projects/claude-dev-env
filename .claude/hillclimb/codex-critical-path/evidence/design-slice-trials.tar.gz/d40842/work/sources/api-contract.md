# Retry delivery contract

One renewal submission carries a retry key. Keep the key stable after ambiguous network failure.
A separate transport request ID is assigned to each delivery attempt. Retrying the same
transport request ID can be filtered before the ledger handler sees the second delivery.
The browser suppresses a repeat submit in the first 90 seconds. Deliveries beyond that
window can reach the handler. Identical keys in different workspaces are independent.
