# Accepted ledger constraints

The server ledger is authoritative. Propose a uniqueness boundary of `(workspace_id, retry_key)`.
Duplicate handling returns the prior committed receipt without inserting another row.
Persist the idempotency record and the ledger entry in the same transaction. A failed response
may happen after commit. The duplicate entry's replay TTL must follow the approved operations register.
