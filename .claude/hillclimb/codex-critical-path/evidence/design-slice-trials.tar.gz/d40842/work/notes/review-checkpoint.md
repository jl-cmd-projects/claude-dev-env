# Design gate handoff

The rough proposal survived the first design discussion. Keep the workspace boundary
and authoritative ledger. Check `evidence/acceptance-open.txt` against the artifacts before clearing rows.
The supporting links were collected in the review table. Operations exported their register
after the draft was written. There is still a list of probe ideas from review below.

## Review backlog

- Check the delayed same-key retry example against the full receipt.
- Compare with a short burst, in case that establishes different behavior.
- Consider a same-key example in another workspace and an interrupted response after commit.
- Record the adopted retention window and its effect on acceptance.

A new delayed prototype run saved with `--save` lands in `evidence/ledger-recheck.json`.
The approved requirements and opening evidence are retained for comparison.
