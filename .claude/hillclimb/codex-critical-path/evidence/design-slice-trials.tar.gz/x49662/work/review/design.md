# Ledger retry design

Implementation is pending design approval. This package closes the design gate; prototype results do not prove a production implementation.

## Decision and sources

Keep the server ledger authoritative. Enforce uniqueness on (workspace_id, retry_key) and persist the idempotency record, prior committed receipt and ledger entry in the same transaction. A duplicate within retention returns the prior receipt without inserting another entry. A response can fail after commit; keep the retry key stable and assign a distinct transport request ID on each delivery. Sources: sources/ledger-model.md and sources/api-contract.md.

Adopt the approved workspace ledger-retry retention of **48 hours (172800 seconds)** from sources/retention-register.csv. The 72-hour entry is superseded; the 24-hour client-metrics and 168-hour journal-export entries do not apply. Start replay retention at commit. Keep the record eligible while elapsed time is less than 48 hours; at 48 hours it expires. Expiry ends the prior-receipt replay guarantee, not the authoritative ledger history. A later renewal still follows business validity checks; expiry alone must never delete a committed ledger entry. Cleanup must not remove a record early or extend its expiry by replaying it.

## Evidence and limits

The opening evidence/delayed-retry.json showed one row at 140 seconds but reused request-041; its transport_filtered outcome never reached duplicate handling. It cannot establish ledger replay.

evidence/ledger-recheck.json: delayed scenario, distinct IDs request-051 and request-052, delay 140 seconds, same workspace oak-17 and key renewal-418: ledger_replay, one row. This is beyond the 90-second browser window and supports the ledger decision.

evidence/burst-probe.json: distinct IDs request-061 and request-062, delay 10 seconds: client_window_filtered, one row. This supports the client filter only and adds no ledger replay proof.

evidence/workspace-probe.json: workspace scenario, distinct IDs request-071 and request-072, delay 140 seconds: separate_workspace, two rows. The synthetic scenario represents the same key in separate workspaces; its receipt prints only the first workspace, so the full workspace pair must also be asserted in implementation acceptance.

evidence/response-loss-probe.json: response-loss scenario, distinct IDs request-081 and request-082, delay 140 seconds: ledger_replay, one row. The synthetic scenario models a lost response after commit; an implementation test must actually drop that response and assert receipt equality and transaction atomicity.

The local prototype permits at most 86400 seconds, so it cannot exercise the 48-hour expiry. Source coverage establishes the adopted TTL; clock-controlled boundary tests below remain implementation acceptance, not claimed prototype results.

## Executable acceptance plan

Run python tools/check_design.py, then python tools/render_review.py and python tools/render_review.py --check for this design package. The script checks the saved prototype receipts and the approved retention selection.

After design approval, implement these tests against an isolated ledger with an injectable clock and delivery transport; seed a fresh ledger per test and query both idempotency records and entries after each step:

- A01: submit key K to workspace A with transport T1 at t=0, retry to A with T2 at t=140 seconds, then submit K to workspace B with T3. Assert A has exactly one entry and a replay with the identical committed receipt; B has its own entry and receipt; total entries equal two. Exercise concurrent A/K submissions and assert one committed entry, with record and entry committed together.
- A02: commit A/K with T1 at t=0 and drop the response after commit. Deliver T2 at t=140 seconds. Assert the handler is reached, returns the first committed receipt, and leaves exactly one entry and one idempotency record. Inject failure before commit separately and assert neither record nor entry commits; retry then creates exactly one pair. A same-transport-ID repeat and a 10-second browser repeat are filter controls and cannot substitute for this test.
- A03: commit A/K at t=0; deliver distinct transport IDs with the same key at t=172799 and assert replay, identical receipt, one entry, and unchanged expiry t=172800. Advance to t=172800, run expiry cleanup, and assert the replay record is expired/removed while the original ledger entry is retained. At t=172801 assert it remains expired and ledger history remains present. Exercise the renewal business check for post-expiry requests separately; do not rely on expired replay protection. Assert cleanup at t=172799 keeps the record. Run these boundaries with sample clock advancement rather than wall-clock waiting.

Acceptance rows are ready as specified tests for approval. Production integration acceptance and implementation remain pending design approval.
