import csv
import json
from pathlib import Path

root = Path(__file__).resolve().parents[1]
expected = {
    "ledger-recheck.json": ("delayed", 140, "ledger_replay", 1),
    "burst-probe.json": ("burst", 10, "client_window_filtered", 1),
    "workspace-probe.json": ("workspace", 140, "separate_workspace", 2),
    "response-loss-probe.json": ("response-loss", 140, "ledger_replay", 1),
}
for name, outcome in expected.items():
    receipt = json.loads((root / "evidence" / name).read_text())
    assert len(set(receipt["request_ids"])) == 2, name
    assert tuple(receipt[k] for k in ("scenario", "delay_seconds", "second_outcome", "ledger_rows")) == outcome, name
with (root / "sources/retention-register.csv").open() as source:
    approved = [r for r in csv.DictReader(source) if r["rule"] == "ledger-retry" and r["scope"] == "workspace" and r["status"] == "approved"]
assert len(approved) == 1 and int(approved[0]["hours"]) == 48
for name, status in (("source-coverage.csv", "covered"), ("acceptance.csv", "ready")):
    with (root / "review" / name).open() as source:
        rows = list(csv.DictReader(source))
    assert len(rows) == 3 and all(r["status"] == status for r in rows), name
print("Design package checks pass: four prototype receipts, approved 48-hour TTL, three covered sources and three ready acceptance plans. Production TTL behavior is not tested by this script.")
