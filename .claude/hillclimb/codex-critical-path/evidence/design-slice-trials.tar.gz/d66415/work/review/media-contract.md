# Accepted Media contract — M-23

Keep the orientation and ICC transforms at `gallery/decode.py:decode_image` for this
release. Review owner: Media. Legacy CMYK calibration follows in the Media queue under
M-41. Gallery navigation owns card publication and navigation identity. This decision
applies to the desktop controller; deployed entry points need an entry-point trace.
