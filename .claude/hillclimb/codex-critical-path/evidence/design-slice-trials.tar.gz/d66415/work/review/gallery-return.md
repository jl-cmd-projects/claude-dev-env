# Browser-back gallery card

## Current behavior

In the desktop browser-back capture `desk-back-7d21`, `SnapshotHydrator.resume` publishes the first card synchronously on navigation `nav-162` from the matching river snapshot at revision `river-r69`. The previous navigation's late image callback (`nav-161`, `terrace-r83`) is discarded with `navigation-mismatch` before decode. The current navigation's callback applies image revision `river-r70` without republishing the card. The visible card retains the hydrator as its publisher and `river-r69` as its card revision.

In the desktop cold-open capture `desk-cold-6a93`, there is no snapshot. The current navigation's decoded image supplies the first card through `LiveImageLoader.publish` (`nav-112`, `courtyard-r17`).

## Proposed boundary

Keep first-card publication and navigation identity in the gallery controller. Publish a matching snapshot on browser back without waiting for an image. On a cold open, publish when the first current-navigation image is ready. Check the navigation token before decode so callbacks from a previous page cannot replace the restored card. A current-navigation image can update the image on the existing card.

Under the [accepted Media contract](media-contract.md), Media owns orientation and ICC transforms in `gallery/decode.py:decode_image`. Card publication stays with Gallery, so restoring a snapshot does not depend on Media decode. Media tracks legacy CMYK calibration separately in M-41.

## Deployment evidence

The [route samples](../evidence/route-samples.json) identify the replayed browser-back capture as a local desktop build and record no deployed partner-embed capture. Whether the deployed embed uses the same controller path remains open. Integrations on-call can resolve it with a deployed entry-point trace that identifies the controller and records first publication and delayed callback handling.

## Coverage

Run both replays from the checkout root and compare their `trace` and `visible_card` fields with [the coverage matrix](gallery-coverage.json).

```sh
python -B tools/trace_preview.py captures/cold-open.json
python -B tools/trace_preview.py captures/return-late.json
```
