def decode_image(event):
    return {"revision": event["revision"], "orientation": "display", "profile": "sRGB"}
