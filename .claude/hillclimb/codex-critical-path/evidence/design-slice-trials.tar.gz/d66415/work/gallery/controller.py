from gallery.decode import decode_image


def replay(capture):
    current = None
    card = None
    trace = []
    for event in capture["events"]:
        token = event["navigation"]
        if event["type"] == "navigation":
            current = token
            card = None
            snapshot = event.get("snapshot")
            if snapshot and snapshot["view"] == event["view"]:
                card = {"revision": snapshot["revision"], "producer": "SnapshotHydrator.resume"}
                trace.append(["card-published", current, card["producer"], card["revision"]])
        elif token != current:
            trace.append(["image-discarded", token, "navigation-mismatch"])
        else:
            decoded = decode_image(event)
            if card is None:
                card = {"revision": decoded["revision"], "producer": "LiveImageLoader.publish"}
                trace.append(["card-published", current, card["producer"], card["revision"]])
            else:
                trace.append(["image-applied", current, decoded["revision"]])
    return {"trace": trace, "visible_card": {"navigation": current, **card} if card else None}
