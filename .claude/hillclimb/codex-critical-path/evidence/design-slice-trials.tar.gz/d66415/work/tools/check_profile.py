import argparse
import json
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument("profile")
parser.add_argument("--compare-transforms", action="store_true")
args = parser.parse_args()
sample = json.loads(Path("evidence/profile-sample.json").read_text())[args.profile]
print(f"{args.profile} / moss: deltaE {sample['delta_e']} (reference envelope ≤ {sample['envelope']})")
if args.compare_transforms:
    print(f"source profile: {sample['source']}; display profile: {sample['display']}")
    print("Store the profile receipt with the Media calibration queue.")
else:
    print("To compare working-space and display conversions, run:")
    print(f"  python -B tools/check_profile.py {args.profile} --compare-transforms")
raise SystemExit(int(sample["delta_e"] > sample["envelope"]))
