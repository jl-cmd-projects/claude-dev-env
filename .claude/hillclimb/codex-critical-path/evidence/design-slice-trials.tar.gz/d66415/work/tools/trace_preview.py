import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from gallery.controller import replay

if len(sys.argv) != 2:
    raise SystemExit("Usage: python -B tools/trace_preview.py captures/<name>.json")
path = Path(sys.argv[1])
capture = json.loads(path.read_text(encoding="utf-8"))
print(json.dumps({"capture": capture["capture"], **replay(capture)}, indent=2))
