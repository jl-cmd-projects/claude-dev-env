# Lamplight gallery

`gallery/controller.py` models the desktop event order for navigation and image callbacks.
Run a capture from the checkout root with `python -B tools/trace_preview.py captures/<name>.json`.
The replay prints the ordered trace and visible card. This captures the local controller only.

For the review coverage matrix, name the capture and record the `trace` and `visible_card`
under `expect`. Reviewers compare those fields with the trace tool before sign-off.
