# Ledger retry design

Implementation remains pending design approval.

## Contract and decision

Keep the server ledger authoritative. Enforce uniqueness on
(workspace_id, retry_key), persist the retry record and ledger entry in one
transaction, and return the prior committed receipt for a live duplicate without
another debit. Preserve the retry key after an ambiguous response; use a distinct
transport request ID on each delivery. Different workspaces remain independent.
Sources: sources/api-contract.md and sources/ledger-model.md.

Use the approved ledger-retry/workspace retention of 48 hours from
sources/retention-register.csv. The 72-hour row is superseded; 24-hour client
metrics and 168-hour journal export rows do not govern retries. Proposed precise
boundary for approval: expires_at = committed_at + 172800 seconds; replay remains
valid while now < expires_at. At equality the retry record is expired. Expiring
retry metadata must not delete the authoritative ledger entry. Beyond this
window the design makes no duplicate-replay guarantee; callers must reconcile
the ledger before resubmitting an ambiguous old renewal.

## Prototype findings

The opening evidence/delayed-retry.json used only request-041 at 140 seconds:
one row and transport_filtered. That receipt never reached ledger duplicate
handling and cannot prove the proposed guarantee.

The corrected delayed run used renewal-418 in oak-17, distinct request-051 and
request-052 at 140 seconds. evidence/ledger-recheck.json reports ledger_replay
and one row. This crosses the 90-second browser window and reaches ledger replay.

The short-burst control used request-061 and request-062 at 10 seconds.
evidence/burst-probe.json reports client_window_filtered and one row; it proves
client filtering only, not ledger idempotency.

The workspace scenario used the same retry key across workspaces, request-071
and request-072 at 140 seconds. evidence/workspace-probe.json reports
separate_workspace and two independent rows. The synthetic receipt exposes
only the first workspace name, so production acceptance must inspect both
workspace IDs explicitly.

The interrupted-response scenario used request-081 and request-082 at 140 seconds.
evidence/response-loss-probe.json reports ledger_replay and one row after a
committed first attempt. All runs are recorded in evidence/probe-runs.jsonl.

These synthetic scenarios support design decisions; they do not exercise a
real database, concurrency or TTL expiry. The sample clock stops at 86400
seconds, before the 48-hour boundary. Do not extend it merely to claim expiry
proof. The acceptance plan below supplies the required implementation checks.

## Executable acceptance plan

Run python tools/acceptance_plan.py now to verify the saved prototype receipts
and approved retention selection. Run python tools/render_review.py followed by
python tools/render_review.py --check to publish and verify this package.

After design approval, implement database-backed acceptance using an injected
UTC clock and isolated workspace fixtures. Execute the following ordered steps
as automated assertions in the implementation test suite; acceptance is pending
until those tests run against the real handler:

1. At t0 commit renewal-418 in oak-17 with request-a. Retry at t0+140 seconds
   with request-b and the same retry key. Assert identical committed receipt,
   one ledger entry and one retry record.
2. Submit the same key to pine-18 with request-c. Assert independent receipt
   and exactly one entry per workspace (two total).
3. Commit an entry and discard its response. Deliver a new transport ID with
   its retry key. Assert replay of the committed receipt and one debit.
   Inject failure before commit separately; assert neither retry record nor
   ledger entry survives rollback. Race two same-key deliveries; assert one
   committed entry and consistent receipt.
4. Use independent fixtures at t0+172799, t0+172800 and t0+172801 seconds.
   Assert replay at 172799; assert expired retry metadata is not replayable at
   equality or afterward. Assert the original ledger entry remains intact at
   every boundary. Check persisted expires_at minus committed_at equals
   172800 seconds. Repeat without cleanup running, so expiry enforcement
   cannot depend on the cleanup schedule.
5. Confirm the caller reconciles an ambiguous renewal older than 48 hours
   before creating a new submission. Verify different retry keys remain
   independent within one workspace.

The CSV rows are ready for the design gate because sources, decisions and
assertions are specified. Ready is not a claim of production implementation
or passing database acceptance.
