import csv
import json
from pathlib import Path

root = Path(__file__).resolve().parents[1]
def receipt(name, outcome, rows, delay):
    data = json.loads((root / "evidence" / name).read_text())
    assert data["second_outcome"] == outcome, name
    assert data["ledger_rows"] == rows, name
    assert data["delay_seconds"] == delay, name
    assert len(set(data["request_ids"])) == 2, name
receipt("ledger-recheck.json", "ledger_replay", 1, 140)
receipt("burst-probe.json", "client_window_filtered", 1, 10)
receipt("workspace-probe.json", "separate_workspace", 2, 140)
receipt("response-loss-probe.json", "ledger_replay", 1, 140)
with (root / "sources/retention-register.csv").open() as f:
    rows = [r for r in csv.DictReader(f) if r["rule"] == "ledger-retry"
            and r["scope"] == "workspace" and r["status"] == "approved"]
assert len(rows) == 1 and int(rows[0]["hours"]) == 48
print("Saved prototype receipts and approved 48-hour retention verified")
print("Database-backed acceptance, including TTL boundaries, remains for implementation after approval")
