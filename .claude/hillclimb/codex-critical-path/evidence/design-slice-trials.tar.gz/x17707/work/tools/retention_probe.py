"""Design-only TTL boundary model; no production persistence or clock."""
import json
from pathlib import Path
TTL_SECONDS = 48 * 60 * 60
cases = [
    {"age_seconds": TTL_SECONDS - 1, "outcome": "ledger_replay", "ledger_rows": 1},
    {"age_seconds": TTL_SECONDS, "outcome": "retry_expired", "ledger_rows": 1},
    {"age_seconds": TTL_SECONDS + 1, "outcome": "retry_expired", "ledger_rows": 1},
]
for case in cases:
    observed = "ledger_replay" if case["age_seconds"] < TTL_SECONDS else "retry_expired"
    assert observed == case["outcome"]
receipt = {"model": "proposed expiry policy, not production proof", "ttl_hours": 48, "ttl_seconds": TTL_SECONDS, "cases": cases}
Path("evidence/retention-probe.json").write_text(json.dumps(receipt, indent=2) + "\n")
print(json.dumps(receipt, indent=2))
