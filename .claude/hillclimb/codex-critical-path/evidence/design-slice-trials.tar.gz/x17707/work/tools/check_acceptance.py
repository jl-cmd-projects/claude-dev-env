"""Verify design receipts; this does not test production code."""
import csv
import json
from pathlib import Path
def receipt(name):
    return json.loads(Path("evidence", name).read_text())
for name, outcome, count, delay in [
    ("ledger-recheck.json", "ledger_replay", 1, 140),
    ("response-loss-probe.json", "ledger_replay", 1, 140),
    ("workspace-probe.json", "separate_workspace", 2, 140),
    ("burst-probe.json", "client_window_filtered", 1, 10),
]:
    r = receipt(name)
    assert (r["second_outcome"], r["ledger_rows"], r["delay_seconds"]) == (outcome, count, delay), name
    assert len(set(r["request_ids"])) == 2, name
rules = list(csv.DictReader(Path("sources/retention-register.csv").open()))
approved = [r for r in rules if r["rule"] == "ledger-retry" and r["scope"] == "workspace" and r["status"] == "approved"]
assert len(approved) == 1 and approved[0]["hours"] == "48"
r = receipt("retention-probe.json")
assert r["ttl_hours"] == 48 and r["ttl_seconds"] == 172800
assert [(c["age_seconds"], c["outcome"], c["ledger_rows"]) for c in r["cases"]] == [(172799,"ledger_replay",1),(172800,"retry_expired",1),(172801,"retry_expired",1)]
for name, status in [("source-coverage.csv","covered"),("acceptance.csv","ready")]:
    rows=list(csv.DictReader(Path("review",name).open()))
    assert len(rows)==3 and all(r["status"]==status for r in rows)
print("Design acceptance receipts and source coverage pass; production acceptance remains planned")
