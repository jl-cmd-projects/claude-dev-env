# Ledger retry design

Design ready for approval; implementation waits for design approval.

## Decision and sources

Keep the server ledger authoritative with uniqueness on (workspace_id, retry_key).
Persist the idempotency record and ledger entry in one transaction. A duplicate within
the replay window returns the original committed receipt with no additional ledger row.
Use a stable retry key per renewal and a fresh transport request ID per delivery.
These decisions follow sources/api-contract.md and sources/ledger-model.md.

Adopt the approved ledger-retry workspace retention of 48 hours (172800 seconds)
from sources/retention-register.csv. The 72-hour entry is superseded; the 24-hour
client metrics and 168-hour export rows have different scopes and do not apply.

Proposed expiry boundary: measure elapsed time from the original commit, without
extending the window on replay. Replay is eligible for age < 172800 seconds.
At age >= 172800, return an explicit retry_expired outcome for that renewal,
without inserting another ledger entry. Keep the original key on the authoritative
ledger entry so expiring replay data cannot remove the uniqueness boundary.
The client must reconcile an expired ambiguous renewal rather than automatically
create a new retry key. This expiry response is a design proposal for approval,
not an already implemented API behavior.

## Prototype findings

evidence/ledger-recheck.json: delayed, 140 seconds, retry key renewal-418 in oak-17,
distinct request-041 and request-088; second_outcome ledger_replay and ledger_rows 1.
The delay exceeds the 90-second browser suppression window and separate transport
IDs avoid request-level filtering. The complete opening receipt in
evidence/delayed-retry.json agrees. This supports server replay within the window.

evidence/burst-probe.json: 10 seconds, burst-1 and burst-2; ledger_rows 1 but
second_outcome client_window_filtered. It exercises client suppression, not ledger
replay, and cannot substitute for the delayed case.

evidence/workspace-probe.json: 140 seconds, workspace-1 and workspace-2, same key
in independent workspaces; second_outcome separate_workspace and ledger_rows 2.
evidence/response-loss-probe.json: 140 seconds, loss-1 and loss-2, response lost
after commit; second_outcome ledger_replay and ledger_rows 1.

tools/retention_probe.py models the proposed expiry boundary and writes
evidence/retention-probe.json: ages 172799, 172800 and 172801 seconds yield replay,
expired and expired respectively, with one ledger row throughout.
The existing ledger demo caps its sample clock at 86400 seconds and has no TTL
implementation. The retention probe is only an executable design model; it does
not establish production retention, transaction isolation or durable behavior.

## Executable acceptance plan

Run from the checkout root:

    python tools/ledger_demo.py workspace --request-id workspace-1 --request-id workspace-2 --delay 140 --save
    python tools/ledger_demo.py delayed --request-id request-041 --request-id request-088 --delay 140 --save
    python tools/ledger_demo.py response-loss --request-id loss-1 --request-id loss-2 --delay 140 --save
    python tools/ledger_demo.py burst --request-id burst-1 --request-id burst-2 --delay 10 --save
    python tools/retention_probe.py
    python tools/check_acceptance.py
    python tools/render_review.py
    python tools/render_review.py --check

The receipt checker asserts outcomes, row counts, distinct IDs and delays; summary
text alone cannot pass. A01 covers workspace independence. A02 covers actual
server replay beyond client filtering and interrupted responses. A03 covers the
approved register and the explicit expiry boundary in the design model.

Implementation acceptance after design approval must replace the synthetic ledger
with an isolated real database and injectable clock: submit equal keys concurrently
in one workspace and assert one durable entry and identical committed receipts;
submit the same key in two workspaces and assert one independent entry per workspace;
drop the first response after commit then retry with a new request ID after 140
seconds and assert the original receipt and exactly one entry. Crash before commit
must leave neither record; crash after commit must leave both and replay correctly.
At 172799 seconds assert replay; at exactly 172800 and 172801 assert retry_expired,
one original ledger entry and no new debit, including after replay-cache cleanup.
Replaying before expiry must not extend the original deadline. These production
checks are planned and have not been run; design readiness does not approve implementation.
