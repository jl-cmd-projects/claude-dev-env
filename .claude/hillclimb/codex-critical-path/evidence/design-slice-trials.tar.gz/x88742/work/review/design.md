# Ledger retry design

## Delivery and commit

One logical renewal keeps the same retry key after an ambiguous response. Each delivery gets a fresh transport request ID. The browser suppresses repeat submits in the first 90 seconds, and reusing a transport ID can prevent the ledger handler from seeing the repeat. Use distinct IDs and pass the client window when testing replay. [Delivery contract](../sources/api-contract.md)

The server ledger is authoritative. Enforce uniqueness on `(workspace_id, retry_key)` and commit the ledger entry and idempotency record in the same transaction. A repeat for a committed key returns the prior receipt without a second debit. A rollback leaves neither record, so a later attempt can commit. The same key in two workspaces is independent. [Ledger constraints](../sources/ledger-model.md)

## Replay retention

Use the approved **48-hour replay TTL** from the first successful commit, without extending it on replay. The 72-hour entry is superseded. Replay is eligible before `committed_at + 48h` and expires at that instant. This design proposes rejecting retries for expired committed keys and directing the caller to reconcile the existing renewal before starting a new one. Expiring receipt replay does not remove the ledger debit or its uniqueness key. [Operations register](../sources/retention-register.csv)

## Prototype evidence

- [Initial delayed receipt](../evidence/delayed-retry.json) used `request-041` and `request-087` at 140 seconds for `renewal-418` in `oak-17`. The second outcome was `ledger_replay` with one ledger row.
- [Delayed recheck](../evidence/ledger-recheck.json) repeated the 140-second case with `request-143` and `request-144`. The result was `ledger_replay` with one row.
- [Burst control](../evidence/burst-probe.json) used `request-151` and `request-152` at 30 seconds. The result was `client_window_filtered` with one row. It confirms why the short burst cannot establish ledger replay.
- [Workspace probe](../evidence/workspace-probe.json) used the workspace scenario with `request-161` and `request-162` at 140 seconds. The simulator reported `separate_workspace` with two rows. The receipt prints only the first workspace, so the implementation test must assert the stored workspace on each row.
- [Response-loss probe](../evidence/response-loss-probe.json) used `request-171` and `request-172` at 140 seconds. The simulated retry returned `ledger_replay` with one row. The implementation test must inject the lost response after a real commit and compare the full receipt.

## Acceptance plan

Run the following cases against an isolated ledger with a controllable clock after design approval. Use a fresh database or distinct fixture keys for each case and verify persisted rows directly. The local [prototype](../tools/ledger_demo.py) can replay the saved examples and supports up to 24 hours on its sample clock. It cannot verify expiry or real database transaction semantics.

1. **A01 — Workspace isolation.** At time zero, send the same retry key with distinct transport IDs to workspace A and workspace B. Assert two committed rows, one per workspace. Repeat in both workspaces after 140 seconds with two new IDs. Assert each returns its own original receipt, and two rows remain.
2. **A02 — Delayed retry after a lost response.** Commit a renewal and inject a lost response after commit. Capture the receipt from persisted state. Advance 140 seconds and send the same workspace and retry key with a fresh transport ID. Assert that the handler receives the delivery, returns the full original receipt and leaves exactly one debit. In a separate fixture force a failure before commit and assert neither the debit nor the idempotency record persists. Retry with a fresh transport ID and assert exactly one successful commit.
3. **A03 — Expiry boundary.** Commit at time zero and send fresh-ID deliveries of the same key at 47:59:59, 48:00:00 and 48:00:01. Assert receipt replay with one debit before the cutoff, an expired-key outcome at and after the cutoff, and exactly one debit across all deliveries. Assert the earlier replay did not extend the original deadline.

Implementation waits for design approval.
