# Ledger retry design

## Decisions

- The browser keeps the renewal's retry key after an ambiguous network failure. Each delivery uses a new transport request ID. Browser suppression covers the first 90 seconds. The server owns correctness for deliveries that reach it. See `sources/api-contract.md`.
- The ledger enforces uniqueness on `(workspace_id, retry_key)`. Store the ledger entry and its replay record in one transaction. During the replay window, a matching retry returns the original committed receipt with no additional row or debit, including when the first response is lost after commit. The same key may independently succeed in two workspaces. See `sources/ledger-model.md`.
- The approved workspace replay window is 48 hours from commit, per the approved `ledger-retry` row in `sources/retention-register.csv`. Replay applies while the age is below 48 hours and expires at 48 hours. Keep the ledger uniqueness guard after the replay record expires. A known, expired key gets an explicit expiry result with no new debit. A new renewal requires a fresh key.

## Evidence

- The opening receipt, `evidence/delayed-retry.json`, used only `request-041`. Its `transport_filtered` result and one row show that the second delivery never reached the ledger. The summary alone could not establish replay.
- Repeating `renewal-418` in `oak-17` at 140 seconds with `request-051` and `request-052` crossed the client window and used distinct transport IDs. The second delivery returned `ledger_replay`, with one ledger row. See `evidence/ledger-recheck.json`.
- The workspace probe at 140 seconds used `request-061` and `request-062` with the same retry key. It returned `separate_workspace` and two rows. See `evidence/workspace-probe.json`.
- The lost-response probe at 140 seconds used `request-071` and `request-072` with the same retry key. It returned `ledger_replay` and one row. See `evidence/response-loss-probe.json`. The synthetic prototype reports outcome and row count. The acceptance plan also compares the actual committed receipt and checks atomicity after implementation.
- The prototype clock is limited to 86,400 seconds. The approved 48-hour value is established by the operations register. The exact expiry boundary and the post-expiry write guard are implementation acceptance checks with an injected clock.

## Acceptance

Run the prototype commands and inspect their JSON assertions as specified in `review/acceptance.csv`. After design approval, run the corresponding integration checks against a clean test ledger with an injected clock and controllable transport and transaction failures. Reset the test ledger between cases. Every failed assertion fails the implementation gate.

Implementation is pending design approval.
