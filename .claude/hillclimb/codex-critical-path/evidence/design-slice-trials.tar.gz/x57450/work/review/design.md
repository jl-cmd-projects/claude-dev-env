# Ledger retry design

Use the authoritative server ledger to make a renewal retry produce at most one debit per `(workspace_id, retry_key)`. The client keeps the renewal's retry key after an ambiguous response and assigns a fresh transport request ID to each delivery. A client's first 90 seconds of submit suppression and the transport's repeated-request filter can reduce deliveries. A delivery that reaches the handler still needs the ledger check. See [retry delivery contract](../sources/api-contract.md).

## Transaction and replay

Write the debit and its idempotency record together in one transaction under the workspace-scoped unique key. A competing handler must resolve the same key against the committed transaction. It replays the original committed receipt without another debit while the record is inside the replay window. If a transaction rolls back before commit, the next delivery can perform the first valid debit. If commit succeeds but the response is lost, a retry with the same workspace/key and a fresh request ID replays the committed receipt. A second workspace can use the same retry key for its own debit. See [ledger constraints](../sources/ledger-model.md).

The operations register approves **48 hours** for workspace ledger retries and marks 72 hours superseded. Measure replay eligibility from the first successful commit, with no extension on replay. The design treats a retry as eligible while its age is less than 48 hours. At exactly 48 hours and afterward, it no longer replays the receipt. Keep uniqueness authoritative on the ledger after replay metadata expires. When that key still belongs to a committed renewal, return an explicit expiry result without creating a second debit. See [retention register](../sources/retention-register.csv).

## Evidence and design gate

| Local sample input | Observed outcome |
| --- | --- |
| Same key `renewal-418` in `oak-17`, 140 s apart with distinct request IDs `request-041` and `request-087` | `ledger_replay` with one row in [the opening receipt](../evidence/delayed-retry.json) and [the recheck](../evidence/ledger-recheck.json). |
| Same key, 30 s apart with distinct IDs `request-111` and `request-112` | `client_window_filtered` with one row. The [burst receipt](../evidence/burst-probe.json) demonstrates browser filtering and does not establish server replay. |
| Same key, workspace scenario, 140 s apart with distinct IDs `request-091` and `request-092` | `separate_workspace` with two rows in the [workspace receipt](../evidence/workspace-probe.json). The sample reports an aggregate row count and one display workspace. Acceptance checks one committed row in each real workspace. |
| Same key, response-loss scenario, 140 s apart with distinct IDs `request-101` and `request-102` | `ledger_replay` with one row in the [response-loss receipt](../evidence/response-loss-probe.json). Acceptance checks persisted receipt equality and injects the loss after commit. |

Run the local reproduction commands and compare the results to the [acceptance rows](acceptance.csv). Run the implementation checks against a controlled clock and an isolated test ledger after design approval. The sample uses a synthetic ledger and caps its clock at 24 hours. It does not exercise the 48-hour boundary, transactional rollback, or receipt equality.

Implementation is pending design approval.
