"""Local design assertions; does not implement or verify the production API."""
import csv
import json
from pathlib import Path

root = Path(__file__).resolve().parents[1]
with (root / "sources/retention-register.csv").open() as source:
    approved = [row for row in csv.DictReader(source)
                if row["rule"] == "ledger-retry" and row["scope"] == "workspace"
                and row["status"] == "approved"]
assert len(approved) == 1
hours = int(approved[0]["hours"])
assert hours == 48
ttl = hours * 3600
cases = [
    ("delayed-retry.json", "ledger_replay", 1, 140),
    ("ledger-recheck.json", "ledger_replay", 1, 140),
    ("burst-probe.json", "client_window_filtered", 1, 10),
    ("workspace-probe.json", "separate_workspace", 2, 140),
    ("response-loss-probe.json", "ledger_replay", 1, 140),
]
for name, outcome, rows, delay in cases:
    receipt = json.loads((root / "evidence" / name).read_text())
    assert receipt["second_outcome"] == outcome, name
    assert receipt["ledger_rows"] == rows, name
    assert receipt["delay_seconds"] == delay, name
    assert len(set(receipt["request_ids"])) == 2, name

# Synthetic ledger persists independently from the replay receipt.
ledger = {("oak-17", "renewal-418"): {"committed_at": 0, "receipt": "receipt-1"}}
def retry(age):
    existing = ledger[("oak-17", "renewal-418")]
    if age - existing["committed_at"] < ttl:
        return {"outcome": "ledger_replay", "receipt": existing["receipt"]}
    return {"outcome": "expired_key", "receipt": None}

results = []
for age, expected in [(ttl - 1, "ledger_replay"), (ttl, "expired_key"),
                      (ttl + 1, "expired_key")]:
    result = retry(age)
    assert result["outcome"] == expected
    assert len(ledger) == 1
    if expected == "ledger_replay":
        assert result["receipt"] == "receipt-1"
    results.append({"age_seconds": age, **result, "ledger_rows": len(ledger)})
receipt = {"kind": "proposed_policy_model", "retention_hours": hours,
           "cases": results}
(root / "evidence/retention-probe.json").write_text(
    json.dumps(receipt, indent=2, sort_keys=True) + "\n")
print("PASS: 5 saved delivery receipts and 3 proposed retention-boundary assertions")
