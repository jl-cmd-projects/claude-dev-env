# Ledger retry design

Implementation waits for design approval. This package closes the design pass; the
local prototypes are evidence for the proposed behavior, not production verification.

## Decisions and sources

The server ledger is authoritative. Use the unique boundary
`(workspace_id, retry_key)`, and persist the ledger entry and idempotency receipt
in one transaction. A duplicate within the replay window returns the prior committed
receipt without adding a row. A response can fail after commit, so the browser must
keep the retry key stable while every transport attempt gets a fresh request ID.
Sources: sources/ledger-model.md and sources/api-contract.md.

Adopt the approved workspace ledger-retry window of **48 hours**, not the
superseded 72-hour value or the unrelated 24/168-hour entries in
sources/retention-register.csv. Measure from the first committed transaction on the
server clock. Replay is available while age < 48 hours. At age >= 48 hours the
receipt is expired. Proposed expiry response: an explicit expired-key conflict with
no debit; callers must reconcile the existing renewal before starting a new one.
Keep the ledger's uniqueness protection after replay receipt expiry, so deleting a
cached receipt never authorizes a second debit for the same workspace/key.
This expiry response is a design choice requiring approval, not an existing API fact.

## Prototype evidence

- evidence/delayed-retry.json: opening delayed case, 140 seconds, distinct
  request-041/request-087, ledger_replay, one row.
- evidence/ledger-recheck.json: delayed 140 seconds with distinct
  request-041/request-088, ledger_replay, one row. This passes the 90-second browser
  window and exercises handler replay.
- evidence/burst-probe.json: 10 seconds with burst-1/burst-2, one row but
  client_window_filtered. This cannot establish handler idempotency.
- evidence/workspace-probe.json: same retry key in separate workspaces, distinct
  workspace-1/workspace-2, 140 seconds, separate_workspace, two independent rows.
- evidence/response-loss-probe.json: response-loss after commit, distinct
  loss-1/loss-2, 140 seconds, ledger_replay, one row.
- evidence/retention-probe.json: local boundary model checks 172799, 172800 and
  172801 seconds against the approved 48 hours; it expects replay before expiry and
  expired-key conflict at/after expiry with one ledger row throughout.

The existing ledger demo has a one-day sample-clock limit and no expiry model.
The separate retention probe exercises the proposed policy only; it does not
establish deployed expiry behavior. Probe receipts and evidence/probe-runs.jsonl
retain the exact inputs. No further burst variants are needed to settle this gate.

## Executable acceptance plan

Run `python tools/design_acceptance.py` to replay the local retention model and
assert the saved delayed, burst, workspace and response-loss outcomes and approved
register. Then run `python tools/render_review.py` followed by
`python tools/render_review.py --check`. review/acceptance.csv maps the gate rows
to these assertions.

Before implementation can ship, implement the same cases against the real API and
database with an injected server clock and fault after commit. Assert receipt
identity, one transaction for ledger plus receipt, workspace isolation and the exact
48-hour boundary; also test concurrent submissions and transaction rollback.
Those integration tests are acceptance requirements, not tests already passed here.
Design approval must accept the proposed expired-key response before API changes.
