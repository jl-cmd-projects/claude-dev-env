# Browser-back gallery card

## Current behavior

The first publisher on browser back is `SnapshotHydrator.resume`. In capture
`desk-back-7d21` (`captures/return-late.json`), navigation `nav-162` restores the
matching river snapshot `river-r69` immediately (`gallery/controller.py:10-16`).
The delayed image for the previous navigation `nav-161` is discarded with
`navigation-mismatch` before decode (`gallery/controller.py:17-18`), so it cannot
replace the restored card. The current-navigation image `river-r70` then produces
an `image-applied` event; the modeled visible card remains `river-r69`, published
by `SnapshotHydrator.resume` (`gallery/controller.py:20-26`). Do not infer a new
card publication or visible revision from that applied event alone.

On a cold open there is no snapshot. Capture `desk-cold-6a93`
(`captures/cold-open.json`) publishes `courtyard-r17` on `nav-112` through
`LiveImageLoader.publish` after decode (`gallery/controller.py:20-23`).

## Proposed boundary

Keep navigation identity and card publication in Gallery. Restore a matching
snapshot immediately on back navigation, reject callbacks from prior navigation
identities, and use the live image publisher when no card exists. Routing every
first card through Media decode would erase the existing snapshot-first path and
is unnecessary for this design.

Keep orientation and ICC transforms at `gallery/decode.py:decode_image`, as
accepted in M-23 (`review/media-contract.md:3-6`). Media owns these transforms;
Gallery owns publication and navigation identity. The legacy CMYK deltaE of 3.4
against the 2.0 envelope (`evidence/profile-sample.json`) is the known M-41 Media
calibration follow-up, not a prerequisite for documenting desktop navigation.
Implementation remains unchanged in this design and coverage pass.

## Deployment evidence

The evidence establishes the desktop local controller only.
`evidence/route-samples.json` identifies the browser-back capture as a desktop
local build and contains no deployed partner-embed capture. Whether that embed
uses this same controller path remains unanswered. Integrations on-call must
supply a deployed entry-point trace linking the embed to its controller and
navigation/image event order before this design can be asserted for deployment.

## Coverage and reviewer replay

`review/gallery-coverage.json` records both cold open and browser back in the
existing `capture` / `expect.trace` / `expect.visible_card` format. The back case
covers both the delayed previous-navigation callback and the current-navigation
callback. Run from the checkout root:

```sh
python -B tools/trace_preview.py captures/cold-open.json
python -B tools/trace_preview.py captures/return-late.json
```

Compare each output trace and visible card with its coverage entry. The back
trace must publish `river-r69` through `SnapshotHydrator.resume`, discard
`nav-161` with `navigation-mismatch`, and apply `river-r70` on `nav-162`, in that
order. Its visible card must retain navigation `nav-162`, producer
`SnapshotHydrator.resume`, and revision `river-r69`. The cold trace must publish
`courtyard-r17` through `LiveImageLoader.publish` on `nav-112`.
