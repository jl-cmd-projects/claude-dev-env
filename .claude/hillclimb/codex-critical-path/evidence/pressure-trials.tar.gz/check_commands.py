"""Run blind judges' quoted operator commands on a fresh read-only staged console."""

import json
from pathlib import Path
import sys
from tempfile import TemporaryDirectory

sys.path.insert(0, str(Path.cwd()))
import pressure_case

root = Path(__file__).resolve().parent
phase = sys.argv[1] if len(sys.argv) > 1 else 'first'
if phase == 'first':
    manifest_name, grades_name = 'pressure_blind_manifest.json', 'pressure_grades.json'
elif phase == 'rescue':
    manifest_name, grades_name = 'pressure_rescue_blind_manifest.json', 'pressure_rescue_grades.json'
else:
    raise ValueError(phase)
manifest = json.loads((root / manifest_name).read_text())['entries']
grades = json.loads((root / grades_name).read_text())['grades']
for opaque, grade in grades.items():
    rid = manifest[opaque]['id']
    specimen = grade['command_excerpt']
    case = json.loads((root / rid / 'run.json').read_text())['case']
    result = {'run':rid, 'case':case, 'command':specimen, 'console_elapsed_seconds':43}
    if specimen:
        with TemporaryDirectory() as tmp:
            work = Path(tmp)/'work'
            pressure_case.prepare(work, case)
            receipt = Path(tmp)/'receipts.jsonl'
            receipt.touch()
            code, stdout, stderr, timedout = pressure_case.execute(work,case,specimen,43,receipt_path=receipt)
            result.update(exit=code, stdout=stdout, stderr=stderr, timed_out=timedout)
    print(json.dumps(result, sort_keys=True))
