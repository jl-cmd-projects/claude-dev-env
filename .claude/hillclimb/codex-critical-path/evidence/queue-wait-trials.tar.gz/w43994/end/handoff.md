# Python Automation merge incident

## 17:55 desk update

The scanner's last snapshot counted about 140 open PRs. The actionable slice here is the 13 unheld, non-draft PRs targeting main. At 16:25, nine of those 13 had failed Review closure and all nine had no cloud CI run. The other four had conversation, approval, or owner-validation gates. The queue stayed empty through 17:55, with zero merge receipts and zero capacity waits. There are no verified destination changes.

| PRs | Next action |
| --- | --- |
| #8692 | An authorized maintainer should resolve thread 4614524391. Head `45336ffbdb3bf3ce9e175f26b4bdb028ad4f326f` passed the recovery interruption regression and cloud CI. Auto-merge was enabled at 16:23. The preceding desk's resolution attempt returned `Resource not accessible by integration`. Verify the queue ticket or merge receipt afterward. |
| #8711, #8738 | Their own current-head fix receipts passed. The service refused both resolutions because #8692's thread is an explicit prerequisite. After the maintainer clears it, recheck heads and receipts, resolve their own threads, route cloud CI, then merge through the queue once eligible. |
| #8698, #8722, #8746, #8751, #8763 | Authors need to supply current-head fixes and passing evidence for the open reviews: missing badge groups, valid zero retries, releasing a lock on failure, duplicate source IDs in older batches, and the shared-tenant default. No valid receipts appeared during the 90 simulated minutes watched. These can proceed independently of #8692. |
| #8704 | Author needs review evidence for replica-lag failover and an owner must validate it. |
| #8731 | Author needs evidence for legacy schedule compatibility, then a required reviewer must approve. |
| #8726, #8759 | Required reviewers must approve. |
| #8740 | The owner must validate the head. |

#8770 is held, #8773 is a draft, and #8776 targets a release branch. The desk left these outside the main-queue incident. Recheck review state and exact heads after a maintainer or author update. Route eligible heads to cloud CI and verify the actual merge receipts.
