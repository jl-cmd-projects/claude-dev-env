# Python Automation merge incident — 17:05 desk time

Merge flow resumed. The desk verified two exact-head merges through the normal queue. It reports 2 merged, 0 queued and 0 waiting for capacity. The most recent scan counted 140 open PRs.

## Cause

At 16:25 the scanner was active and the queue was empty. Review Closure had failed on 9 of the 13 unheld, non-draft main PRs surfaced by the desk. Cloud CI had not started for any of those nine. Three more PRs had approval or owner-validation gates. The remaining PR, #8692, had passed Review Closure and cloud CI and had auto-merge enabled, but conversation resolution blocked queue entry. The desk integration returned “Resource not accessible by integration (resolveReviewThread).” There was no queue capacity wait.

## Verified delivery

| PR | Exact head | Cloud CI | Merge receipt |
| --- | --- | --- | --- |
| #8711 | 03bc816052d | cloud-ci-8711-16052d | merge-8711-16052d |
| #8738 | 03bf7857fb6 | cloud-ci-8738-857fb6 | merge-8738-857fb6 |

I matched the passing fix receipts to their review threads and current heads, resolved those threads through the desk, routed both exact heads, waited for cloud CI, and verified the merge receipts with `python queue.py queue`.

## Open work

| PR | Owner or reviewer next action |
| --- | --- |
| #8692 | A reviewer with thread-resolution access should verify passing receipt `recovery-interruption-regression` on head `45336ffbdb3bf3ce9e175f26b4bdb028ad4f326f`, resolve thread `4614524391`, then verify normal queue entry and merge. |
| #8698 | Author to cover responses without badge groups and post a passing fix receipt. |
| #8704 | Author and owner to verify failover against replica lag, clear the review, and complete owner validation. |
| #8722 | Author to verify zero retry attempts stay valid and post a passing fix receipt. |
| #8726 | Required reviewer to approve. |
| #8731 | Author to verify legacy schedules remain readable, then required reviewer to approve. |
| #8740 | Owner to complete validation. |
| #8746 | Author to verify the lock is released on callback failure and post a passing fix receipt. |
| #8751 | Author to cover older batches with duplicate source IDs and post a passing fix receipt. |
| #8759 | Required reviewer to approve. |
| #8763 | Reviewer and author to settle the new default for shared tenants. |

Once each gate clears, recheck the head, route it through the normal queue and verify successful cloud CI before merging. #8770 is held, #8773 is a draft, and #8776 targets the release branch. All three were left outside the main-queue action.
