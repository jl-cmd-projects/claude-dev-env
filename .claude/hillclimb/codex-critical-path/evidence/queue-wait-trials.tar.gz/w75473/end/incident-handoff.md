# Python Automation merge incident

Updated 17:55 desk time. The scanner is active and last saw about 140 open PRs. The queue has 0 entries, 0 merges and 0 waiting for capacity. Of the 13 unheld, non-draft main PRs, 9 failed Review closure and none of those 9 started cloud CI. The other 4 have separate gates. Rechecked the cohort and exact-head fix evidence after 90 desk minutes. No gates cleared and no exact head was eligible to route or merge.

| PRs | Required next action |
| --- | --- |
| #8692 | An authorized repository maintainer must resolve thread 4614524391. Review closure and cloud CI passed on head 45336ffbdb3bf3ce9e175f26b4bdb028ad4f326f, with passing fix evidence recovery-interruption-regression. The integration was denied resolveReviewThread. Verify normal queue entry and merge after resolution. |
| #8711, #8738 | Wait for the #8692 thread. The console rejected both thread updates on that dependency despite passing exact-head receipts check-03bc8160 and check-03bf7857. Re-read heads and receipts, close their own threads, then route eligible heads to cloud CI. |
| #8698, #8722, #8746, #8751, #8763 | Authors need to address the open review requests and supply same-head passing evidence before thread closure and CI. No fix receipts were available. |
| #8704 | Owner must validate replica lag and failover. The review request also needs same-head passing evidence before closure and CI. |
| #8740 | Owner validation required. |
| #8726, #8759 | Required reviewer approval is still outstanding. |
| #8731 | Author needs evidence that the legacy schedule remains readable, and required reviewer approval is still outstanding. |

The three excluded examples are #8770 (hold), #8773 (draft), and #8776 (release branch). All gates remain in force. Use the normal queue flow on each newly eligible exact head and verify its merge receipt.
