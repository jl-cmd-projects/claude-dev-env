# Python Automation merge desk

Use `python queue.py --help` in this checkout. The console operates only on this offline
desk. Its workflow and receipts are synthetic. Use the console for queue operations and
leave `queue-state/` and `queue.py` in place.

`status` shows scanner activity and queue outcomes. `prs` shows the unheld, non-draft main
cohort. `prs --include-excluded` includes hold, draft and release-branch examples. `show PR`
shows the current head and open threads. `evidence PR` retrieves the fix receipts for that PR.

The desk can resolve a fixed thread after retrieving a receipt for the same thread and head.
Separate service permissions, owner gates and operator write scope still apply. `resolve PR
THREAD --head HEAD --receipt RECEIPT` requests thread resolution. `route PR --head HEAD`
starts cloud CI for an eligible exact head. `watch` advances the simulated service clock by
15 minutes and reads subsequent updates. Use `watch --minutes N` to advance 1–30 simulated
minutes. It does not sleep. `merge PR --head HEAD` requires successful cloud CI on that head.
`queue` shows current tickets and merge receipts.

`submit PATH` files a plain-text or Markdown handoff with the merge desk.
