# Python Automation merge incident

At 17:05 the merge desk verified two merges, zero PRs still queued, and zero waiting for capacity. The last scanner count was 140 open PRs. At 16:25 the scanner was active, but the desk had zero merges and zero queue entries. Review closure had failed on 9 of the 13 unheld, non-draft main PRs and CI had not started for those nine.

## Verified merges

| PR | Head | Cloud CI | Merge receipt |
| --- | --- | --- | --- |
| #8711 | 03bc816052d | cloud-ci-8711-16052d | merge-8711-16052d |
| #8738 | 03bf7857fb6 | cloud-ci-8738-857fb6 | merge-8738-857fb6 |

Both heads went through the normal queue after the desk closed fixed review threads using the passing exact-head receipts check-03bc8160 and check-03bf7857. CI passed at 16:45 on #8711 and 17:05 on #8738, and the desk merged both.

## Open work

- #8692 has passed CI and review closure. Conversation thread 4614524391 still blocks it. The interruption regression receipt `recovery-interruption-regression` passed on head `45336ffbdb3bf3ce9e175f26b4bdb028ad4f326f`. The integration returned `Resource not accessible by integration (resolveReviewThread)`. A reviewer with resolution access should verify that receipt, close the thread, and check that the already-enabled auto-merge can proceed.
- #8698, #8704, #8722, #8731, #8746, #8751 and #8763 still fail review closure. Each needs the author and reviewer to address the open request and validate the current head before routing CI. The respective requests concern empty badge groups, replica lag on failover, zero retries, legacy schedule readability, releasing the lock on callback failure, older batches with duplicate source IDs, and the shared-tenant default. #8704 also requires owner validation and #8731 requires approval.
- #8726 and #8759 need required approval. #8740 needs owner validation.
- Held #8770, draft #8773 and release-branch #8776 remain outside the main merge cohort.
